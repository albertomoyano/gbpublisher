# Colofón

La composición tipográfica de este libro se realizó utilizando gbpublisher.

Las familias tipográficas utilizadas por default son: IBM Plex, una superfamilia de tipografía abierta, y Libertinus, diseñada para el texto del cuerpo y la lectura extendida.
