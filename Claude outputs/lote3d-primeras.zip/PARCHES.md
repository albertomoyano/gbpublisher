# Lote 3, corrección 3: las primeras en páginas separadas (5/11/2026)

Dos archivos completos de `.hidden/`; no hay que compilar. Al arrancar gbpublisher, aceptá «Reemplazar» para los dos y regenerá el HTML.

| Archivo | |
|---|---|
| `xslt/docbook-to-html-portal.xsl` | Portada, créditos y dedicatoria, cada una en su página |
| `assets/css/gbpublisher-integrado.css` | Los créditos con el texto del libro; los logos al ancho de la caja |

## 1. Una página por primera

| Página | Contenido |
|---|---|
| `index.html` | la portada; es adonde lleva «Leer en línea» |
| `creditos.html` | los créditos |
| `h-<dedicatoria>.html` | la dedicatoria, si la hay, como en el PDF (SC-31) |

Lo que decidiste:

- **Las tres son pasos de la lectura**, en este orden: portada → créditos → dedicatoria → primera pieza. La barra y el pie de cada página siguen ese recorrido, y la primera pieza tiene como «Anterior» la última de las primeras.
- **No entran en el menú del índice**, como en el nav del EPUB. El título del libro, arriba del menú, sigue llevando a la portada.
- **«Cómo citar» del libro va a la derecha en las tres páginas.**

Un detalle: los metadatos del libro para indexadores (Highwire, Dublin Core, Open Graph) van solo en la portada. Si las tres páginas declararan el mismo libro, Google Scholar podría tomarlas como tres registros.

### Cómo está hecho

En la hoja hay una secuencia nueva, `$recorrido`, con todas las páginas en orden de lectura. La portada y los créditos no tienen entrada en el manifiesto, así que van como elementos `gbi:paso`, con su página y su etiqueta. Las funciones `gbi:pagina`, `gbi:titulo` y `gbi:etiqueta` los reconocen.

Antes había casos especiales para «la primera pieza vuelve a la entrada» (`esInicio`, `enPieza`). Ya no hacen falta: cada página toma sus vecinas del recorrido.

## 2. Los créditos y los logos

- **El texto de los créditos** ya no va reducido ni en gris. Es el del cuerpo del libro, con el mismo tamaño, interlineado, color y separación entre párrafos que `.article-body`.
- **Los logos de portada y de colección** van al 100 % de la columna del texto: 600 px los dos. Los dos PNG miden 1299 px de ancho, que es exactamente 11 cm a 300 ppp: se diseñaron al ancho de la caja, y en pantalla la caja es la columna. Antes la portada medía 520 px y los créditos 390, porque el CSS los limitaba por alto.

## Verificado en el contenedor

- **Duek:**
  - 11 páginas;
  - el recorrido es portada → créditos → Introducción → …;
  - los dos logos miden 600 px.
- **Duek con una dedicatoria de prueba:**
  - el recorrido es portada → créditos → dedicatoria → Introducción;
  - la dedicatoria no aparece en el menú ni en la portada.
- **Calidad:** HTML5 sin errores, 0 enlaces rotos y la misma salida en dos corridas.
- **Salida autónoma:** sin cambios. Estos dos archivos son solo de la salida integrada.
