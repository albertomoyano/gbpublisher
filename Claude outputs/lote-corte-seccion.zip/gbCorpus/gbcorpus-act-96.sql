-- ============================================================
-- gbCorpus — actualización 96: el corte de un título de sección cae
--            debajo del número (GV-192); \gbCorteSeccion (SC-63)
-- Esquema: 2
-- Origen: conversación del 11/11/2026. Observación de Alberto en Mint
--         con un libro: con el corte, la segunda línea de un título de
--         sección caía debajo del número; la composición que se busca
--         es la de LaTeX (decisión de Alberto).
-- Fecha:  2026-11-11
-- Aplicar: después de act-95. Va con el lote de gbpublisher
--          (lote-corte-seccion: contrato 23).
--
-- ALTAS:
--   GV-192  \\ con \raggedright termina el párrafo del título
--
-- MODIFICA:
--   SC-63   PDF: \gbCorteSeccion en la hoja y en el contrato 23;
--           pendiente (revistas); relaciones
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-95 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 95;
INSERT INTO verificacion SELECT 'GV-191 última GV', MAX(numero) = 191 FROM entradas WHERE prefijo = 'GV';
INSERT INTO verificacion SELECT 'GV-192 libre', COUNT(*) = 0 FROM entradas WHERE prefijo = 'GV' AND numero = 192;
INSERT INTO verificacion SELECT 'SC-63 pendiente', pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10). En el panel (corte-titulo, en borrador hasta probarlo en una revista, SC-34): en una revista, la inserción y las tres salidas, después de la refactorización del módulo de revistas; en los dos productos, los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda.' FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 relaciones', relaciones = 'vinculo:SC-28,vinculo:SC-29,vinculo:SC-39,vinculo:SC-54,vinculo:SC-62,vinculo:GV-121,vinculo:RF-11,vinculo:SC-34' FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 plantilla una vez', (length(cuerpo) - length(replace(cuerpo, '- `docbook-to-latex.xsl`: una plantilla para `processing-instruction(''gb-corte'')` escribe `\gbCorteTitulo` en la apertura y nada en el sumario. Los títulos que vienen de la base no pasan por ella: los arman `f:titulo-compuesto` y `f:titulo-plano`.', ''))) = length('- `docbook-to-latex.xsl`: una plantilla para `processing-instruction(''gb-corte'')` escribe `\gbCorteTitulo` en la apertura y nada en el sumario. Los títulos que vienen de la base no pasan por ella: los arman `f:titulo-compuesto` y `f:titulo-plano`.') FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 contrato una vez', (length(cuerpo) - length(replace(cuerpo, '`\gbCorteTitulo` ya está en el contrato del libro (versión 6) y en el preámbulo de la revista (`m_XML`): no hay contrato nuevo.', ''))) = length('`\gbCorteTitulo` ya está en el contrato del libro (versión 6) y en el preámbulo de la revista (`m_XML`): no hay contrato nuevo.') FROM entradas WHERE codigo = 'SC-63';

-- ------------------------------------------------------------
-- 2. GV-192
-- ------------------------------------------------------------
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('GV', 192, 'GV-192', 'LaTeX: con \raggedright, \\ termina el párrafo; en la forma hang de titlesec la línea cortada cae debajo del número',
   'Observado por Alberto en Mint (11/11/2026) en un título de sección con corte: la segunda línea empezaba en el margen, debajo de «1.1», y no alineada con el texto del título como en LaTeX.

POR QUÉ

- En el núcleo de LaTeX, `\raggedright` cambia `\\` por `\@centercr`, que hace `\par`. titlesec solo le agrega `\nobreak` (`\ttl@changecentercr`, 2.16).
- La forma `hang` de titlesec (`\ttlh@hang`) pone el número y su separación en una caja y compone el título como un párrafo con `\hangindent` igual al ancho de esa caja.
- Un `\\` en el título cierra ese párrafo: la línea siguiente empieza otro, sin la sangría colgante.
- `\newline` corta la línea dentro del mismo párrafo, y la sangría se conserva.

MEDIDO

LuaLaTeX (TeX Live 2023) con las capas reales del libro —la estética compone las secciones con `\titleformat{\section}[hang]{\sf\bfseries\large\raggedright}{\thesection}{.5em}{}`—: con `\\` la segunda línea empieza en el margen del número; con `\newline` queda alineada con el texto del título, igual que la segunda línea de un título largo que LaTeX parte solo. Desde el .md, por la cadena real (filtros, `docbook-to-latex`), en una sección con nota con símbolo y en una subsección: las dos alineadas.

NO MEDIDO

En un texto centrado (`\centering`), `\\` sirve: cada línea es un párrafo centrado. `\newline` termina la línea con `\hfil\break`, y ese `\hfil` correría la línea cortada hacia la izquierda: por eso `\gbCorteTitulo`, que usan los títulos centrados, no se cambió.',
   'vigente', 'empirica', 'LuaLaTeX (TeX Live 2023) con titlesec 2.16 y la estética del libro / SaxonJ-HE 12.5 / Pandoc 3.1.3 / contenedor Ubuntu 24.04; gbpublisher en Linux Mint (observación de Alberto, 11/11)', '2026-11', 'apoya:SC-63,vinculo:GV-70,vinculo:GV-190', NULL, 1920,
   datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO verificacion SELECT 'GV-192 escrita', COUNT(*) = 1 FROM entradas WHERE codigo = 'GV-192';

-- ------------------------------------------------------------
-- 3. SC-63
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(replace(cuerpo, '- `docbook-to-latex.xsl`: una plantilla para `processing-instruction(''gb-corte'')` escribe `\gbCorteTitulo` en la apertura y nada en el sumario. Los títulos que vienen de la base no pasan por ella: los arman `f:titulo-compuesto` y `f:titulo-plano`.', '- `docbook-to-latex.xsl`: una plantilla para `processing-instruction(''gb-corte'')` escribe `\gbCorteSeccion` en la apertura y nada en el sumario. Los títulos que vienen de la base no pasan por ella: los arman `f:titulo-compuesto` y `f:titulo-plano`, con `\gbCorteTitulo`.'), '`\gbCorteTitulo` ya está en el contrato del libro (versión 6) y en el preámbulo de la revista (`m_XML`): no hay contrato nuevo.', '`\gbCorteSeccion` es `\newline` (contrato 23 del libro, 11/11/2026). Hasta entonces la hoja escribía `\gbCorteTitulo`, que es `\\`: en la forma `hang` de titlesec, con `\raggedright`, `\\` termina el párrafo del título, y la segunda línea caía debajo del número (GV-192). Con `\newline` queda alineada con el texto del título, como cuando LaTeX lo parte solo: lo que da la composición en LaTeX (decisión de Alberto). `\gbCorteTitulo` sigue siendo `\\` para los títulos centrados que vienen de la base. En el preámbulo de la revista, `jats-to-latex` sigue escribiendo `\gbCorteTitulo` (ver el pendiente).'),
       pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10). En el panel (corte-titulo, en borrador hasta probarlo en una revista, SC-34): en una revista, la inserción y las tres salidas, después de la refactorización del módulo de revistas; en los dos productos, los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda. Revistas: `jats-to-latex.xsl` escribe `\gbCorteTitulo` en `sec/title/break`, y la segunda línea cae debajo del número (GV-192); se corrige con la refactorización, como en el libro (`\gbCorteSeccion`).',
       relaciones = relaciones || ',vinculo:GV-192',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 con gbCorteSeccion', instr(cuerpo, '\gbCorteSeccion') > 0 FROM entradas WHERE codigo = 'SC-63';

COMMIT;

SELECT codigo, estado, titulo FROM entradas WHERE codigo IN ('SC-63','GV-192') ORDER BY prefijo, numero;
