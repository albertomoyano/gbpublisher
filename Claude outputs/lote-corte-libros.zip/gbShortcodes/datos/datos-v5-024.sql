-- ============================================================
-- datos-v5-024: corte-titulo probado en libros; sigue en borrador
-- ------------------------------------------------------------
-- Modifica:
--   corte-titulo: el pendiente queda con lo que falta. Probado por
--   Alberto en Mint (11/11) en un libro: PDF, HTML y EPUB, escrito a
--   mano y desde el panel, con dos avisos. No se libera: SC-34 no deja
--   liberarlo en libros con las revistas en borrador, y las revistas se
--   prueban después de su refactorización.
-- Esquema: 5
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE _verif (paso TEXT, ok INTEGER CHECK (ok = 1));

-- --- 1. PRECONDICIONES: datos-v5-023 APLICADO, SIN CAMBIOS DESDE ENTONCES ---
INSERT INTO _verif SELECT 'corte-titulo en borrador', COUNT(*) = 1 FROM shortcodes
  WHERE nombre = 'corte-titulo' AND estado_libro = 'borrador' AND estado_revista = 'borrador';
INSERT INTO _verif SELECT 'pendiente de datos-v5-023', pendiente = 'Probar en Mint con un libro y una revista: la inserción desde el panel (cursor antes y después del espacio), los avisos del panel (fuera de un título, # de capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte), la ayuda con el ejemplo coloreado y el PDF del documento de prueba.' FROM shortcodes WHERE nombre = 'corte-titulo';

-- --- 2. CAMBIO ---
UPDATE shortcodes
   SET pendiente = 'Para liberar (SC-34: en los dos productos a la vez): probar en Mint con una revista, después de la refactorización en curso del módulo de revistas: la inserción desde el panel, un aviso y las tres salidas. En los dos: los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda con el ejemplo coloreado. En libros, lo probado está en SC-63.',
       fecha_modificacion = datetime('now','localtime')
 WHERE nombre = 'corte-titulo';

INSERT INTO _verif SELECT 'pendiente nuevo', instr(pendiente, 'Para liberar') = 1 FROM shortcodes WHERE nombre = 'corte-titulo';

DROP TABLE _verif;

COMMIT;

SELECT nombre, estado_libro, estado_revista, pendiente FROM shortcodes WHERE nombre = 'corte-titulo';
