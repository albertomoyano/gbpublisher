-- ============================================================
-- gbCorpus — actualización 94: el corte de un título, probado en
--            libros desde el panel (SC-63)
-- Esquema: 2
-- Origen: conversación del 11/11/2026. Prueba de Alberto en Linux
--         Mint, en un libro. Las revistas se prueban después de su
--         refactorización, en curso en otra conversación.
-- Fecha:  2026-11-11
-- Aplicar: después de act-93. Va con gbShortcodes datos-v5-024.sql.
--
-- ALTAS: ninguna.
--
-- MODIFICA:
--   SC-63   PROBADO EN MINT: la prueba del 11/11 en libros; pendiente
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA: act-93 APLICADA, TEXTOS UNA VEZ
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-93 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 93;
INSERT INTO verificacion SELECT 'SC-63 con el panel', instr(cuerpo, 'EN EL PANEL') > 0 FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 ancla una vez', (length(cuerpo) - length(replace(cuerpo, 'Alberto, 21/10, con un libro y una revista reales: el PDF corta en la apertura del título de sección; el HTML y el EPUB, sin corte.', ''))) = length('Alberto, 21/10, con un libro y una revista reales: el PDF corta en la apertura del título de sección; el HTML y el EPUB, sin corte.') FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 pendiente', pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10). En el panel (corte-titulo, en borrador): la inserción, los avisos, la ayuda y el PDF del documento de prueba.' FROM entradas WHERE codigo = 'SC-63';

-- ------------------------------------------------------------
-- 2. SC-63
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'Alberto, 21/10, con un libro y una revista reales: el PDF corta en la apertura del título de sección; el HTML y el EPUB, sin corte.', 'Alberto, 21/10, con un libro y una revista reales: el PDF corta en la apertura del título de sección; el HTML y el EPUB, sin corte.

Alberto, 11/11, en un libro: el corte escrito a mano y el insertado desde el panel. El PDF corta; el HTML y el EPUB salen de corrido. Desde el panel, una inserción en un título de sección y dos avisos: con el cursor en un párrafo y con una palabra seleccionada. La fila sigue en borrador hasta probarla en una revista (gbShortcodes `datos-v5-024.sql`).'),
       pendiente = replace(pendiente, 'En el panel (corte-titulo, en borrador): la inserción, los avisos, la ayuda y el PDF del documento de prueba.', 'En el panel (corte-titulo, en borrador hasta probarlo en una revista, SC-34): en una revista, la inserción y las tres salidas, después de la refactorización del módulo de revistas; en los dos productos, los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda.'),
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 prueba del 11/11', instr(cuerpo, 'Alberto, 11/11, en un libro') > 0 FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 pendiente nuevo', instr(pendiente, 'hasta probarlo en una revista') > 0 FROM entradas WHERE codigo = 'SC-63';

COMMIT;

SELECT codigo, estado, pendiente FROM entradas WHERE codigo = 'SC-63';
