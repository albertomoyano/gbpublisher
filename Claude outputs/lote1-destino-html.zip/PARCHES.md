# Lote 1 del HTML integrado: el destino del HTML del libro (5/11/2026)

Cada libro declara dónde se publica su salida HTML:

- **autónomo:** lo de siempre;
- **integrado al portal:** en ese caso declara además la dirección del portal.

Este lote solo guarda el dato y lo controla, y no cambia ninguna salida. La salida HTML integrada llega en el lote 3.

## Orden de aplicación

1. **gbpublisher, base:** `sudo bash actualizar-esquema-1.22.0.sh`
2. **gbpublisher, fuentes:** copiá los cuatro archivos de `gbpublisher/.src/` con el IDE **cerrado**. Compilá recién con los cuatro en su lugar.
3. **gbWeb:** copiá `gbWeb/.src/m_Sitio.module` y `gbWeb/.hidden/engine/construir_sitio.sh`, también con el IDE cerrado.

La 1.22.0 va antes que todo lo demás:

- gbpublisher con los fuentes nuevos espera 88 columnas en `libros_md` y avisa si no las encuentra.
- gbWeb con el `m_Sitio` nuevo lee las columnas `destino_html` y `url_portal` de la vista.

`crear-cuenta-gbweb.sh` no hace falta: no hay vistas nuevas, y `CREATE OR REPLACE VIEW` conserva el permiso de la cuenta (GV-177).

## Parte 1: gbpublisher

| Archivo | |
|---|---|
| `actualizar-esquema-1.22.0.sh` | **nuevo** |
| `.src/FMetadatosLibro.form` | **completo.** Es el tuyo: suma dos filas debajo de `url-libro` |
| `.src/FMetadatosLibro.class` | **completo.** Es el tuyo: en `Form_Open`, llena el combo nuevo |
| `.src/m_Metadatos.module` | **completo.** Es el tuyo: carga, valida y guarda los dos campos |
| `.src/m_ConexionBD.module` | **completo.** Es el tuyo: `libros_md` pasa a 88 |

### El script (`actualizar-esquema-1.22.0.sh`)

Exige la 1.21.0 y sigue las reglas de SC-22: idempotente, con respaldo verificado, verificación posterior e informe de solo lectura.

**Las columnas.** Suma dos columnas al final de `libros_md`, en una sola sentencia:

- **`destino_html`:** ENUM `autonomo` o `portal`, NOT NULL, con `autonomo` por omisión. Todos los libros quedan como hasta ahora.
- **`url_portal`:** `VARCHAR(500)`, NULL cuando no hay dato.

**Dos restricciones CHECK:**

- **`chk_libros_url_portal`:** la forma de la dirección es `https?://…/`, con la `/` final, igual que `url_base` del portal en gbWeb.
- **`chk_libros_destino_html`:** un libro con destino `portal` tiene que tener su dirección.

**La vista.** `v_web_libro` suma las dos columnas al final y queda con 34.

**Volver atrás.** El script imprime una línea que primero restaura la vista de la 1.21.0 y después quita las restricciones y las columnas, en ese orden por GV-169. No hace falta restaurar el respaldo entero.

### El formulario

Debajo de `url-libro` hay dos filas nuevas:

- **`destino-html`:** un combo de solo lectura con «Autónomo» e «Integrado al portal».
- **`url-portal`:** un cuadro de texto.

### Al guardar (`m_Metadatos`, función nueva `UrlPortalValida`)

Aplica las mismas reglas que las restricciones CHECK, pero con un aviso claro en lugar del error de la base:

- **«Integrado al portal» sin dirección:** avisa y no guarda.
- **La dirección:** tiene que empezar con `https://` (o `http://`) y no puede tener espacios.
- **La `/` final:** si falta, la agrega y la deja escrita en el cuadro, como hace gbWeb con la dirección del sitio.

Una dirección vacía se guarda como NULL (GV-74).

## Parte 2: gbWeb

| Archivo | |
|---|---|
| `.src/m_Sitio.module` | **completo.** El `<libro>` suma el atributo `destino` y el elemento `<url-portal>` |
| `.hidden/engine/construir_sitio.sh` | **completo.** Suma el aviso, en «Datos para el pie y para compartir» |

**El aviso.** Si un libro asociado a este portal figura en gbpublisher como integrado a otro portal (con otra `url-portal`), se avisa y no se frena:

```
⚠ Libro(s) 903 910: integrados a otro portal según gbpublisher (url-portal distinta de https://…/). Revisá el formulario del libro.
```

Lo que decide qué libros aparecen en el portal sigue siendo la asociación de gbWeb. La dirección que declara el libro solo decide qué cabecera va a llevar su HTML.

El sitio construido no cambia: la XSLT no lee estos datos.

## Verificado en el contenedor

**Base (MySQL 8.0.46)**
- **Primera corrida:** aplica todo; los 19 libros quedan como autónomos.
- **Segunda corrida:** «No hay nada que cambiar».
- **Restricciones:** rechazan «portal» sin dirección y una dirección sin `/` final.
- **Vista:** muestra los dos datos.
- **Cuenta de gbWeb:** conserva sus permisos.
- **Volver atrás:** la línea que imprime el script deja la base en 86 columnas y la vista en 32. Después la volví a aplicar.

**gbpublisher**
- El proyecto completo compila con los cuatro archivos (gbc3 3.19).
- El formulario no se puede abrir en el contenedor: probalo en Mint.
  1. Elegí «Integrado al portal» sin dirección y guardá: tiene que avisar y no guardar.
  2. Cargá una dirección sin `/` final y guardá: tiene que agregarla.

**gbWeb**
- Con el libro 902 integrado a este portal y los 903 y 910 integrados a otro, el aviso nombra solo a 903 y 910.
- Dos construcciones dan la misma huella, y la misma que antes del lote.
