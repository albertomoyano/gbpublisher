#!/bin/bash
# Construcción del sitio estático de un portal — gbWeb
# ============================================================================
# Vive en /usr/share/gbweb/engine/ (o en .hidden/engine/ desde el IDE).
#
# USO
#   construir_sitio.sh <ruta_portal>
#
#   ruta_portal   la carpeta del L-ALGO.md o R-ALGO.md. Gambas ya escribió
#                 ahí tmp/sitio.xml y tmp/tapas/ (m_Sitio.Escribir)
#
# QUÉ HACE
#   1. Verifica sitio.xml (bien formado) y cada tapa que nombra: el archivo
#      está, su nombre tiene la forma <id>-<sha8>.jpg y su sha256 es el que
#      dice el XML.
#   2. Prepara el logo y la imagen destacada de media/ (esquema gbweb
#      1.1.0): el logo tal cual, la imagen en su versión de pantalla. Sin
#      imagen elegida va la de por defecto; si la elegida falta, también,
#      con un aviso. Los publica con el comienzo de su sha256 en el nombre,
#      para que un cambio cambie la URL.
#   3. Pasa con Pandoc las páginas escritas (paginas/<clave>.<idioma>.md)
#      a tmp/paginas/, solo las de la matriz de menu.xml. La que falta se
#      crea con «Acá va el texto», como la imagen por defecto: así están
#      todas con su nombre, listas para escribir. Nunca se pisa una que ya
#      está.
#   4. Corre la XSLT del portal con Saxon en tmp/docs-nuevo/: todas las
#      páginas, en los tres idiomas, en una sola corrida (SC-80).
#   5. Copia las tapas, la hoja de estilo, las fuentes y las banderas.
#   6. Reemplaza docs/ entera por la nueva. docs/ ES DE gbWeb: lo que se ponga
#      ahí a mano se pierde en la próxima construcción.
#   7. Imprime la huella de docs/: con los mismos datos, la misma huella
#      (SC-80, DETERMINISMO).
#
# NO TOCA LA BASE (SC-13): todo lo que necesita lo dejó Gambas en tmp/.
# ============================================================================

set -uo pipefail

DIR_ENGINE="$(dirname "$(readlink -f "$0")")"
if ! source "$DIR_ENGINE/comun.sh"; then
    echo "No se pudo cargar $DIR_ENGINE/comun.sh" >&2
    exit 1
fi

# LAS HOJAS Y EL ESTILO, AL LADO DE engine/ (.hidden/ O /usr/share/gbweb/)
DIR_RECURSOS="$(dirname "$DIR_ENGINE")"
XSL_PORTAL="$DIR_RECURSOS/xslt/portal.xsl"
MENU_XML="$DIR_RECURSOS/xslt/menu.xml"
CSS_PORTAL="$DIR_RECURSOS/css/estilo.css"
DIR_SITIO="$DIR_RECURSOS/sitio"
IMAGEN_DEFECTO="$DIR_SITIO/imagen-por-defecto.png"

# --- 1. CONFIGURACIÓN ---
TIEMPO_SAXON=300

# ============================================================================
# ORQUESTACIÓN
# ============================================================================

encabezado "CONSTRUCCIÓN DEL SITIO"

# --- 2. ARGUMENTOS Y HERRAMIENTAS ---
(( $# == 1 )) || morir "Uso: construir_sitio.sh <ruta_portal>"
DIR_PORTAL="$1"
[[ -d "$DIR_PORTAL" ]] || morir "No existe la carpeta del portal: $DIR_PORTAL"
cd "$DIR_PORTAL" || morir "No se pudo entrar a la carpeta del portal: $DIR_PORTAL"

requerir_comandos java xmllint sha256sum timeout convert identify kpsewhich pandoc
[[ -f "$RUTA_SAXON" ]] || morir "No está Saxon-HE en $RUTA_SAXON"
[[ -f "$XSL_PORTAL" ]] || morir "No está la hoja del portal: $XSL_PORTAL"
[[ -f "$MENU_XML" ]] || morir "No está la matriz de páginas: $MENU_XML"
[[ -f "$CSS_PORTAL" ]] || morir "No está la hoja de estilo: $CSS_PORTAL"
[[ -f "$IMAGEN_DEFECTO" ]] || morir "No está la imagen por defecto: $IMAGEN_DEFECTO"
[[ -d "$DIR_SITIO/fuentes" && -d "$DIR_SITIO/banderas" ]] || morir "Faltan las fuentes o las banderas en $DIR_SITIO"

SITIO_XML="tmp/sitio.xml"
DIR_TAPAS="tmp/tapas"
DIR_NUEVO="tmp/docs-nuevo"
DIR_ANTERIOR="tmp/docs-anterior"

tenue "Portal: $(pwd)"

# --- 3. LOS DATOS ---
paso "Datos del portal"
[[ -f "$SITIO_XML" ]] || morir "No está $SITIO_XML: lo escribe gbWeb antes de lanzar este script."
xmllint --noout "$SITIO_XML" || morir "$SITIO_XML no está bien formado."
LIBROS=$(xmllint --xpath 'count(/sitio/libro)' "$SITIO_XML")
TAPAS=$(xmllint --xpath 'count(/sitio/libro/tapa)' "$SITIO_XML")
ok "sitio.xml bien formado: $LIBROS libro(s), $TAPAS tapa(s)"
(( LIBROS > 0 )) || aviso "El portal no tiene libros asociados: el catálogo sale vacío."

# --- 4. LAS TAPAS ---
# CADA TAPA QUE NOMBRA EL XML ESTÁ, CON NOMBRE SEGURO Y LOS BYTES QUE DICE
# SU sha256. EL NOMBRE SE CONTROLA PORQUE SE USA COMO RUTA
paso "Tapas"
for (( i = 1; i <= TAPAS; i++ )); do
    archivo=$(xmllint --xpath "string((/sitio/libro/tapa)[$i]/@archivo)" "$SITIO_XML")
    esperado=$(xmllint --xpath "string((/sitio/libro/tapa)[$i]/@sha256)" "$SITIO_XML")
    [[ "$archivo" =~ ^[0-9]+-[0-9a-f]{8}\.jpg$ ]] || morir "Nombre de tapa inesperado en sitio.xml: «$archivo»"
    [[ -f "$DIR_TAPAS/$archivo" ]] || morir "Falta la tapa $DIR_TAPAS/$archivo"
    real=$(sha256sum "$DIR_TAPAS/$archivo" | cut -d' ' -f1)
    [[ "$real" == "$esperado" ]] || morir "La tapa $archivo no tiene los bytes que dice la base (sha256 $real, se esperaba $esperado)."
    [[ "${archivo#*-}" == "${esperado:0:8}.jpg" ]] || morir "El nombre de la tapa $archivo no corresponde a su sha256."
done
(( TAPAS > 0 )) && ok "$TAPAS tapa(s) verificadas"

rm -rf "$DIR_NUEVO" || morir "No se pudo vaciar $DIR_NUEVO"
mkdir -p "$DIR_NUEVO/media" || morir "No se pudo crear $DIR_NUEVO"

# --- 5. EL LOGO Y LA IMAGEN DESTACADA ---
# LOS NOMBRES SE CONTROLAN COMO EN LOS CHECK DE LA BASE: SE USAN COMO RUTA
paso "Logo e imagen destacada"
LOGO=$(xmllint --xpath 'string(/sitio/@logo)' "$SITIO_XML")
IMAGEN=$(xmllint --xpath 'string(/sitio/@imagen)' "$SITIO_XML")
LOGO_PUBLICADO=""

if [[ -z "$LOGO" ]]; then
    tenue "Sin logo: la cabecera lleva el código del portal."
elif [[ ! "$LOGO" =~ ^logo-portal\.(svg|png|jpg)$ ]]; then
    morir "Nombre de logo inesperado en sitio.xml: «$LOGO»"
elif [[ ! -f "media/$LOGO" ]]; then
    aviso "El logo elegido (media/$LOGO) no está: la cabecera lleva el código del portal."
else
    # EL LOGO VA TAL CUAL: UN svg NO SE RASTERIZA, Y UN png O jpg DE LOGO
    # YA VIENE A SU MEDIDA
    huella=$(sha256sum "media/$LOGO" | cut -c1-8)
    LOGO_PUBLICADO="media/logo-portal-$huella.${LOGO##*.}"
    cp "media/$LOGO" "$DIR_NUEVO/$LOGO_PUBLICADO" || morir "No se pudo copiar el logo"
    ok "Logo: media/$LOGO"
fi

ORIGEN_IMAGEN="$IMAGEN_DEFECTO"
if [[ -z "$IMAGEN" ]]; then
    tenue "Sin imagen elegida: va la de por defecto."
elif [[ ! "$IMAGEN" =~ ^imagen-[0-9]{2,}\.(jpg|png)$ ]]; then
    morir "Nombre de imagen inesperado en sitio.xml: «$IMAGEN»"
elif [[ ! -f "media/$IMAGEN" ]]; then
    aviso "La imagen elegida (media/$IMAGEN) no está: va la de por defecto."
else
    ORIGEN_IMAGEN="media/$IMAGEN"
fi

if [[ "$ORIGEN_IMAGEN" == "$IMAGEN_DEFECTO" ]]; then
    # LA DE POR DEFECTO YA ESTÁ PREPARADA: SE COPIA
    TEMPORAL="tmp/destacada.png"
    cp "$IMAGEN_DEFECTO" "$TEMPORAL" || morir "No se pudo copiar la imagen por defecto"
else
    TEMPORAL="tmp/destacada.${ORIGEN_IMAGEN##*.}"
    imagen_pantalla "$ORIGEN_IMAGEN" "$TEMPORAL" || morir "No se pudo preparar media/$IMAGEN: $PANTALLA_NOTA"
    [[ -n "$PANTALLA_NOTA" ]] && tenue "$PANTALLA_NOTA"
fi
huella=$(sha256sum "$TEMPORAL" | cut -c1-8)
DESTACADA="media/destacada-$huella.${TEMPORAL##*.}"
mv -f "$TEMPORAL" "$DIR_NUEVO/$DESTACADA" || morir "No se pudo publicar la imagen destacada"
# EN DOS PASOS: identify NO TERMINA LA LÍNEA, Y read DEVOLVERÍA ERROR AUNQUE
# LEYERA LAS MEDIDAS
MEDIDAS=$(identify -format '%w %h' "$DIR_NUEVO/$DESTACADA" 2>/dev/null) \
    || morir "No se pudieron leer las medidas de la imagen destacada"
read -r DESTACADA_ANCHO DESTACADA_ALTO <<< "$MEDIDAS"
ok "Imagen destacada: ${ORIGEN_IMAGEN#$DIR_RECURSOS/} (${DESTACADA_ANCHO}×${DESTACADA_ALTO})"

# --- 5a. LOS DATOS DEL PORTAL ---
# SIN LA DIRECCIÓN DEL SITIO NO HAY BOTONES DE COMPARTIR NI VISTA PREVIA:
# LAS DOS COSAS NECESITAN DIRECCIONES COMPLETAS
paso "Datos para el pie y para compartir"
URL_BASE=$(xmllint --xpath 'string(/sitio/datos/url-base)' "$SITIO_XML")
NOMBRE=$(xmllint --xpath 'string(/sitio/datos/nombre)' "$SITIO_XML")
[[ -n "$NOMBRE" ]] && ok "Nombre: $NOMBRE" || aviso "Sin nombre del portal: va el código. Se carga en «Datos del portal»."
if [[ -n "$URL_BASE" ]]; then
    ok "Dirección del sitio: $URL_BASE"
else
    aviso "Sin dirección del sitio: no hay botones de compartir ni vista previa. Se carga en «Datos del portal»."
fi
REDES=$(xmllint --xpath 'count(/sitio/datos/red)' "$SITIO_XML")
tenue "Perfiles en las redes: $REDES"

# UN LIBRO INTEGRADO AL PORTAL LLEVA EN SU HTML LA CABECERA DEL PORTAL QUE
# DECLARA EN gbpublisher (url_portal). SI NO ES ESTE, SU CABECERA ES DE OTRO
# PORTAL: SE AVISA, NO SE FRENA. LA ASOCIACIÓN DE gbWeb DECIDE QUÉ LIBROS
# APARECEN; LA URL DEL LIBRO, SOLO SU CABECERA
if [[ -n "$URL_BASE" ]]; then
    mapfile -t AJENOS < <(xmllint --xpath "/sitio/libro[@destino='portal' and string(url-portal) != '$URL_BASE']/@id" "$SITIO_XML" 2>/dev/null | grep -oP 'id="\K[^"]+')
    if (( ${#AJENOS[@]} > 0 )); then
        aviso "Libro(s) ${AJENOS[*]}: integrados a otro portal según gbpublisher (url-portal distinta de $URL_BASE). Revisá el formulario del libro."
    fi
fi

# --- 5b. LAS PÁGINAS ESCRITAS ---
# SOLO LAS CLAVES DE LA MATRIZ DE ESTA CLASE DE PORTAL QUE SE ESCRIBEN (SIN
# genera). LA LISTA SALE DE menu.xml, LA MISMA QUE LEE LA XSLT
paso "Páginas escritas"
TIPO=$(xmllint --xpath 'string(/sitio/@tipo)' "$SITIO_XML")
mapfile -t CLAVES < <(xmllint --xpath "//tipo[@t='$TIPO']//item[not(@genera)]/@clave" "$MENU_XML" 2>/dev/null | grep -oP 'clave="\K[^"]+')
(( ${#CLAVES[@]} > 0 )) || morir "La matriz no tiene páginas escritas para «$TIPO»."
DIR_PAGINAS_TMP="tmp/paginas"
rm -rf "$DIR_PAGINAS_TMP" && mkdir -p "$DIR_PAGINAS_TMP" || morir "No se pudo preparar $DIR_PAGINAS_TMP"

# LO QUE HAY EN paginas/ Y NO CORRESPONDE A LA MATRIZ SE AVISA: UN NOMBRE MAL
# ESCRITO NO PUEDE QUEDAR AFUERA EN SILENCIO
if [[ -d paginas ]]; then
    for archivo in paginas/*; do
        [[ -e "$archivo" ]] || continue
        nombre="${archivo#paginas/}"
        if [[ "$nombre" =~ ^([a-z-]+)\.(es|en|pt)\.md$ ]] && [[ " ${CLAVES[*]} " == *" ${BASH_REMATCH[1]} "* ]]; then
            continue
        fi
        aviso "paginas/$nombre no corresponde a ninguna página de este portal: no se usa."
    done
fi

# LAS QUE FALTAN, CON EL TEXTO DE RELLENO (DECISIÓN DE ALBERTO)
TEXTO_RELLENO="Acá va el texto"
mkdir -p paginas || morir "No se pudo crear la carpeta paginas/ del portal."
creadas=0
for clave in "${CLAVES[@]}"; do
    for idioma in es en pt; do
        md="paginas/$clave.$idioma.md"
        [[ -e "$md" ]] && continue
        printf '%s\n' "$TEXTO_RELLENO" > "$md" || morir "No se pudo crear $md"
        creadas=$((creadas + 1))
    done
done
(( creadas > 0 )) && tenue "Creadas $creadas página(s) con «$TEXTO_RELLENO» en paginas/"

for clave in "${CLAVES[@]}"; do
    hay=()
    relleno=()
    for idioma in es en pt; do
        md="paginas/$clave.$idioma.md"
        [[ -f "$md" ]] || continue
        # LA QUE SIGUE CON EL RELLENO SE PUBLICA IGUAL, PERO SE SEÑALA
        [[ "$(cat "$md")" == "$TEXTO_RELLENO" ]] && relleno+=("$idioma")
        destino="$DIR_PAGINAS_TMP/$clave.$idioma.xml"
        # SIN HTML SUELTO (-raw_html): EL CONTENIDO QUEDA LIMPIO Y BIEN FORMADO.
        # LOS TÍTULOS DEL .md BAJAN UN NIVEL: EL h1 ES EL NOMBRE DE LA PÁGINA
        html=$(pandoc -f markdown-raw_html -t html5 --shift-heading-level-by=1 "$md") \
            || morir "Pandoc no pudo convertir $md"
        printf '<div>\n%s\n</div>\n' "$html" > "$destino" || morir "No se pudo escribir $destino"
        xmllint --noout "$destino" 2>/dev/null || morir "$md dio un HTML mal formado."
        grep -q '<img ' "$destino" && aviso "$md tiene imágenes: todavía no se publican."
        hay+=("$idioma")
    done
    if (( ${#hay[@]} == 0 )); then
        tenue "$clave: sin escribir"
    elif [[ ! -f "paginas/$clave.es.md" ]]; then
        # SIN EL ESPAÑOL LA PÁGINA NO EXISTE, AUNQUE ESTÉN LAS TRADUCCIONES
        aviso "$clave: falta paginas/$clave.es.md; sin él la página no sale (hay ${hay[*]})."
    elif (( ${#relleno[@]} > 0 )); then
        tenue "$clave: ${hay[*]} (sin escribir todavía: ${relleno[*]})"
    else
        ok "$clave: ${hay[*]}"
    fi
done

# --- 5c. LA HOJA DE ESTILO, CON SU HUELLA EN EL NOMBRE ---
# COMO LAS TAPAS Y LA IMAGEN: SI LA HOJA CAMBIA, CAMBIA SU NOMBRE, Y NINGÚN
# NAVEGADOR NI SERVIDOR (GitHub Pages GUARDA COPIA UNOS MINUTOS) SIGUE
# MOSTRANDO LA VIEJA. CON LA MISMA HOJA, EL MISMO NOMBRE (SC-80)
ESTILO="estilo-$(sha256sum "$CSS_PORTAL" | cut -c1-8).css"

# --- 6. LA TRANSFORMACIÓN ---
paso "Páginas (Saxon)"
# -o: ES EL INICIO EN ESPAÑOL; LAS DEMÁS SALEN CON xsl:result-document,
# RELATIVAS A ÉL
if ! timeout "$TIEMPO_SAXON" java -jar "$RUTA_SAXON" \
        -s:"$SITIO_XML" -xsl:"$XSL_PORTAL" -o:"$DIR_NUEVO/index.html" estilo="$ESTILO" \
        logo="$LOGO_PUBLICADO" destacada="$DESTACADA" \
        destacada_ancho="$DESTACADA_ANCHO" destacada_alto="$DESTACADA_ALTO"; then
    morir "La transformación falló. El detalle de Saxon está arriba."
fi
PAGINAS=$(find "$DIR_NUEVO" -name '*.html' -type f | wc -l)
ok "$PAGINAS página(s)"

# --- 7. TAPAS, ESTILO, FUENTES Y BANDERAS ---
paso "Recursos"
if (( TAPAS > 0 )); then
    mkdir -p "$DIR_NUEVO/tapas" || morir "No se pudo crear $DIR_NUEVO/tapas"
    for (( i = 1; i <= TAPAS; i++ )); do
        archivo=$(xmllint --xpath "string((/sitio/libro/tapa)[$i]/@archivo)" "$SITIO_XML")
        cp "$DIR_TAPAS/$archivo" "$DIR_NUEVO/tapas/$archivo" || morir "No se pudo copiar la tapa $archivo"
    done
fi
cp "$CSS_PORTAL" "$DIR_NUEVO/$ESTILO" || morir "No se pudo copiar la hoja de estilo"
# LAS FUENTES CON SU LICENCIA: LA OFL PIDE QUE VIAJE CON ELLAS. EL LEEME NO
mkdir -p "$DIR_NUEVO/fuentes" "$DIR_NUEVO/banderas" || morir "No se pudieron crear fuentes/ y banderas/"
cp "$DIR_SITIO"/fuentes/*.woff2 "$DIR_SITIO/fuentes/OFL.txt" "$DIR_NUEVO/fuentes/" || morir "No se pudieron copiar las fuentes"
cp "$DIR_SITIO"/banderas/*.png "$DIR_NUEVO/banderas/" || morir "No se pudieron copiar las banderas"
# LOS ÍCONOS PNG VAN COMO ARCHIVO (EL DE ORCID); LOS SVG VAN DENTRO DE CADA
# PÁGINA Y NO SE COPIAN
mkdir -p "$DIR_NUEVO/iconos" || morir "No se pudo crear iconos/"
cp "$DIR_SITIO"/iconos/*.png "$DIR_NUEVO/iconos/" || morir "No se pudieron copiar los íconos"
ok "Tapas, estilo, fuentes y banderas copiados"

# --- 8. EL REEMPLAZO DE docs/ ---
# PRIMERO SE APARTA LA VIEJA Y DESPUÉS SE PONE LA NUEVA: SI ALGO FALLA EN EL
# MEDIO, LA VIEJA ESTÁ ENTERA EN tmp/docs-anterior
paso "docs/"
rm -rf "$DIR_ANTERIOR" || morir "No se pudo vaciar $DIR_ANTERIOR"
if [[ -e docs ]]; then
    mv docs "$DIR_ANTERIOR" || morir "No se pudo apartar la docs/ anterior."
fi
if ! mv "$DIR_NUEVO" docs; then
    [[ -e "$DIR_ANTERIOR" ]] && mv "$DIR_ANTERIOR" docs
    morir "No se pudo poner la docs/ nueva; quedó la anterior."
fi
rm -rf "$DIR_ANTERIOR"
ok "docs/ reemplazada"

# --- 9. LA HUELLA ---
# DOS CONSTRUCCIONES SIN CAMBIOS EN LOS DATOS TIENEN QUE DAR LA MISMA
paso "Huella"
tenue "docs/  $(huella_carpeta docs)"

echo
ok "Sitio construido: $(pwd)/docs/index.html"
terminar
