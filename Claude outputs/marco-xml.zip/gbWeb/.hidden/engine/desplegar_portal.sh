#!/bin/bash
# Despliegue del portal en GitHub — gbWeb
# ============================================================================
# Vive en /usr/share/gbweb/engine/ (o en .hidden/engine/ desde el IDE).
#
# USO
#   desplegar_portal.sh <ruta_portal> <usuario_github> <codigo> <mensaje>
#
#   ruta_portal      la carpeta del L-ALGO.md o R-ALGO.md
#   usuario_github   el dueño del repositorio
#   codigo           el código del portal (L-IMAGO): el repositorio se llama
#                    igual (SC-80)
#   mensaje          el mensaje del commit
#
# QUÉ HACE (EL PUSH DE gbpublisher, m_GitHub.EjecutarPushGitHub, EN UN
# SCRIPT: ASÍ GAMBAS SABE CÓMO TERMINÓ)
#   1. Comprueba la clave SSH contra GitHub.
#   2. Si la carpeta no es un repositorio, lo inicia con la rama main.
#   3. Deja tmp/ fuera de git (.gitignore): es material de trabajo. Y
#      deja netlify.toml con «Pretty URLs» apagado (ver el apartado 3).
#   4. Si no hay remoto, agrega git@github.com:<usuario>/<codigo>.git.
#   5. git add, commit (si hay cambios) y push a main.
#
# El repositorio en GitHub tiene que existir: este script no lo crea.
# No toca la base (SC-13).
# ============================================================================

set -uo pipefail

DIR_ENGINE="$(dirname "$(readlink -f "$0")")"
if ! source "$DIR_ENGINE/comun.sh"; then
    echo "No se pudo cargar $DIR_ENGINE/comun.sh" >&2
    exit 1
fi

TIEMPO_SSH=20

encabezado "DESPLIEGUE DEL PORTAL"

# --- 1. ARGUMENTOS Y HERRAMIENTAS ---
(( $# == 4 )) || morir "Uso: desplegar_portal.sh <ruta_portal> <usuario_github> <codigo> <mensaje>"
DIR_PORTAL="$1"
USUARIO="$2"
CODIGO="$3"
MENSAJE="$4"

requerir_comandos git ssh timeout
[[ -d "$DIR_PORTAL" ]] || morir "No existe la carpeta del portal: $DIR_PORTAL"
# EL USUARIO Y EL CÓDIGO VAN EN LA URL: SOLO SUS FORMAS VÁLIDAS (LA DEL
# USUARIO, LA DE GITHUB; LA DEL CÓDIGO, LA DEL CHECK DE gbweb.portal)
[[ "$USUARIO" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,37}[A-Za-z0-9])?$ ]] || morir "Usuario de GitHub inválido: «$USUARIO»"
[[ "$CODIGO" =~ ^[LR]-[A-Za-z0-9_-]+$ ]] || morir "Código de portal inválido: «$CODIGO»"
[[ -n "${MENSAJE// /}" ]] || morir "Falta el mensaje del commit."
cd "$DIR_PORTAL" || morir "No se pudo entrar a la carpeta del portal."
[[ -f docs/index.html ]] || morir "El portal no tiene sitio construido (docs/index.html)."

REMOTO="git@github.com:$USUARIO/$CODIGO.git"
tenue "Portal: $(pwd)"

# --- 2. LA CLAVE SSH ---
# ssh -T CONTRA GITHUB SALE CON 1 AUN CUANDO AUTENTICA: SE MIRA EL TEXTO
paso "Acceso a GitHub"
SALIDA_SSH=$(timeout "$TIEMPO_SSH" ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new -T git@github.com 2>&1)
if [[ "$SALIDA_SSH" == *"successfully authenticated"* ]]; then
    ok "GitHub acepta la clave SSH"
elif [[ "$SALIDA_SSH" == *"Permission denied"* ]]; then
    morir "GitHub rechazó la clave SSH. Cargá la clave pública en GitHub → Settings → SSH and GPG keys."
else
    morir "No se pudo conectar con GitHub por SSH: $SALIDA_SSH"
fi

# --- 3. EL REPOSITORIO LOCAL ---
paso "Repositorio"
if [[ ! -d .git ]]; then
    git init --initial-branch=main >/dev/null || morir "No se pudo iniciar el repositorio."
    ok "Repositorio iniciado (rama main)"
fi

# tmp/ ES MATERIAL DE TRABAJO (sitio.xml, TAPAS, docs-anterior): NO VIAJA
if ! grep -qxF '/tmp/' .gitignore 2>/dev/null; then
    printf '/tmp/\n' >> .gitignore || morir "No se pudo escribir .gitignore"
    ok "tmp/ fuera de git (.gitignore)"
fi

# NETLIFY NO REESCRIBE LO QUE PUBLICA (DECISIÓN DE ALBERTO, 07/11/2026). CON
# «PRETTY URLS» CAMBIA LOS ENLACES …/index.html POR …/ EN CADA .html SERVIDO
# (MEDIDO EL 07/11 EN L-IMAGO): LO PUBLICADO DEJA DE SER LO CONSTRUIDO, Y EL
# MARCO DE LOS LIBROS LLEGABA CON OTRO sha256. EL ARCHIVO PISA EL INTERRUPTOR
# DEL PANEL DE NETLIFY (docs.netlify.com, «File-based configuration»). VA EN LA
# RAÍZ DEL REPOSITORIO, AL LADO DE docs/, QUE construir_sitio.sh REEMPLAZA
# ENTERA. SI YA EXISTE, NO SE PISA: SE AVISA SI NO APAGA PRETTY URLS
if [[ ! -f netlify.toml ]]; then
    printf '# Lo escribe gbWeb (desplegar_portal.sh): Netlify publica docs/ sin reescribirlo.
[build.processing.html]
  pretty_urls = false
' > netlify.toml ||
        morir "No se pudo escribir netlify.toml"
    ok "netlify.toml: Netlify no reescribe los .html (pretty_urls = false)"
elif ! grep -Eq '^[[:space:]]*pretty_urls[[:space:]]*=[[:space:]]*false' netlify.toml; then
    aviso "netlify.toml no apaga «Pretty URLs» (pretty_urls = false en [build.processing.html]): Netlify va a reescribir los .html y el marco de los libros no va a coincidir con su sha256."
fi

# git config Y NO git remote get-url: get-url DEVUELVE LA URL YA REESCRITA
# POR UN url.<x>.insteadOf, Y LA COMPARACIÓN DARÍA DISTINTO SIN SERLO
ORIGEN=$(git config --get remote.origin.url 2>/dev/null)
if [[ -n "$ORIGEN" ]]; then
    tenue "Remoto: $ORIGEN"
    [[ "$ORIGEN" == "$REMOTO" ]] || aviso "El remoto no es $REMOTO: se empuja al que ya está configurado."
else
    git remote add origin "$REMOTO" || morir "No se pudo agregar el remoto $REMOTO"
    ok "Remoto: $REMOTO"
fi

if [[ "$(git symbolic-ref --short HEAD 2>/dev/null)" != "main" ]]; then
    git branch -M main || morir "No se pudo pasar a la rama main."
    ok "Rama main"
fi

# --- 4. COMMIT ---
paso "Commit"
git add -A || morir "git add falló."
if git diff --cached --quiet; then
    tenue "No hay cambios para guardar: se empuja lo que ya está."
else
    # SIN user.name O user.email CONFIGURADOS, git NO HACE EL COMMIT
    git commit -q -m "$MENSAJE" || morir "El commit falló. Si git pide nombre y correo: git config --global user.name y user.email."
    ok "Commit: $(git log -1 --format='%h %s')"
fi

# --- 5. PUSH ---
paso "Push"
if ! git push --set-upstream origin main; then
    morir "El push falló. Si dice «Repository not found», creá el repositorio $CODIGO en GitHub (vacío) y volvé a desplegar."
fi
ok "Portal en $REMOTO"

echo
terminar
