# Lote 3, corrección: vnu no valida los fragmentos del marco (5/11/2026)

## El error

La validación HTML5 recorría todo `docs/`, y con el lote 3 eso incluye `docs/assets/marco/<idioma>/cabecera.html` y `pie.html`. Esos dos archivos no son páginas:

- son XML sin doctype, para que la hoja los lea con `doc()`;
- los enlaces para compartir traen `{u}` y `{t}`, que la hoja completa al copiarlos en cada página.

Los 36 errores son todos de ahí. Las páginas del libro estaban bien: en el contenedor las había validado una por una, y por eso no lo vi.

## El cambio

Un solo archivo, `.hidden/engine/generar_html_libro.sh`. Va completo en el zip, o aplicá este parche.

En el archivo `generar_html_libro.sh`, sección de orquestación, en el apartado 9 («VALIDACIÓN HTML5»), reemplazá:

```bash
    salida=$(timeout "$TIEMPO_VNU" java -jar "$RUTA_VNU" \
                --format gnu --errors-only --skip-non-html "$DIR_DOCS/" 2>&1)
```

por:

```bash
    # LOS FRAGMENTOS DEL MARCO (assets/marco/<idioma>/*.html) NO SON PÁGINAS:
    # SON XML SIN DOCTYPE, Y COMPARTIR LLEVA {u} Y {t}, QUE LA HOJA COMPLETA
    # AL COPIARLOS. vnu RECIBE TODOS LOS .html DE docs/ MENOS ESOS; CON EL
    # DESTINO AUTÓNOMO NO HAY MARCO Y LA LISTA ES LA DE SIEMPRE (INCLUIDOS LOS
    # GRÁFICOS DE assets/media/, SC-69)
    mapfile -t PAGINAS_VNU < <(find "$DIR_DOCS" -type f -name '*.html' \
                                    -not -path "$DIR_MARCO/*" | LC_ALL=C sort)
    salida=$(timeout "$TIEMPO_VNU" java -jar "$RUTA_VNU" \
                --format gnu --errors-only --skip-non-html "${PAGINAS_VNU[@]}" 2>&1)
```

`DIR_MARCO` ya está definida en el apartado 2. Con el destino autónomo no hay marco, así que la lista es la de antes, incluidos los gráficos interactivos de `assets/media/`.

## Verificado en el contenedor, con vnu instalado en `/opt/vnu/vnu.jar` como en Mint

- **Destino portal:** «✓ HTML5 sin errores», código 0.
- **Destino autónomo:** «✓ HTML5 sin errores».
- **Un error puesto a propósito en una página:** vnu lo informa, así que la página sigue validándose.
