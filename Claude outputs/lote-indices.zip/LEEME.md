# Lote 1 de índices (SC-77) — solo PDF, libros

Base: los archivos de tu disco al 30/10/2026, 17:30 aprox. Antes de copiar, mirá
que no hayas tocado alguno de estos después de esa hora: el lote los reemplaza
enteros. `lote-indices.diff` tiene cada cambio, para revisarlo línea por línea.

Todos los archivos dependen entre sí: se aplican juntos y después se recompila.

## Archivos

Nuevos

- `.hidden/filters/indice.lua` — la marca del .md a `<indexterm>` (con su xml:id).
- `.hidden/engine/gbindice.xdy` — declara para xindy `gbIndPrincipal` y `gbIndNota` (GV-160).

Modificados

- `.hidden/engine/comun.sh` — `indice.lua` en `FILTROS_LIBRO`, después de `cifras.lua` (4b°).
- `.hidden/engine/controles_md.lua` — `PATRONES_LATEX` admite `\index`; el mensaje de `latex_en_linea` lo nombra.
- `.hidden/engine/compilar_latex_comun.sh` — xindy con `-L spanish-modern -C utf8` (GV-158) y `-M gbindice.xdy`; sin respaldo a otro `.xdy`; aviso de «unknown attribute».
- `.hidden/xslt/docbook-to-latex.xsl` — plantillas de `indexterm` (formato explícito, escapes de xindy, clave plana cuando hay `\emph`).
- `.hidden/xslt/docbook-to-html.xsl`, `docbook-to-epub.xsl` — `indexterm` vacío en todos los modos.
- `.hidden/xslt/ensamblar-capitulo-canonico.xsl` — prefija `@startref` como `@linkend`; fuera el código muerto de `indice_tematico` / `indice_analitico`.
- `.hidden/latex/preambulo-contrato.tex` — contrato 18: `\gbIndNota`, `\gbIndPrincipal`; el índice `names` agrega `|hyperpage` (`\gbIndiceNombre`).
- `.hidden/latex/preambulo-hyperref.tex` — `hyperindex=false` en las dos ramas (GV-159).
- `.hidden/themes/Markdown.highlight` — `$(orden)` resalta `\index`.
- `.src/m_GenerarPDFLibro.module` — `CONTRATO_VERSION = 18` y el comentario que decía «PENDIENTE MAYOR».
- `.src/m_PiezasLibro.module` — comentario de la condición de los índices (SC-77).

## Reglas nuevas que no habíamos hablado (decidí yo; confirmalas)

1. **`\emph{…}` es la única orden admitida adentro de una entrada** (títulos de obras: `Borges, Jorge Luis!\emph{Ficciones}`). Cualquier otra frena. Sin clave `@`, xindy ordena por el texto plano.
2. **No va en el pie ni en la imagen de una figura, ni en el pie de un cuadro.** El pie se copia a la lista de figuras/cuadros y desde ahí se indexaría otra vez, con la página de la lista.
3. **No va sola en un párrafo** (quedaría un párrafo vacío).
4. **Misma página, dos marcas** (medido): principal y común → la página en negrita; común y en nota → la página sin «n.».

## Probado en el contenedor

Pandoc 3.1.3, SaxonJ-HE 12.5, jing, LuaLaTeX (TeX Live 2023), xindy de Ubuntu 24.04:
`generar_canonicos_capitulos.sh` real sobre un proyecto de prueba → canónico válido
contra el RNG 5.2 (rango con `startref` prefijado) → `docbook-to-latex.xsl` → PDF con
los dos índices; el EPUB no muestra los términos; los casos que frenan dan su mensaje.
No probé `vista_cuadro.sh` ni el preámbulo completo de un libro real.

## Para probar en Mint

Un capítulo real con:

    Borges\index[onomastico]{Borges, Jorge Luis!infancia} nació …
    *Ficciones*\index[onomastico]{Borges, Jorge Luis!\emph{Ficciones}}
    la democracia\index[concepto]{democracia!liberal|(} … \index[concepto]{democracia!liberal|)}
    la universidad\index[concepto]{universidad|see{educación superior}}
    educación superior\index[concepto]{educación superior|seealso{universidad}}\index[concepto]{educación superior|textbf}
    De la Torre\index[onomastico]{Torre Lisandro@Torre, Lisandro de la}, ¡Absalón\index[onomastico]{¡Absalón, Absalón\!}
    una nota.[^1]

    [^1]: Sarmiento\index[onomastico]{Sarmiento, Domingo F.}.

y las piezas `indice_onomastico` e `indice_concepto` declaradas. Mirar:

- el orden (Ávila después de Avellaneda; Ñ en su grupo) — también en el índice de autores;
- «23 n.», el rango «3–7», la negrita, «véase» y «véase también»;
- los enlaces de las páginas, en los tres índices;
- el resaltado de `\index` en el editor (el patrón tiene un nivel de llaves anidado; gb.highlight no lo probé);
- un caso que frena: `## Título\index[concepto]{x}`.

## Lo que queda afuera de este lote

- Las dos filas de gbShortcodes (`index-onomastico`, `index-concepto`; borrador en libros, `no_aplica` en revistas): necesito la carpeta de gbShortcodes.
- La act del corpus que actualiza SC-54 (dos órdenes admitidas más) y el pendiente de SC-77: después de tu prueba, como siempre.
