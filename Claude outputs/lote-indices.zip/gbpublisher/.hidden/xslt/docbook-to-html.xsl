<?xml version="1.0" encoding="UTF-8"?>
<!--
=========================================================
docbook-to-html.xsl — Generación HTML del libro completo
=========================================================
UBICACIÓN: ~/.gbpublisher/xslt/docbook-to-html.xsl

VERSIÓN: Fase 1 (solo index.html — portada del libro).

PROPÓSITO GENERAL:
  Transforma el canónico DocBook 5.2 del libro completo
  (jats/c-libro-{nombre}.xml) en una salida HTML multi-página
  para GitHub Pages. Todas las páginas comparten CSS/JS externo
  en docs/assets/ para minimizar tamaño y facilitar mantenimiento.

FUENTES DE ENTRADA:
  - Fuente principal: canónico ensamblado del libro.
  - Parámetro manifiesto_libro: ruta al manifiesto para mapear
    xml:id → nombre_archivo de cada capítulo.
  - Parámetro proyecto_dir: para construir paths absolutos si
    hicieran falta (por ahora no se usa; queda declarado para
    fases futuras).

SALIDAS DE FASE 1:
  - docs/index.html: portada del libro con
    * layout de 2 columnas (col-left + col-center, sin col-right)
    * metadatos HTML: Highwire Press, DC, OG, Twitter Cards
    * col-left: tapa, ISBN(s), autores, editorial, DOI, colección/serie,
      licencia, fecha de publicación en cascada
    * col-center: título, subtítulo, autoría, resumen (si hay),
      keywords, lista de capítulos con enlaces a h-{nombre}.html

FASES POSTERIORES (no implementadas todavía):
  - Fase 2: páginas h-{nombre_archivo}.html de cada capítulo
  - Fase 3: drawer con refs/notas/figs
  - Fase 4: metadatos HTML por capítulo
  - Fase 5: widget "Citar este libro/capítulo"

RC APLICADAS:
  - RC-XJ-01: idioma en cascada (idioma_principal → 'es' default)
  - RC-DB-08: copy-namespaces="no" cuando aplique
  - Fecha en cascada: fecha_publicacion_completa → mes+año → año → nada
=========================================================
-->
<xsl:stylesheet version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:db="http://docbook.org/ns/docbook"
                xmlns="http://www.w3.org/1999/xhtml"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:nl="urn:gbpublisher:numeracion-libro"
                xmlns:gbc="urn:gbpublisher:codigo"
                xmlns:gbv="urn:gbpublisher:conversacion"
                xmlns:gbvr="urn:gbpublisher:verso"
                xmlns:gbct="urn:gbpublisher:citas"
                xmlns:gbg="urn:gbpublisher:grafico"
                exclude-result-prefixes="db xs xlink nl gbc gbv gbvr gbct gbg">

  <!-- NIVELADO DE COMILLAS POR PROFUNDIDAD. ES LA ÚNICA REGLA DEL PROYECTO:
       NO DEFINIR ACÁ OTRA PLANTILLA PARA db:quote. SIN ESTE INCLUDE, <quote>
       CAE EN EL CATCH-ALL match="*" Y LAS COMILLAS DESAPARECEN -->
  <xsl:include href="quote.xsl"/>

  <!-- MARCA DE LOS EDITORES QUE OCUPAN EL LUGAR DEL AUTOR: (Ed.), (Comp.)...
       ES LA ÚNICA REGLA DE LAS SALIDAS DIGITALES; NO DUPLICARLA ACÁ -->
  <xsl:include href="marca-editor.xsl"/>

  <!-- NÚMERO DE FIGURA Y REFERENCIAS CRUZADAS: LA MISMA REGLA QUE EL PDF
       Y QUE EL EPUB (SC-31). NO DUPLICARLA ACÁ -->
  <xsl:include href="numeracion-libro.xsl"/>

  <!-- LAS REGLAS DEL CÓDIGO COMUNES A LAS SEIS SALIDAS (SC-42) -->
  <xsl:include href="codigo-comun.xsl"/>

  <!-- CONVERSACIÓN (SC-43): LA ETIQUETA DE CADA TURNO, COMÚN A LAS SEIS HOJAS -->
  <xsl:include href="conversacion-comun.xsl"/>

  <!-- VERSO (SC-49): ESTROFAS, VERSOS Y SANGRÍA, COMÚN A LAS SEIS HOJAS -->
  <xsl:include href="verso-comun.xsl"/>

  <!-- CITAS (SC-57): EL AGRUPAMIENTO Y EL id DE CADA GRUPO, LOS MISMOS QUE
       EL PDF, Y LA LECTURA DE citas.html (PARÁMETRO bib_dir) -->
  <xsl:include href="cita-comun.xsl"/>
  <xsl:include href="cita-fragmentos.xsl"/>

  <!-- GRÁFICOS (SC-69): LA FIGURA INTERACTIVA, COMÚN A LAS DOS HOJAS DE HTML -->
  <xsl:include href="grafico-comun.xsl"/>

  <!-- Output principal: no se usa en Fase 1 (todo va por xsl:result-document) -->
  <xsl:output method="xml"
              encoding="UTF-8"
              indent="yes"
              omit-xml-declaration="yes"/>

  <!-- Formato específico para archivos HTML de salida -->
  <xsl:output name="html5"
              method="html"
              encoding="UTF-8"
              indent="yes"
              doctype-system="about:legacy-compat"
              omit-xml-declaration="yes"/>

  <!-- ==========================================================
       PARÁMETROS DE ENTRADA
       ========================================================== -->
  <xsl:param name="proyecto_dir" as="xs:string" required="yes"/>
  <xsl:param name="manifiesto_libro" as="xs:string" required="yes"/>

  <!-- ESTILO DE CITA: EL IDENTIFICADOR DE libros_md.estilo_cita, QUE
       RESUELVE m_GenerarSalidasLibro.ResolverEstiloCita. DEFAULT 'apa'.
       CON bib_dir (cita-fragmentos.xsl) LAS CITAS Y LAS REFERENCIAS SALEN
       DE citas.html Y EL ESTILO SOLO DECIDE EL AGRUPAMIENTO (cita-comun.xsl).
       SIN bib_dir LAS ARMAN LAS PLANTILLAS DE ESTA HOJA, QUE SOLO EXISTEN
       PARA 'apa' | 'vancouver' | 'iso690' | 'ieee': CON OTRO ESTILO LA HOJA
       SE CORTA (PLANTILLA RAÍZ). -->
  <xsl:param name="estilo_cita" as="xs:string" select="'apa'"/>

  <!-- CARPETA DE LOS BLOQUES DE CÓDIGO COLOREADOS POR colorear_codigo.sh
       (SC-42), COMO RUTA ABSOLUTA. VACÍA: EL CÓDIGO SALE SIN COLOR.
       generar_html_libro.sh LA PASA SIEMPRE -->
  <xsl:param name="codigo_dir" as="xs:string" select="''"/>

  <!-- ==========================================================
       CARGA DEL MANIFIESTO Y KEY PARA MAPEAR xml:id → nombre_archivo
       ========================================================== -->
  <xsl:variable name="manifiesto"
                select="doc(concat($proyecto_dir, '/', $manifiesto_libro))"/>

  <!-- COLOFÓN DIGITAL PARA EL PIE DE PÁGINA. LO ESCRIBE GAMBAS EN
       tmp/colofon-digital.xml ANTES DE LANZAR LA TRANSFORMACIÓN, CON EL
       MISMO TEXTO QUE LA PÁGINA DE COLOFÓN DEL EPUB (m_PiezasLibro).
       EL SCRIPT VERIFICA QUE EXISTA: SI FALTARA, ESTA HOJA OMITIRÍA EL PIE
       SIN DECIR NADA. EL <p> YA VIENE EN EL NAMESPACE DE XHTML. -->
  <xsl:variable name="colofon_ruta"
                select="concat($proyecto_dir, '/tmp/colofon-digital.xml')"/>
  <xsl:variable name="colofon_digital"
                select="if (doc-available($colofon_ruta))
                        then doc($colofon_ruta)/colofon/*
                        else ()"/>

  <!-- Genera un mapeo directo: al buscar la key con el xml_id de un capítulo
       ('cap-7'), retorna el nodo <capitulo> del manifiesto que tiene
       @id_capitulo='7'. De ahí se lee el @nombre_archivo. -->
  <xsl:key name="cap-por-id"
           match="capitulo"
           use="concat('cap-', @id_capitulo)"/>

  <!-- LAS PIEZAS DEL LIBRO EN ORDEN, PARA numeracion-libro.xsl -->
  <xsl:variable name="piezasLibro" as="element()*"
                select="/*/descendant::*[nl:es-pieza(.)]"/>

  <!-- ==========================================================
       VARIABLES GLOBALES DERIVADAS DEL <book>
       ========================================================== -->
  <xsl:variable name="book" select="/db:book | /book"/>
  <xsl:variable name="info" select="$book/db:info | $book/info"/>

  <xsl:variable name="idioma_principal" as="xs:string">
    <xsl:choose>
      <xsl:when test="normalize-space($book/@xml:lang) != ''">
        <xsl:value-of select="$book/@xml:lang"/>
      </xsl:when>
      <xsl:otherwise>es</xsl:otherwise>
    </xsl:choose>
  </xsl:variable>

  <xsl:variable name="titulo_libro" as="xs:string">
    <xsl:value-of select="normalize-space($info/db:title[not(@role)] | $info/title[not(@role)])"/>
  </xsl:variable>

  <xsl:variable name="subtitulo" as="xs:string">
    <xsl:value-of select="normalize-space($info/db:subtitle | $info/subtitle)"/>
  </xsl:variable>

  <xsl:variable name="doi_libro" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:biblioid[@class='doi'] | $info/biblioid[@class='doi'])[1])"/>
  </xsl:variable>

  <!-- URLs DE DESCARGA (LIBRO COMPLETO): LAS EMITE GenerarInfoLibroXML
       COMO bibliomisc DESDE libros_md.url_descarga_pdf/epub. -->
  <xsl:variable name="url_descarga_pdf" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:bibliomisc[@role='url-descarga-pdf']
       | $info/bibliomisc[@role='url-descarga-pdf'])[1])"/>
  </xsl:variable>

  <xsl:variable name="url_descarga_epub" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:bibliomisc[@role='url-descarga-epub']
       | $info/bibliomisc[@role='url-descarga-epub'])[1])"/>
  </xsl:variable>

  <xsl:variable name="isbn_print" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:biblioid[@class='isbn'][@role='print']
       | $info/biblioid[@class='isbn'][@role='print'])[1])"/>
  </xsl:variable>

  <xsl:variable name="isbn_electronic" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:biblioid[@class='isbn'][@role='electronic']
       | $info/biblioid[@class='isbn'][@role='electronic'])[1])"/>
  </xsl:variable>

  <xsl:variable name="editorial" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:publisher/db:publishername
       | $info/publisher/publishername)[1])"/>
  </xsl:variable>

  <xsl:variable name="ciudad_pub" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:publisher/db:address/db:city
       | $info/publisher/address/city)[1])"/>
  </xsl:variable>

  <xsl:variable name="pais_pub" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:publisher/db:address/db:country
       | $info/publisher/address/country)[1])"/>
  </xsl:variable>

  <!-- Fecha de publicación en cascada:
       1. pubdate[@role='completa'] (ISO YYYY-MM-DD)
       2. pubdate sin role (año)
       3. bibliomisc[@role='mes-publicacion'] + pubdate (año)
       4. vacío -->
  <xsl:variable name="fecha_completa" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:pubdate[@role='completa'] | $info/pubdate[@role='completa'])[1])"/>
  </xsl:variable>

  <xsl:variable name="anio_publicacion" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:pubdate[not(@role)] | $info/pubdate[not(@role)])[1])"/>
  </xsl:variable>

  <xsl:variable name="mes_publicacion" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:bibliomisc[@role='mes-publicacion']
       | $info/bibliomisc[@role='mes-publicacion'])[1])"/>
  </xsl:variable>

  <!-- Año para CITACIÓN: prioriza el año de la fecha_completa (que refleja
       la última publicación, el objeto que se cita), y cae al pubdate sin
       role solo si no hay fecha completa. Un libro puede tener pubdate=2006
       (papel original) y fecha_completa=2026-07-04 (HTML/EPUB): se cita 2026. -->
  <xsl:variable name="anio_cita" as="xs:string">
    <xsl:choose>
      <xsl:when test="$fecha_completa != ''">
        <!-- EXTRAER LOS 4 DÍGITOS DEL AÑO DE UNA FECHA ISO YYYY-MM-DD -->
        <xsl:value-of select="substring($fecha_completa, 1, 4)"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$anio_publicacion"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:variable>

  <!-- Fecha "amigable" para mostrar en col-left, según cascada -->
  <xsl:variable name="fecha_display" as="xs:string">
    <xsl:choose>
      <xsl:when test="$fecha_completa != ''">
        <xsl:value-of select="$fecha_completa"/>
      </xsl:when>
      <xsl:when test="$mes_publicacion != '' and $anio_publicacion != ''">
        <xsl:value-of select="concat($mes_publicacion, ' ', $anio_publicacion)"/>
      </xsl:when>
      <xsl:when test="$anio_publicacion != ''">
        <xsl:value-of select="$anio_publicacion"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:text></xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:variable>

  <!-- Tapa del libro: en el canónico está como ../media/{archivo}
       (relativa desde jats/). En HTML va como assets/media/{archivo}. -->
  <xsl:variable name="imagen_tapa" as="xs:string">
    <xsl:variable name="fileref"
                  select="($info/db:mediaobject[@role='tapa']/db:imageobject/db:imagedata/@fileref
                          | $info/mediaobject[@role='tapa']/imageobject/imagedata/@fileref)[1]"/>
    <xsl:choose>
      <xsl:when test="$fileref != ''">
        <!-- Extraer solo el nombre del archivo -->
        <xsl:value-of select="concat('assets/media/',
                                    tokenize($fileref, '/')[last()])"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:text></xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:variable>

  <xsl:variable name="url_libro" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:bibliomisc[@role='url-libro']
       | $info/bibliomisc[@role='url-libro'])[1])"/>
  </xsl:variable>

  <xsl:variable name="licencia_texto" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:legalnotice[@role='licencia']/db:para[1]
       | $info/legalnotice[@role='licencia']/para[1])[1])"/>
  </xsl:variable>

  <xsl:variable name="licencia_url" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:legalnotice[@role='licencia']/db:para/db:link/@xlink:href
       | $info/legalnotice[@role='licencia']/para/link/@xlink:href)[1])"/>
  </xsl:variable>

  <xsl:variable name="resumen_libro" as="xs:string">
    <xsl:value-of select="normalize-space(
      ($info/db:abstract[not(@role='traducido')]/db:para
       | $info/abstract[not(@role='traducido')]/para)[1])"/>
  </xsl:variable>

  <!-- ==========================================================
       TEMPLATE PRINCIPAL: MATCH /
       ==========================================================
       En Fase 1 solo emite index.html.
       En fases futuras acá también se disparan xsl:result-document
       para cada capítulo. -->
  <xsl:template match="/">
    <!-- 0. ESTILO SIN CAMINO: NI citas.html NI PLANTILLAS PROPIAS. ANTES
         CAÍA EN UN AUTOR-AÑO GENÉRICO QUE NO ES EL DEL PDF (SC-14) -->
    <xsl:if test="not($gbct:tex4ht) and not($estilo_cita = ('apa', 'iso690', 'vancouver', 'ieee'))">
      <xsl:message terminate="yes">
        <xsl:text>&#10;[docbook-to-html] ESTILO DE CITA SIN SALIDA HTML: </xsl:text>
        <xsl:value-of select="$estilo_cita"/>
        <xsl:text>&#10;  No tiene archivo de pantalla (cita-</xsl:text>
        <xsl:value-of select="$estilo_cita"/>
        <xsl:text>-html.tex) ni plantillas en esta hoja.&#10;</xsl:text>
      </xsl:message>
    </xsl:if>

    <!-- 1. PORTADA DEL LIBRO -->
    <xsl:call-template name="emitir-index-html"/>

    <!-- 2. UNA PÁGINA POR CADA CAPÍTULO (Fase 2) -->
    <!-- xsl:result-document DENTRO DE xsl:for-each ES VÁLIDO EN SAXON.
         CADA CAPÍTULO GENERA UN docs/h-{nombre_archivo}.html. -->
    <!-- xsl:result-document DENTRO DE xsl:for-each ES VÁLIDO EN SAXON.
         SE RECORRE EL MANIFIESTO (NO LISTAS DE TIPOS DE ELEMENTO): ASÍ
         CADA CAPÍTULO DECLARADO GENERA SU PÁGINA, SEA CUAL SEA EL
         ELEMENTO DOCBOOK QUE LO REPRESENTE (chapter, preface,
         acknowledgements, appendix, etc.). FUENTE ÚNICA DE VERDAD,
         SINCRONIZADA CON EL ÍNDICE DE LA COLUMNA CENTRAL. -->
    <xsl:for-each select="$manifiesto//capitulo">
      <!-- RESOLVER EL NODO DEL CAPÍTULO EN EL CANÓNICO POR
           xml:id = concat('cap-', @id_capitulo). local-name() != ''
           EXCLUYE LOS ELEMENTOS QUE NO SEAN CAPÍTULOS DE PRIMER NIVEL. -->
      <xsl:variable name="capIdEsperado" select="concat('cap-', @id_capitulo)"/>
      <xsl:variable name="capNodo"
                    select="$book/*[@xml:id = $capIdEsperado]"/>
      <!-- LA DEDICATORIA NO TIENE PÁGINA PROPIA: VA EN LA DE ENTRADA, ANTES
           DEL ÍNDICE, COMO EN EL PDF VA ANTES DEL SUMARIO (SC-31). UNA
           PÁGINA SUYA QUEDARÍA SIN ENLACE: EL HTML SE RECORRE DESDE EL ÍNDICE,
           Y LA DEDICATORIA NO ENTRA EN ÉL. -->
      <xsl:if test="$capNodo[not(self::db:dedication or self::dedication)]">
        <xsl:call-template name="emitir-capitulo-html">
          <xsl:with-param name="capitulo" select="$capNodo"/>
        </xsl:call-template>
      </xsl:if>
    </xsl:for-each>
  </xsl:template>

  <!-- ==========================================================
       TEMPLATE: EMITIR index.html
       ========================================================== -->
  <xsl:template name="emitir-index-html">
    <xsl:result-document href="docs/index.html" format="html5">
      <html lang="{$idioma_principal}">
        <head>
          <meta charset="UTF-8"/>
          <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

          <title>
            <xsl:value-of select="$titulo_libro"/>
          </title>

          <xsl:call-template name="emitir-meta-highwire-libro"/>
          <xsl:call-template name="emitir-meta-dc-libro"/>
          <xsl:call-template name="emitir-meta-og-twitter-libro"/>

          <!-- Fuentes tipográficas (compartidas con revistas) -->
          <link rel="preconnect" href="https://fonts.googleapis.com"/>
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous"/>
          <link rel="stylesheet"
                href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,400;0,600;1,400;1,600&amp;family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&amp;family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&amp;display=swap"/>

          <!-- CSS y JS externos, compartidos entre index y capítulos -->
          <link rel="stylesheet" href="assets/css/gbpublisher.css"/>
        </head>

        <body class="pagina-libro-index">

          <!-- ==========================================
               LAYOUT DE 2 COLUMNAS (SIN COL-RIGHT)
               ========================================== -->
          <div class="layout layout-2col" id="mainLayout">

            <xsl:call-template name="emitir-col-left-libro"/>
            <xsl:call-template name="emitir-col-center-index"/>

          </div>

          <xsl:call-template name="emitir-pie-colofon"/>

          <!-- ==========================================
               INYECCIÓN DE citaData (Fase 5) + JS EXTERNO
               ========================================== -->
          <xsl:call-template name="emitir-citadata-libro"/>
          <script src="assets/js/gbpublisher.js"></script>

        </body>
      </html>
    </xsl:result-document>
  </xsl:template>

  <!-- ==========================================================
       META TAGS: HIGHWIRE PRESS (Google Scholar) — LIBROS
       ========================================================== -->
  <xsl:template name="emitir-meta-highwire-libro">
    <xsl:comment> ============================================
    METADATOS: Highwire Press — Google Scholar
    Adaptados para libros (citation_book_title, citation_isbn)
    ============================================ </xsl:comment>

    <meta name="citation_book_title" content="{$titulo_libro}"/>

    <xsl:if test="$doi_libro != ''">
      <meta name="citation_doi" content="{$doi_libro}"/>
    </xsl:if>

    <xsl:if test="$isbn_print != ''">
      <meta name="citation_isbn" content="{$isbn_print}"/>
    </xsl:if>

    <xsl:if test="$isbn_electronic != ''">
      <meta name="citation_isbn" content="{$isbn_electronic}"/>
    </xsl:if>

    <xsl:if test="$editorial != ''">
      <meta name="citation_publisher" content="{$editorial}"/>
    </xsl:if>

    <xsl:if test="$anio_cita != ''">
      <meta name="citation_publication_date" content="{$anio_cita}"/>
    </xsl:if>

    <meta name="citation_language" content="{$idioma_principal}"/>

    <xsl:if test="$url_libro != ''">
      <meta name="citation_fulltext_html_url" content="{$url_libro}"/>
    </xsl:if>

    <!-- Autores (loop) -->
    <xsl:for-each select="$info/db:author | $info/author">
      <meta name="citation_author"
            content="{normalize-space(db:personname/db:surname | personname/surname)}, {normalize-space(db:personname/db:firstname | personname/firstname)}"/>

      <xsl:variable name="orcid_url"
                    select="(db:uri[@type='orcid'] | uri[@type='orcid'])[1]"/>
      <xsl:if test="$orcid_url != ''">
        <meta name="citation_author_orcid" content="{$orcid_url}"/>
      </xsl:if>

      <xsl:variable name="orgname"
                    select="(db:affiliation/db:orgname | affiliation/orgname)[1]"/>
      <xsl:if test="$orgname != ''">
        <meta name="citation_author_institution" content="{normalize-space($orgname)}"/>
      </xsl:if>
    </xsl:for-each>

    <!-- Editores del libro -->
    <xsl:for-each select="$info/db:editor | $info/editor">
      <meta name="citation_editor"
            content="{normalize-space(db:personname/db:surname | personname/surname)}, {normalize-space(db:personname/db:firstname | personname/firstname)}"/>
    </xsl:for-each>
  </xsl:template>

  <!-- ==========================================================
       META TAGS: DUBLIN CORE
       ========================================================== -->
  <xsl:template name="emitir-meta-dc-libro">
    <xsl:comment> ============================================
    METADATOS: Dublin Core (DC)
    ============================================ </xsl:comment>

    <meta name="DC.title" content="{$titulo_libro}"/>
    <meta name="DC.language" content="{$idioma_principal}"/>
    <meta name="DC.type" content="Book"/>
    <meta name="DC.format" content="text/html"/>

    <xsl:if test="$editorial != ''">
      <meta name="DC.publisher" content="{$editorial}"/>
    </xsl:if>

    <xsl:if test="$doi_libro != ''">
      <meta name="DC.identifier" content="https://doi.org/{$doi_libro}"/>
    </xsl:if>

    <xsl:if test="$anio_cita != ''">
      <meta name="DC.date" content="{$anio_cita}"/>
    </xsl:if>

    <xsl:if test="$licencia_url != ''">
      <meta name="DC.rights" content="{$licencia_url}"/>
    </xsl:if>

    <xsl:for-each select="$info/db:author | $info/author">
      <meta name="DC.creator"
            content="{normalize-space(db:personname/db:surname | personname/surname)}, {normalize-space(db:personname/db:firstname | personname/firstname)}"/>
    </xsl:for-each>
  </xsl:template>

  <!-- ==========================================================
       META TAGS: OPEN GRAPH + TWITTER CARDS
       ========================================================== -->
  <xsl:template name="emitir-meta-og-twitter-libro">
    <xsl:comment> ============================================
    METADATOS: Open Graph + Twitter Cards
    ============================================ </xsl:comment>

    <meta property="og:type" content="book"/>
    <meta property="og:title" content="{$titulo_libro}"/>
    <xsl:if test="$resumen_libro != ''">
      <meta property="og:description" content="{$resumen_libro}"/>
    </xsl:if>
    <xsl:if test="$imagen_tapa != ''">
      <meta property="og:image" content="{$imagen_tapa}"/>
    </xsl:if>
    <xsl:if test="$url_libro != ''">
      <meta property="og:url" content="{$url_libro}"/>
    </xsl:if>
    <xsl:if test="$isbn_print != ''">
      <meta property="og:book:isbn" content="{$isbn_print}"/>
    </xsl:if>

    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:title" content="{$titulo_libro}"/>
    <xsl:if test="$resumen_libro != ''">
      <meta name="twitter:description" content="{$resumen_libro}"/>
    </xsl:if>
    <xsl:if test="$imagen_tapa != ''">
      <meta name="twitter:image" content="{$imagen_tapa}"/>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       COL-LEFT: METADATOS DEL LIBRO
       ==========================================================
       Estructura:
         - Tapa
         - ISBN(s)
         - Autores del libro
         - Publicación (año + lugar)
         - DOI
         - Licencia badge
         - Colección/serie
       En Fase 5 se agregará "Citar este libro". -->
  <xsl:template name="emitir-col-left-libro">
    <aside class="col-left">

      <!-- TAPA DEL LIBRO -->
      <xsl:if test="$imagen_tapa != ''">
        <div class="tapa-wrapper">
          <img src="{$imagen_tapa}" alt="Cubierta de {$titulo_libro}"/>
        </div>
      </xsl:if>

      <!-- FILA DE COMPARTIR EN REDES (COMPARTE EL LIBRO) -->
      <xsl:call-template name="fila-compartir">
        <xsl:with-param name="url" select="$url_libro"/>
        <xsl:with-param name="titulo" select="$titulo_libro"/>
      </xsl:call-template>

      <!-- ==========================================================
           BLOQUE DE IDENTIFICADORES: ISBN, eISBN, DOI, LICENCIA
           Van juntos tras la tapa. Rótulos en mayúscula con dos puntos
           (mismo patrón: meta-key negro + valor/enlace).
           ========================================================== -->

      <!-- ISBN (IMPRESO) -->
      <xsl:if test="$isbn_print != ''">
        <div class="meta-issn"><span class="meta-key">ISBN: </span>
          <xsl:value-of select="$isbn_print"/>
        </div>
      </xsl:if>

      <!-- eISBN (ELECTRÓNICO) -->
      <xsl:if test="$isbn_electronic != ''">
        <div class="meta-issn"><span class="meta-key">eISBN: </span>
          <xsl:value-of select="$isbn_electronic"/>
        </div>
      </xsl:if>

      <!-- DOI -->
      <xsl:if test="$doi_libro != ''">
        <div class="meta-seccion">
          <div class="meta-valor"><span class="meta-key">DOI: </span>
            <a class="doi-link" href="https://doi.org/{$doi_libro}"
               target="_blank" rel="noopener noreferrer">
              <xsl:value-of select="$doi_libro"/>
            </a>
          </div>
        </div>
      </xsl:if>

      <!-- LICENCIA (mismo patrón que DOI: meta-key inline + link, MAYÚSCULA) -->
      <xsl:if test="$licencia_texto != ''">
        <div class="meta-seccion">
          <div class="meta-valor"><span class="meta-key">LICENCIA: </span>
            <xsl:choose>
              <xsl:when test="$licencia_url != ''">
                <a class="licencia-link" href="{$licencia_url}"
                   target="_blank" rel="noopener noreferrer">
                  <xsl:value-of select="$licencia_texto"/>
                </a>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="$licencia_texto"/>
              </xsl:otherwise>
            </xsl:choose>
          </div>
        </div>
      </xsl:if>

      <!-- PUBLICACIÓN -->
      <xsl:if test="$editorial != '' or $fecha_display != ''">
        <div class="meta-seccion">
          <div class="meta-label">Publicación</div>
          <div class="meta-valor">
            <xsl:if test="$fecha_display != ''">
              <xsl:value-of select="$fecha_display"/>
            </xsl:if>
            <xsl:if test="$fecha_display != '' and $editorial != ''">
              <xsl:text>. </xsl:text>
            </xsl:if>
            <xsl:if test="$editorial != ''">
              <xsl:value-of select="$editorial"/>
            </xsl:if>
            <xsl:if test="$ciudad_pub != ''">
              <xsl:text>, </xsl:text>
              <xsl:value-of select="$ciudad_pub"/>
            </xsl:if>
            <xsl:if test="$pais_pub != ''">
              <xsl:text>, </xsl:text>
              <xsl:value-of select="$pais_pub"/>
            </xsl:if>
          </div>
        </div>
      </xsl:if>

      <!-- COLECCIÓN / SERIE -->
      <xsl:for-each select="$info/db:biblioset | $info/biblioset">
        <div class="meta-seccion">
          <div class="meta-label">
            <xsl:choose>
              <xsl:when test="@relation='series'">Colección</xsl:when>
              <xsl:when test="@relation='subseries'">Serie</xsl:when>
              <xsl:otherwise>Colección</xsl:otherwise>
            </xsl:choose>
          </div>
          <div class="meta-valor">
            <xsl:value-of select="normalize-space(db:title | title)"/>
            <xsl:if test="db:volumenum | volumenum">
              <xsl:text>, número </xsl:text>
              <xsl:value-of select="normalize-space(db:volumenum | volumenum)"/>
            </xsl:if>
          </div>
        </div>
      </xsl:for-each>

      <!-- BOTONES DE DESCARGA (LIBRO COMPLETO): PDF Y EPUB.
           SOLO EN EL INDEX. CADA BOTÓN APARECE SI SU URL EXISTE. -->
      <xsl:if test="$url_descarga_pdf != '' or $url_descarga_epub != ''">
        <div class="meta-seccion descarga-libro-wrapper">
          <xsl:if test="$url_descarga_pdf != ''">
            <a class="btn-descargar-pdf" href="{$url_descarga_pdf}"
               target="_blank" rel="noopener noreferrer">
              <xsl:text>Descargar PDF</xsl:text>
            </a>
          </xsl:if>
          <xsl:if test="$url_descarga_epub != ''">
            <a class="btn-descargar-epub" href="{$url_descarga_epub}"
               target="_blank" rel="noopener noreferrer">
              <xsl:text>Descargar EPUB</xsl:text>
            </a>
          </xsl:if>
        </div>
      </xsl:if>

      <!-- WIDGET "CÓMO CITAR" (FASE 5) -->
      <xsl:call-template name="emitir-widget-citar"/>

    </aside>
  </xsl:template>

  <!-- ==========================================================
       PIE DE PÁGINA: COLOFÓN DIGITAL
       ==========================================================
       EN HTML EL COLOFÓN NO ES UNA PIEZA DE LA SECUENCIA SINO PARTE DE
       LA PLANTILLA (m_PiezasLibro: TRATAMIENTO_PIE). VA EN TODAS LAS
       PÁGINAS. -->
  <xsl:template name="emitir-pie-colofon">
    <xsl:if test="$colofon_digital">
      <footer class="pie-colofon">
        <xsl:copy-of select="$colofon_digital" copy-namespaces="no"/>
      </footer>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       COL-CENTER PARA index.html
       ==========================================================
       Estructura:
         - Título + subtítulo
         - Autores (nombres visibles)
         - Resumen (si hay) + keywords (si hay)
         - Índice de contenidos (lista de capítulos con links)  -->
  <xsl:template name="emitir-col-center-index">
    <main class="col-center">

      <!-- Tipo (para el chip superior estilo revista) -->
      <div class="article-type-bar">Libro</div>

      <!-- Título del libro -->
      <h1 class="article-title">
        <xsl:value-of select="$titulo_libro"/>
      </h1>

      <!-- Subtítulo si tiene -->
      <xsl:if test="$subtitulo != ''">
        <div class="article-trans-title">
          <xsl:value-of select="$subtitulo"/>
        </div>
      </xsl:if>

      <!-- Autoría visible en el centro (nombre enlaza al ORCID si existe) -->
      <xsl:if test="$info/db:author | $info/author | $info/db:editor | $info/editor">
        <div class="autoria-inline">
          <xsl:for-each select="$info/db:author | $info/author">
            <xsl:call-template name="separador-autoria">
              <xsl:with-param name="pos" select="position()"/>
              <xsl:with-param name="total" select="last()"/>
              <xsl:with-param name="nombre"
                              select="(db:personname/db:firstname | personname/firstname)[1]"/>
            </xsl:call-template>
            <xsl:call-template name="emitir-nombre-autor">
              <xsl:with-param name="persona" select="."/>
            </xsl:call-template>
          </xsl:for-each>
          <xsl:if test="($info/db:author | $info/author)
                    and ($info/db:editor | $info/editor)">
            <xsl:text> · </xsl:text>
          </xsl:if>
          <!-- UNA SOLA MARCA DESPUÉS DE TODOS LOS EDITORES, SEGÚN SU ROL:
               «(comps.)», Y NO UNA MARCA DESPUÉS DE CADA NOMBRE. LOS NOMBRES VAN
               «Nombre Apellido», SIN PUNTO FINAL: LA MARCA VA EN MINÚSCULA -->
          <xsl:for-each select="$info/db:editor | $info/editor">
            <xsl:call-template name="separador-autoria">
              <xsl:with-param name="pos" select="position()"/>
              <xsl:with-param name="total" select="last()"/>
              <xsl:with-param name="nombre"
                              select="(db:personname/db:firstname | personname/firstname)[1]"/>
            </xsl:call-template>
            <xsl:call-template name="emitir-nombre-autor">
              <xsl:with-param name="persona" select="."/>
            </xsl:call-template>
          </xsl:for-each>
          <xsl:if test="$info/db:editor | $info/editor">
            <xsl:call-template name="marca-editor-db">
              <xsl:with-param name="estilo" select="$estilo_cita"/>
              <xsl:with-param name="editores" select="$info/db:editor | $info/editor"/>
            </xsl:call-template>
          </xsl:if>
        </div>
      </xsl:if>

      <div class="article-body">

        <!-- ==========================================================
             RESUMEN DEL LIBRO (desplegable, patrón del artículo)
             ==========================================================
             <details>/<summary> igual que el abstract de revistas:
             "Resumen" como etiqueta chica en sans con la flecha nativa
             del <details>; texto y palabras clave dentro. -->
        <xsl:if test="$resumen_libro != ''">
          <div class="abstracts-wrapper">
            <details class="abstract-block" open="open">
              <summary class="abstract-lang-label">Resumen</summary>
              <div class="abstract-texto">
                <p><xsl:value-of select="$resumen_libro"/></p>
              </div>
              <!-- PALABRAS CLAVE -->
              <xsl:variable name="keywords"
                            select="$info/db:keywordset/db:keyword | $info/keywordset/keyword"/>
              <xsl:if test="$keywords">
                <p class="abstract-keywords">
                  <strong>Palabras clave: </strong>
                  <xsl:for-each select="$keywords">
                    <xsl:if test="position() &gt; 1">, </xsl:if>
                    <xsl:value-of select="normalize-space(.)"/>
                  </xsl:for-each>
                </p>
              </xsl:if>
            </details>
          </div>
        </xsl:if>

        <!-- ==========================================================
             ÍNDICE POR PARTES ESTRUCTURALES
             ==========================================================
             Los capítulos se agrupan en 3 partes estructurales según
             el PREFIJO del nombre_archivo del manifiesto:
               fm-  → Preliminares
               a-   → Cuerpo principal (ÚNICO CON NUMERACIÓN)
               bm-  → Material complementario
             El manifiesto ya trae las entradas en orden de lectura.
             Cada parte se muestra solo si tiene capítulos. -->
        <!-- ==========================================================
             DEDICATORIA
             ==========================================================
             REPLICA EL PDF (SC-31): SIN TÍTULO VISIBLE Y CON EL BLOQUE
             DEL EPÍGRAFE SIN ATRIBUCIÓN, QUE NO LLEVA FILETE (SC-35). VA
             ANTES DEL ÍNDICE, COMO EN EL PDF ANTES DEL SUMARIO, Y NO
             ENTRA EN ÉL. SIN LA BAJADA DEL PDF: EN UNA PÁGINA QUE SE
             DESPLAZA NO HAY TOPE DE CAJA (EXCEPCIÓN 2 DE SC-31).
             EL TÍTULO DEL CANÓNICO QUEDA COMO NOMBRE ACCESIBLE.
             role="doc-dedication": DPUB-ARIA 1.1, SUPERCLASE section. -->
        <xsl:for-each select="$book/db:dedication | $book/dedication">
          <xsl:variable name="dedTitulo"
                        select="normalize-space((db:info/db:title | info/title)[1])"/>
          <section class="dedicatoria" role="doc-dedication">
            <xsl:if test="$dedTitulo != ''">
              <xsl:attribute name="aria-label" select="$dedTitulo"/>
            </xsl:if>
            <div class="epigrafe">
              <xsl:for-each select="*[not(self::db:info or self::info)]">
                <xsl:choose>
                  <xsl:when test="self::db:para or self::para">
                    <p class="epigrafe-texto"><xsl:apply-templates/></p>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:apply-templates select="."/>
                  </xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </div>
          </section>
        </xsl:for-each>

        <section class="indice-capitulos">

          <!-- PRELIMINARES (fm-). SIN LA DEDICATORIA: VA ARRIBA, FUERA DEL
               ÍNDICE, COMO EN EL PDF (m_PiezasLibro.VaEnIndice ES LA MISMA
               REGLA PARA EL nav DEL EPUB) -->
          <xsl:variable name="caps_fm"
                        select="$manifiesto//capitulo[starts-with(@nombre_archivo, 'fm-')]
                                                     [not(@tipo_capitulo = 'dedicatoria')]"/>
          <xsl:if test="$caps_fm">
            <div class="parte-estructural">
              <h2 class="parte-titulo">Preliminares</h2>
              <ul class="lista-capitulos">
                <xsl:for-each select="$caps_fm">
                  <xsl:call-template name="emitir-item-parte">
                    <xsl:with-param name="capManif" select="."/>
                    <xsl:with-param name="numero" select="''"/>
                  </xsl:call-template>
                </xsl:for-each>
              </ul>
            </div>
          </xsl:if>

          <!-- CUERPO PRINCIPAL (a-) — CON NUMERACIÓN -->
          <xsl:variable name="caps_a"
                        select="$manifiesto//capitulo[starts-with(@nombre_archivo, 'a-')]"/>
          <xsl:if test="$caps_a">
            <div class="parte-estructural">
              <h2 class="parte-titulo">Cuerpo principal</h2>
              <ol class="lista-capitulos lista-numerada">
                <xsl:for-each select="$caps_a">
                  <xsl:call-template name="emitir-item-parte">
                    <xsl:with-param name="capManif" select="."/>
                    <xsl:with-param name="numero" select="string(position())"/>
                  </xsl:call-template>
                </xsl:for-each>
              </ol>
            </div>
          </xsl:if>

          <!-- MATERIAL COMPLEMENTARIO (bm-) -->
          <xsl:variable name="caps_bm"
                        select="$manifiesto//capitulo[starts-with(@nombre_archivo, 'bm-')]"/>
          <xsl:if test="$caps_bm">
            <div class="parte-estructural">
              <h2 class="parte-titulo">Material complementario</h2>
              <ul class="lista-capitulos">
                <xsl:for-each select="$caps_bm">
                  <xsl:call-template name="emitir-item-parte">
                    <xsl:with-param name="capManif" select="."/>
                    <xsl:with-param name="numero" select="''"/>
                  </xsl:call-template>
                </xsl:for-each>
              </ul>
            </div>
          </xsl:if>

        </section>

      </div>
    </main>
  </xsl:template>

  <!-- ==========================================================
       PARTE ESTRUCTURAL A PARTIR DEL nombre_archivo
       ==========================================================
       Deriva la parte estructural del PREFIJO del nombre_archivo:
         fm-  → Preliminares
         a-   → Cuerpo principal
         bm-  → Material complementario
       Es la misma clasificación que usa el índice de la portada. -->
  <xsl:template name="parte-estructural-de">
    <xsl:param name="nombreArchivo"/>
    <xsl:choose>
      <xsl:when test="starts-with($nombreArchivo, 'fm-')">Preliminares</xsl:when>
      <xsl:when test="starts-with($nombreArchivo, 'a-')">Cuerpo principal</xsl:when>
      <xsl:when test="starts-with($nombreArchivo, 'bm-')">Material complementario</xsl:when>
      <xsl:otherwise>Cuerpo principal</xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       NOMBRE DE AUTOR/EDITOR CON ENLACE AL ORCID (SI EXISTE)
       ==========================================================
       Emite "Nombre Apellido". Si el <author>/<editor> tiene
       <uri type="orcid">, el nombre se envuelve en un enlace a esa
       URL (sin escribir la palabra ORCID). Sin ORCID, texto plano. -->
  <xsl:template name="emitir-nombre-autor">
    <xsl:param name="persona"/>
    <xsl:variable name="nombreCompleto"
                  select="concat(
                    normalize-space($persona/db:personname/db:firstname | $persona/personname/firstname),
                    ' ',
                    normalize-space($persona/db:personname/db:surname | $persona/personname/surname))"/>
    <xsl:variable name="orcid"
                  select="normalize-space(
                    ($persona/db:uri[@type='orcid'] | $persona/uri[@type='orcid'])[1])"/>
    <xsl:choose>
      <xsl:when test="$orcid != ''">
        <a class="autor-orcid-link" href="{$orcid}"
           target="_blank" rel="noopener noreferrer">
          <xsl:value-of select="$nombreCompleto"/>
        </a>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$nombreCompleto"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       ITEM DE UNA PARTE ESTRUCTURAL DEL ÍNDICE
       ==========================================================
       Recibe la entrada <capitulo> del manifiesto y el número
       (posición dentro del Cuerpo principal, o '' si no numera).
       Resuelve el título yendo al capítulo del canónico por
       xml:id = concat('cap-', @id_capitulo). Solo muestra el
       título (sin etiqueta de tipo). -->
  <xsl:template name="emitir-item-parte">
    <xsl:param name="capManif"/>
    <xsl:param name="numero" as="xs:string" select="''"/>

    <xsl:variable name="nombreArchivo" select="$capManif/@nombre_archivo"/>
    <xsl:variable name="capIdEsperado" select="concat('cap-', $capManif/@id_capitulo)"/>

    <!-- BUSCAR EL CAPÍTULO EN EL CANÓNICO PARA SACAR EL TÍTULO -->
    <xsl:variable name="capNodo"
                  select="($book/db:chapter | $book/chapter
                         | $book/db:preface | $book/preface
                         | $book/db:acknowledgements | $book/acknowledgements
                         | $book/db:appendix | $book/appendix
                         | $book/db:dedication | $book/dedication
                         | $book/db:colophon | $book/colophon
                         | $book/db:glossary | $book/glossary)
                         [@xml:id = $capIdEsperado]"/>

    <xsl:variable name="capTitulo"
                  select="normalize-space(
                    ($capNodo/db:info/db:title | $capNodo/info/title)[1])"/>

    <li class="item-capitulo">
      <a class="link-capitulo" href="h-{$nombreArchivo}.html">
        <xsl:if test="$numero != ''">
          <span class="cap-numero"><xsl:value-of select="$numero"/></span>
        </xsl:if>
        <span class="cap-titulo"><xsl:value-of select="$capTitulo"/></span>
      </a>
    </li>
  </xsl:template>

  <!-- ==========================================================
       ITEM DE LA LISTA DE CAPÍTULOS
       ==========================================================
       Recibe el nodo <chapter>/<preface>/etc. del <book>.
       Mapea xml:id → nombre_archivo consultando el manifiesto
       con xsl:key ('cap-por-id').  -->
  <xsl:template name="emitir-item-capitulo">
    <xsl:param name="capitulo"/>

    <!-- xml:id del capítulo raíz (típicamente 'cap-N') -->
    <xsl:variable name="capId" select="$capitulo/@xml:id"/>

    <!-- Buscar en el manifiesto el <capitulo> con id que coincide -->
    <xsl:variable name="capManif"
                  select="key('cap-por-id', $capId, $manifiesto)"/>

    <xsl:variable name="nombreArchivo"
                  select="$capManif/@nombre_archivo"/>

    <!-- Título del capítulo (del <info>) -->
    <xsl:variable name="capTitulo"
                  select="normalize-space(
                    ($capitulo/db:info/db:title
                     | $capitulo/info/title)[1])"/>

    <!-- Etiqueta del tipo de capítulo (chapter, preface, appendix, etc.) -->
    <xsl:variable name="capTipo">
      <xsl:call-template name="etiqueta-tipo-capitulo">
        <xsl:with-param name="elemento" select="local-name($capitulo)"/>
      </xsl:call-template>
    </xsl:variable>

    <li class="item-capitulo">
      <xsl:choose>
        <xsl:when test="$nombreArchivo != ''">
          <a class="link-capitulo" href="h-{$nombreArchivo}.html">
            <span class="cap-tipo"><xsl:value-of select="$capTipo"/></span>
            <span class="cap-titulo"><xsl:value-of select="$capTitulo"/></span>
          </a>
        </xsl:when>
        <xsl:otherwise>
          <!-- Fallback: nombre_archivo no encontrado en manifiesto,
               emitir texto sin enlace y comentario para debug -->
          <xsl:comment>
            <xsl:text>ADVERTENCIA: no se pudo resolver nombre_archivo para xml:id='</xsl:text>
            <xsl:value-of select="$capId"/>
            <xsl:text>'. Verificar manifiesto.</xsl:text>
          </xsl:comment>
          <span class="cap-tipo"><xsl:value-of select="$capTipo"/></span>
          <span class="cap-titulo"><xsl:value-of select="$capTitulo"/></span>
        </xsl:otherwise>
      </xsl:choose>
    </li>
  </xsl:template>

  <!-- ==========================================================
       MAPEO DE local-name() A ETIQUETA LEGIBLE PARA EL ÍNDICE
       ========================================================== -->
  <xsl:template name="etiqueta-tipo-capitulo">
    <xsl:param name="elemento" as="xs:string"/>
    <xsl:choose>
      <xsl:when test="$elemento = 'chapter'">Capítulo</xsl:when>
      <xsl:when test="$elemento = 'preface'">Prefacio</xsl:when>
      <xsl:when test="$elemento = 'appendix'">Apéndice</xsl:when>
      <xsl:when test="$elemento = 'dedication'">Dedicatoria</xsl:when>
      <xsl:when test="$elemento = 'colophon'">Colofón</xsl:when>
      <xsl:when test="$elemento = 'bibliography'">Bibliografía</xsl:when>
      <xsl:when test="$elemento = 'glossary'">Glosario</xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$elemento"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       ============ FASE 2: PÁGINAS DE CAPÍTULO ================
       ========================================================== -->

  <!-- ==========================================================
       TEMPLATE: EMITIR h-{nombre_archivo}.html DE UN CAPÍTULO
       ==========================================================
       Layout de 3 columnas (col-left híbrida + col-center + drawer).
       El drawer (col-right) se arma estructuralmente pero vacío;
       se puebla en Fase 3 con notas/referencias/figuras. -->
  <xsl:template name="emitir-capitulo-html">
    <xsl:param name="capitulo"/>

    <!-- RESOLVER nombre_archivo VÍA MANIFIESTO -->
    <xsl:variable name="capId" select="$capitulo/@xml:id"/>
    <xsl:variable name="capManif" select="key('cap-por-id', $capId, $manifiesto)"/>
    <xsl:variable name="nombreArchivo" select="$capManif/@nombre_archivo"/>

    <!-- SI NO SE RESUELVE EL NOMBRE, NO GENERAR ARCHIVO (SE AVISA EN COMENTARIO) -->
    <xsl:choose>
      <xsl:when test="$nombreArchivo != ''">

        <xsl:variable name="capInfo" select="$capitulo/db:info | $capitulo/info"/>
        <xsl:variable name="capTitulo"
                      select="normalize-space(($capInfo/db:title | $capInfo/title)[1])"/>

        <xsl:result-document href="docs/h-{$nombreArchivo}.html" format="html5">
          <html lang="{$idioma_principal}">
            <head>
              <meta charset="UTF-8"/>
              <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
              <title>
                <xsl:value-of select="$capTitulo"/>
                <xsl:text> — </xsl:text>
                <xsl:value-of select="$titulo_libro"/>
              </title>

              <xsl:call-template name="emitir-metadatos-capitulo">
                <xsl:with-param name="capitulo" select="$capitulo"/>
                <xsl:with-param name="capInfo" select="$capInfo"/>
                <xsl:with-param name="capTitulo" select="$capTitulo"/>
              </xsl:call-template>

              <link rel="preconnect" href="https://fonts.googleapis.com"/>
              <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous"/>
              <link rel="stylesheet"
                    href="https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,400;0,600;1,400;1,600&amp;family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,600;1,300;1,400;1,600&amp;family=IBM+Plex+Mono:ital,wght@0,400;0,600;1,400&amp;display=swap"/>
              <link rel="stylesheet" href="assets/css/gbpublisher.css"/>
            </head>

            <body class="pagina-libro-capitulo">

              <!-- BOTÓN MOSTRAR/OCULTAR PANEL DERECHO (IGUAL QUE REVISTAS) -->
              <button class="panel-toggle" id="panelToggle" onclick="togglePanel()">
                <xsl:text>&#x2192; Mostrar panel</xsl:text>
              </button>

              <!-- FABS PARA TABLET/MÓVIL -->
              <button class="fab-meta" onclick="openDrawerMeta()">&#x2261;</button>
              <button class="fab-panel-tablet" onclick="openDrawerPanel()">&#x2192;</button>
              <div class="drawer-backdrop" id="drawerBackdrop" onclick="closeDrawers()"></div>

              <div class="layout layout-3col panel-hidden" id="mainLayout">
                <xsl:call-template name="emitir-col-left-capitulo">
                  <xsl:with-param name="capInfo" select="$capInfo"/>
                  <xsl:with-param name="capTitulo" select="$capTitulo"/>
                  <xsl:with-param name="nombreArchivo" select="$nombreArchivo"/>
                </xsl:call-template>

                <xsl:call-template name="emitir-col-center-capitulo">
                  <xsl:with-param name="capitulo" select="$capitulo"/>
                  <xsl:with-param name="capInfo" select="$capInfo"/>
                  <xsl:with-param name="capTitulo" select="$capTitulo"/>
                </xsl:call-template>

                <xsl:call-template name="emitir-col-right-drawer">
                  <xsl:with-param name="capitulo" select="$capitulo"/>
                </xsl:call-template>
              </div>

              <xsl:call-template name="emitir-pie-colofon"/>

              <!-- INYECCIÓN DE citaData (Fase 5) ANTES DEL JS EXTERNO -->
              <xsl:call-template name="emitir-citadata-capitulo">
                <xsl:with-param name="capInfo" select="$capInfo"/>
                <xsl:with-param name="capTitulo" select="$capTitulo"/>
              </xsl:call-template>

              <!-- JS EXTERNO COMPARTIDO -->
              <script src="assets/js/gbpublisher.js"></script>
            </body>
          </html>
        </xsl:result-document>

      </xsl:when>
      <xsl:otherwise>
        <xsl:message>
          <xsl:text>ADVERTENCIA: no se pudo resolver nombre_archivo para xml:id='</xsl:text>
          <xsl:value-of select="$capId"/>
          <xsl:text>'. Capítulo omitido del HTML.</xsl:text>
        </xsl:message>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       COL-LEFT DE CAPÍTULO (HÍBRIDA LIBRO + CAPÍTULO)
       ==========================================================
       - Tapa del libro (heredada, constante entre capítulos)
       - Datos del capítulo: autores con afiliación/ORCID, licencia
       - Placeholder "Descargar capítulo (PDF)"
       - Placeholder "Cómo citar" (Fase 5)
       - Enlace de vuelta al índice del libro -->
  <xsl:template name="emitir-col-left-capitulo">
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>
    <xsl:param name="nombreArchivo"/>

    <aside class="col-left">

      <!-- BOTÓN "IR AL INICIO" (vuelve al index del libro).
           Mismo tratamiento que el botón Descargar EPUB: fondo blanco,
           texto azul, semibold. -->
      <a href="index.html" class="btn-ir-inicio">
        <xsl:text>Ir al inicio</xsl:text>
      </a>

      <!-- TAPA DEL LIBRO -->
      <xsl:if test="$imagen_tapa != ''">
        <div class="tapa-wrapper">
          <img src="{$imagen_tapa}" alt="Cubierta de {$titulo_libro}"/>
        </div>
      </xsl:if>

      <!-- FILA DE COMPARTIR EN REDES (COMPARTE EL CAPÍTULO).
           LA URL DEL CAPÍTULO SE DERIVA DE LA BASE DEL LIBRO
           (QUE TERMINA EN '/') + h-<nombre_archivo>.html. -->
      <xsl:if test="$url_libro != ''">
        <xsl:call-template name="fila-compartir">
          <xsl:with-param name="url"
            select="concat($url_libro, 'h-', $nombreArchivo, '.html')"/>
          <xsl:with-param name="titulo" select="$capTitulo"/>
        </xsl:call-template>
      </xsl:if>

      <!-- BOTÓN "DESCARGAR PDF" DEL CAPÍTULO.
           Lee la URL de descarga del PDF del capítulo desde el canónico
           (bibliomisc role="url-descarga-pdf-capitulo"), que provendrá de
           un campo del formulario de capítulos (aún no implementado).
           El botón aparece SOLO si la URL existe. Mismo estilo que EPUB. -->
      <xsl:variable name="capUrlPdf"
                    select="normalize-space(
                      ($capInfo/db:bibliomisc[@role='url-descarga-pdf-capitulo']
                       | $capInfo/bibliomisc[@role='url-descarga-pdf-capitulo'])[1])"/>
      <xsl:if test="$capUrlPdf != ''">
        <a class="btn-descargar-pdf" href="{$capUrlPdf}"
           target="_blank" rel="noopener noreferrer">
          <xsl:text>Descargar PDF</xsl:text>
        </a>
      </xsl:if>

      <!-- WIDGET "CÓMO CITAR" (FASE 5) -->
      <xsl:call-template name="emitir-widget-citar"/>

    </aside>
  </xsl:template>

  <!-- ==========================================================
       COL-CENTER DE CAPÍTULO
       ==========================================================
       - Título del capítulo + autores inline
       - Resúmenes (uno por idioma) si existen
       - Keywords si existen
       - Cuerpo del capítulo (apply-templates sobre el contenido) -->
  <xsl:template name="emitir-col-center-capitulo">
    <xsl:param name="capitulo"/>
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>

    <main class="col-center">

      <!-- BARRA SUPERIOR: PARTE ESTRUCTURAL (Preliminares / Cuerpo
           principal / Material complementario), derivada del prefijo
           del nombre_archivo del capítulo (resuelto vía manifiesto). -->
      <xsl:variable name="capIdBarra" select="$capitulo/@xml:id"/>
      <xsl:variable name="capManifBarra"
                    select="key('cap-por-id', $capIdBarra, $manifiesto)"/>
      <div class="article-type-bar">
        <xsl:call-template name="parte-estructural-de">
          <xsl:with-param name="nombreArchivo" select="$capManifBarra/@nombre_archivo"/>
        </xsl:call-template>
      </div>

      <!-- TÍTULO DEL CAPÍTULO -->
      <h1 class="article-title">
        <xsl:value-of select="$capTitulo"/>
      </h1>

      <!-- SUBTÍTULO SI TIENE -->
      <xsl:variable name="capSubtitulo"
                    select="normalize-space(($capInfo/db:subtitle | $capInfo/subtitle)[1])"/>
      <xsl:if test="$capSubtitulo != ''">
        <div class="article-trans-title">
          <xsl:value-of select="$capSubtitulo"/>
        </div>
      </xsl:if>

      <!-- AUTORÍA INLINE (nombre enlaza al ORCID si existe) -->
      <xsl:if test="$capInfo/db:author | $capInfo/author">
        <div class="autoria-inline">
          <xsl:for-each select="$capInfo/db:author | $capInfo/author">
            <xsl:call-template name="separador-autoria">
              <xsl:with-param name="pos" select="position()"/>
              <xsl:with-param name="total" select="last()"/>
              <xsl:with-param name="nombre"
                              select="(db:personname/db:firstname | personname/firstname)[1]"/>
            </xsl:call-template>
            <xsl:call-template name="emitir-nombre-autor">
              <xsl:with-param name="persona" select="."/>
            </xsl:call-template>
          </xsl:for-each>
        </div>
      </xsl:if>

      <div class="article-body">

        <!-- ==========================================================
             RESUMEN(ES) DEL CAPÍTULO (desplegable, patrón del index)
             ==========================================================
             <details>/<summary> igual que la portada y las revistas.
             Uno por idioma. Las palabras clave del mismo idioma se
             incluyen dentro del <details> correspondiente. -->
        <xsl:if test="$capInfo/db:abstract | $capInfo/abstract">
          <div class="abstracts-wrapper">
            <xsl:for-each select="$capInfo/db:abstract | $capInfo/abstract">
              <details class="abstract-block" open="open">
                <summary class="abstract-lang-label">
                  <xsl:text>Resumen</xsl:text>
                  <xsl:if test="@xml:lang">
                    <xsl:text> (</xsl:text><xsl:value-of select="@xml:lang"/><xsl:text>)</xsl:text>
                  </xsl:if>
                </summary>
                <div class="abstract-texto">
                  <xsl:for-each select="db:para | para">
                    <p><xsl:value-of select="normalize-space(.)"/></p>
                  </xsl:for-each>
                </div>
                <!-- PALABRAS CLAVE DEL MISMO IDIOMA (si hay keywordset con
                     el mismo xml:lang, o el único keywordset si no hay lang) -->
                <xsl:variable name="lang" select="@xml:lang"/>
                <xsl:variable name="kws"
                              select="../db:keywordset[not(@xml:lang) or @xml:lang = $lang]/db:keyword
                                    | ../keywordset[not(@xml:lang) or @xml:lang = $lang]/keyword"/>
                <xsl:if test="$kws">
                  <p class="abstract-keywords">
                    <strong>Palabras clave: </strong>
                    <xsl:for-each select="$kws">
                      <xsl:if test="position() &gt; 1">, </xsl:if>
                      <xsl:value-of select="normalize-space(.)"/>
                    </xsl:for-each>
                  </p>
                </xsl:if>
              </details>
            </xsl:for-each>
          </div>
        </xsl:if>

        <!-- CUERPO DEL CAPÍTULO -->
        <!-- SE APLICAN TEMPLATES SOBRE TODO EL CONTENIDO EXCEPTO <info> Y
             <bibliography> (ESTA ÚLTIMA VA AL DRAWER EN FASE 3, NO AL CUERPO) -->
        <xsl:apply-templates select="$capitulo/*[not(local-name() = 'info')
                                                 and not(local-name() = 'bibliography')]"/>

      </div>
    </main>
  </xsl:template>

  <!-- ==========================================================
       COL-RIGHT: DRAWER CON 3 PESTAÑAS (Fase 3)
       ==========================================================
       Usa las clases reales de revistas (panel-tab, panel-section,
       switchTab, contadores) para reutilizar el CSS de gbpublisher.css.
       - Notas y Figuras: construidas por JS en runtime desde las
         marcas del cuerpo (.nota-ref / .fig-wrapper).
       - Referencias: renderizadas por el XSLT desde <bibliography>. -->
  <xsl:template name="emitir-col-right-drawer">
    <xsl:param name="capitulo"/>

    <aside class="col-right" id="rightPanel">

      <div class="panel-tabs">
        <button class="panel-tab active" id="tab-notas" onclick="switchTab('notas')">
          <xsl:text>Notas </xsl:text>
          <span class="tab-count" id="count-notas">0</span>
        </button>
        <button class="panel-tab" id="tab-refs" onclick="switchTab('refs')">
          <xsl:text>Referencias </xsl:text>
          <span class="tab-count" id="count-refs">0</span>
        </button>
        <button class="panel-tab" id="tab-figs" onclick="switchTab('figs')">
          <xsl:text>Figuras </xsl:text>
          <span class="tab-count" id="count-figs">0</span>
        </button>
      </div>

      <div class="panel-content">

        <!-- SECCIÓN NOTAS: CONSTRUIDA POR JS (buildNotesPanel) -->
        <div class="panel-section active" id="panel-notas"></div>

        <!-- SECCIÓN REFERENCIAS: RENDERIZADA POR EL XSLT -->
        <div class="panel-section" id="panel-refs">
          <!-- FUENTE DE LA BIBLIOGRAFÍA DEL DRAWER:
               - por_capitulo: cada capítulo tiene su <bibliography> propia.
               - consolidada: el capítulo NO tiene bibliografía; se usa la
                 <bibliography> única del final del <book>, idéntica en todas
                 las páginas. La numeración sale corrida por su posición en
                 esa lista única.
               Se detecta sin parámetro de modelo: si el capítulo tiene
               bibliografía propia, se usa; si no, la consolidada del book. -->
          <xsl:variable name="biblioCap"
                        select="$capitulo/db:bibliography | $capitulo/bibliography"/>
          <xsl:variable name="biblio"
                        select="if ($biblioCap/db:biblioentry | $biblioCap/biblioentry)
                                then $biblioCap
                                else ($book/db:bibliography | $book/bibliography)"/>
          <xsl:choose>
            <!-- CON citas.html: LAS ENTRADAS DE biblatex, EN SU ORDEN (SC-57) -->
            <xsl:when test="$gbct:tex4ht">
              <xsl:call-template name="panel-refs-tex4ht">
                <xsl:with-param name="capitulo" select="$capitulo"/>
              </xsl:call-template>
            </xsl:when>
            <xsl:when test="$biblio/db:biblioentry | $biblio/biblioentry">
              <xsl:apply-templates select="$biblio/db:biblioentry | $biblio/biblioentry"
                                    mode="panel-ref"/>
            </xsl:when>
            <xsl:otherwise>
              <p class="drawer-vacio">Sin referencias.</p>
            </xsl:otherwise>
          </xsl:choose>
        </div>

        <!-- SECCIÓN FIGURAS: CONSTRUIDA POR JS (buildFigsPanel) -->
        <div class="panel-section" id="panel-figs"></div>

      </div>

    </aside>
  </xsl:template>

  <!-- ==========================================================
       ========== TEMPLATES DEL CUERPO DEL CAPÍTULO ============
       ==========================================================
       Vocabulario DocBook 5.2 → HTML. Namespace db: para los
       nodos cargados del canónico. -->

  <!-- SECTION → nivel de heading según profundidad de anidamiento -->
  <xsl:template match="db:section | section">
    <xsl:variable name="nivel" select="count(ancestor::db:section | ancestor::section) + 2"/>
    <section class="cap-section" id="{@xml:id}">
      <xsl:variable name="nodoTitulo" select="(db:title | title)[1]"/>
      <!-- EL TÍTULO SE RECORRE POR NODOS, COMO EN EL EPUB (SC-29):
           normalize-space() PEGABA EL TEXTO DE UNA NOTA AL TÍTULO Y
           PERDÍA SU MARCA, Y BORRABA LA CURSIVA Y LAS CITAS. LA NOTA
           TOMA LA PLANTILLA footnote: MARCA NUMERADA Y PANEL DE NOTAS -->
      <xsl:if test="normalize-space($nodoTitulo) != ''">
        <xsl:element name="h{if ($nivel &gt; 6) then 6 else $nivel}">
          <xsl:apply-templates select="$nodoTitulo/node()"/>
        </xsl:element>
      </xsl:if>
      <!-- CONTENIDO DE LA SECCIÓN, EXCEPTO SU PROPIO TÍTULO -->
      <xsl:apply-templates select="*[not(local-name() = 'title')]"/>
    </section>
  </xsl:template>

  <!-- PARA → P -->
  <xsl:template match="db:para | para">
    <p>
      <xsl:apply-templates/>
    </p>
  </xsl:template>

  <!-- ORDEREDLIST → OL (ANIDABLE) -->
  <xsl:template match="db:orderedlist | orderedlist">
    <ol>
      <xsl:apply-templates select="db:listitem | listitem"/>
    </ol>
  </xsl:template>

  <!-- ITEMIZEDLIST → UL (ANIDABLE) -->
  <xsl:template match="db:itemizedlist | itemizedlist">
    <ul>
      <xsl:apply-templates select="db:listitem | listitem"/>
    </ul>
  </xsl:template>

  <!-- LISTITEM → LI -->
  <xsl:template match="db:listitem | listitem">
    <li>
      <!-- SI EL LISTITEM TIENE UN SOLO PARA, DESENVOLVERLO PARA EVITAR
           <li><p>...</p></li> INNECESARIO. SI TIENE MÁS DE UN HIJO O
           SUBLISTAS, APLICAR TEMPLATES NORMALMENTE. -->
      <xsl:choose>
        <xsl:when test="count(*) = 1 and (db:para | para)">
          <xsl:apply-templates select="(db:para | para)/node()"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:apply-templates/>
        </xsl:otherwise>
      </xsl:choose>
    </li>
  </xsl:template>

  <!-- FIGURE / INFORMALFIGURE → .fig-wrapper CON data-fig-id.
       EL JS (buildFigsPanel) LEE ESTAS MARCAS PARA CONSTRUIR EL
       PANEL DE FIGURAS Y CABLEAR LA NAVEGACIÓN CRUZADA.
       LA NUMERACIÓN ES CORRELATIVA POR CAPÍTULO. -->
  <!-- EL NÚMERO ES EL DEL PDF (numeracion-libro.xsl, SC-31): 2.3 EN UN
       CAPÍTULO NUMERADO, A.1 EN UN APÉNDICE, 1 EN UNA PIEZA SIN NÚMERO.
       EL FILTRO DE LIBRO SOLO EMITE <figure> CON xml:id; EL id DE
       RESPALDO QUEDA PARA UN CANÓNICO VIEJO. -->
  <xsl:template match="db:figure | figure | db:informalfigure | informalfigure">
    <xsl:variable name="num" select="nl:numero-figura(., $piezasLibro)"/>
    <xsl:variable name="figId" select="if (@xml:id) then @xml:id
                                       else concat('fig-', translate($num, '.', '-'))"/>
    <xsl:variable name="imgdata"
                  select="(db:mediaobject/db:imageobject/db:imagedata
                          | mediaobject/imageobject/imagedata)[1]"/>
    <xsl:variable name="fileref" select="$imgdata/@fileref"/>
    <xsl:variable name="titulo"
                  select="normalize-space((db:title | title)[1])"/>
    <!-- TEXTO ALTERNATIVO: EL DECLARADO EN EL .md, QUE EL FILTRO PONE EN
         textobject; SI NO HAY, EL PIE -->
    <xsl:variable name="alt"
                  select="normalize-space(((db:mediaobject/db:textobject/db:phrase
                          | mediaobject/textobject/phrase)[1], $titulo)[1])"/>

    <!-- LA IMAGEN VIVE EN media/; EN docs/ VA A assets/media/ -->
    <xsl:variable name="nombre" select="string(tokenize($fileref, '/')[last()])"/>

    <!-- EL ANCHO DEL SHORTCODE (ancho=60 → @width="60%"): UN TOPE SOBRE
         EL TAMAÑO NATURAL, COMO max-width: 100% SIN ÉL. SOLO LA FORMA QUE
         ESCRIBE EL FILTRO; OTRA LA SEÑALA EL VALIDADOR (gbp-ancho) -->
    <xsl:variable name="ancho" as="xs:string"
                  select="if (matches(string($imgdata/@width), '^([1-9][0-9]?|100)%$'))
                          then string($imgdata/@width) else ''"/>

    <!-- data-png: LA IMAGEN PARA EL PANEL DE FIGURAS, QUE CON UN IFRAME NO
         TIENE UN <img> DE DONDE TOMARLA -->
    <figure class="fig-wrapper"
            id="{$figId}"
            data-fig-id="{$figId}"
            data-png="assets/media/{$nombre}"
            onclick="highlightPanel('figs','{$figId}')"
            style="cursor:pointer">
      <xsl:choose>
        <!-- UN GRÁFICO DE gbpublisher: media/fig-x.png CON media/fig-x.html
             AL LADO VA EN UN IFRAME (SC-69). EL HTML DEL LIBRO ES SU SALIDA
             DE PUBLICACIÓN: NO HAY MODO DE CONTROL COMO EN LAS REVISTAS -->
        <xsl:when test="$fileref != '' and gbg:interactivo(concat($proyecto_dir, '/media'), $nombre)">
          <xsl:call-template name="gbg:iframe">
            <xsl:with-param name="src" select="concat('assets/media/', gbg:html-del-png($nombre))"/>
            <xsl:with-param name="proporcion"
              select="gbg:proporcion(concat($proyecto_dir, '/media'), $nombre)"/>
            <xsl:with-param name="alt" select="string($alt)"/>
            <xsl:with-param name="espacio" select="'http://www.w3.org/1999/xhtml'"/>
            <xsl:with-param name="ancho" select="$ancho"/>
          </xsl:call-template>
        </xsl:when>
        <xsl:when test="$fileref != ''">
          <img src="assets/media/{$nombre}" alt="{$alt}">
            <xsl:if test="$ancho != ''">
              <xsl:attribute name="style" select="concat('max-width:', $ancho)"/>
            </xsl:if>
          </img>
        </xsl:when>
      </xsl:choose>
      <figcaption class="fig-caption">
        <span class="fig-label">Figura <xsl:value-of select="$num"/></span>
        <!-- EL TÍTULO SE RENDERIZA CON apply-templates (NO value-of) PARA
             QUE LOS biblioref DEL CAPTION SE RESUELVAN COMO REFERENCIA
             VISIBLE "(Autor, año)" EN LUGAR DE PERDERSE. -->
        <xsl:if test="normalize-space((db:title | title)[1]) != ''">
          <xsl:text>. </xsl:text>
          <xsl:apply-templates select="(db:title | title)[1]/node()"/>
        </xsl:if>
      </figcaption>
    </figure>
  </xsl:template>

  <!-- ==========================================================
       REFERENCIA CRUZADA (@fig-… EN EL .md)
       ==========================================================
       SOLO EL NÚMERO, COMO \ref EN EL PDF: LA PALABRA LA ESCRIBE EL
       EDITOR. SI LA FIGURA ESTÁ EN OTRA PIEZA, EL ENLACE VA A SU
       PÁGINA. UN DESTINO INEXISTENTE SALE «??», COMO EN LaTeX, Y SE
       AVISA. -->
  <xsl:template match="db:xref | xref">
    <xsl:variable name="destino" select="nl:destino(string(@linkend), $piezasLibro)"/>
    <xsl:variable name="texto" select="nl:texto-referencia($destino, $piezasLibro)"/>
    <xsl:choose>
      <xsl:when test="empty($destino)">
        <xsl:message>
          <xsl:text>AVISO: referencia sin destino: </xsl:text>
          <xsl:value-of select="@linkend"/>
        </xsl:message>
        <xsl:value-of select="$texto"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:if test="nl:cantidad-destinos(string(@linkend), $piezasLibro) > 1">
          <xsl:message>
            <xsl:text>AVISO: identificador repetido en el libro: </xsl:text>
            <xsl:value-of select="@linkend"/>
          </xsl:message>
        </xsl:if>
        <xsl:variable name="piezaDestino" select="nl:pieza-de($destino)"/>
        <xsl:variable name="pagina"
                      select="if ($piezaDestino is nl:pieza-de(.)) then ''
                              else concat('h-', key('cap-por-id', $piezaDestino/@xml:id,
                                                    $manifiesto)/@nombre_archivo, '.html')"/>
        <a class="fig-ref" href="{$pagina}#{@linkend}">
          <xsl:value-of select="$texto"/>
        </a>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- EN EL PANEL DE NOTAS Y EN EL TEXTO PLANO, EL NÚMERO SOLO -->
  <xsl:template match="db:xref | xref" mode="nota-panel texto-plano">
    <xsl:value-of select="nl:texto-referencia(
      nl:destino(string(@linkend), $piezasLibro), $piezasLibro)"/>
  </xsl:template>

  <!-- CITA DE FUENTE (blockquote role="source") → cita documental
       con la procedencia (attribution) al pie. Se distingue de la
       cita en bloque común por el role y la atribución. -->
  <xsl:template match="db:blockquote[@role='source'] | blockquote[@role='source']">
    <div class="cita-fuente">
      <xsl:for-each select="db:para | para">
        <p class="cita-fuente-texto"><xsl:apply-templates/></p>
      </xsl:for-each>
      <xsl:if test="db:attribution | attribution">
        <p class="cita-fuente-proc">
          <xsl:value-of select="normalize-space((db:attribution | attribution)[1])"/>
        </p>
      </xsl:if>
    </div>
  </xsl:template>

  <!-- BLOCKQUOTE → BLOCKQUOTE -->
  <xsl:template match="db:blockquote | blockquote">
    <blockquote>
      <xsl:apply-templates/>
    </blockquote>
  </xsl:template>

  <!-- ==========================================================
       TABLA (informaltable / table) → HTML <table>
       ==========================================================
       Modelo CALS de DocBook: tgroup > (thead|tbody) > row > entry.
       - entry en thead → <th>; en tbody → <td>.
       - La alineación de cada columna viene de colspec/@align (por
         posición). Se resuelve por el índice de la celda.
       - Si hay <title> (tabla formal), se emite como <caption>. -->

  <!-- CUADRO (SC-66): EL QUE ESCRIBIÓ cuadro-armar.lua. LA TABLA
       COMPLETA Y DERECHA; DEBAJO, COMO EN EL PDF, «Cuadro N» CON EL
       TÍTULO Y LA NOTA (EL <caption> DE DocBook), EN UN PÁRRAFO. EL NÚMERO ES
       EL DEL PDF (numeracion-libro.xsl). LOS NAVEGADORES NO APLICAN
       align="char": LA COLUMNA DE CIFRAS VA A LA DERECHA, CON CIFRAS
       TABULARES. LA INSTRUCCIÓN gb-cuadro ES DEL PDF: ACÁ NO SALE -->
  <xsl:template match="db:table[processing-instruction('gb-cuadro')]
                       | table[processing-instruction('gb-cuadro')]" priority="2">
    <xsl:variable name="specs" select="(db:tgroup | tgroup)[1]/(db:colspec | colspec)"/>
    <div class="tabla-wrapper cuadro" id="{@xml:id}">
      <table class="tabla-datos">
        <xsl:for-each select="(db:tgroup | tgroup)[1]/(db:thead | thead | db:tbody | tbody)">
          <xsl:element name="{local-name()}" namespace="http://www.w3.org/1999/xhtml">
            <xsl:for-each select="db:row | row">
              <tr>
                <xsl:for-each select="db:entry | entry">
                  <!-- LA COLUMNA LA DICE colname (cuadro-armar.lua): CON CELDAS
                       UNIDAS ARRIBA, LA POSICIÓN EN LA FILA NO. LA CELDA QUE
                       UNE COLUMNAS VA CENTRADA, COMO EN EL PDF -->
                  <xsl:variable name="al"
                    select="if (@namest) then 'center' else string($specs[@colname = current()/@colname]/@align)"/>
                  <xsl:element name="{if (ancestor::db:thead or ancestor::thead) then 'th' else 'td'}"
                               namespace="http://www.w3.org/1999/xhtml">
                    <xsl:if test="@namest">
                      <xsl:attribute name="colspan"
                        select="xs:integer(substring-after(@nameend, 'c')) - xs:integer(substring-after(@namest, 'c')) + 1"/>
                    </xsl:if>
                    <xsl:if test="@morerows">
                      <xsl:attribute name="rowspan" select="xs:integer(@morerows) + 1"/>
                    </xsl:if>
                    <xsl:choose>
                      <xsl:when test="$al = 'char'">
                        <xsl:attribute name="style">text-align: right; font-variant-numeric: tabular-nums</xsl:attribute>
                      </xsl:when>
                      <xsl:when test="$al = 'center'">
                        <xsl:attribute name="style">text-align: center</xsl:attribute>
                      </xsl:when>
                    </xsl:choose>
                    <xsl:apply-templates/>
                  </xsl:element>
                </xsl:for-each>
              </tr>
            </xsl:for-each>
          </xsl:element>
        </xsl:for-each>
      </table>
      <!-- EL PIE EN UN SOLO PÁRRAFO, COMO EN EL PDF (f:cuadro-pie): EL
           TÍTULO Y, A CONTINUACIÓN, LA NOTA, CON PUNTO SEGUIDO SI EL
           TÍTULO NO TERMINA EN . ? ! (decisión de Alberto) -->
      <xsl:variable name="titulo" select="normalize-space((db:title | title)[1])"/>
      <p class="cuadro-pie">
        <span class="cuadro-label">
          <xsl:text>Cuadro </xsl:text>
          <xsl:value-of select="nl:numero-cuadro(., $piezasLibro)"/>
        </span>
        <xsl:if test="$titulo != ''">
          <xsl:text>. </xsl:text>
          <xsl:apply-templates select="(db:title | title)[1]/node()"/>
        </xsl:if>
        <xsl:if test="db:caption | caption">
          <xsl:value-of select="if ($titulo = '' or not(matches($titulo, '[.?!]$'))) then '. ' else ' '"/>
          <xsl:for-each select="(db:caption | caption)/(db:para | para)">
            <xsl:if test="position() &gt; 1"><xsl:text> </xsl:text></xsl:if>
            <xsl:apply-templates/>
          </xsl:for-each>
        </xsl:if>
      </p>
    </div>
  </xsl:template>

  <xsl:template match="db:table | table | db:informaltable | informaltable">
    <div class="tabla-wrapper">
      <table class="tabla-datos">
        <xsl:variable name="titulo" select="normalize-space((db:title | title)[1])"/>
        <xsl:if test="$titulo != ''">
          <caption><xsl:value-of select="$titulo"/></caption>
        </xsl:if>
        <!-- ALINEACIONES POR COLUMNA (de los colspec del tgroup) -->
        <xsl:variable name="aligns"
                      select="(db:tgroup | tgroup)[1]/(db:colspec | colspec)/@align"/>
        <xsl:for-each select="(db:tgroup | tgroup)[1]/(db:thead | thead)">
          <thead>
            <xsl:for-each select="db:row | row">
              <tr>
                <xsl:for-each select="db:entry | entry">
                  <xsl:variable name="pos" select="position()"/>
                  <th>
                    <xsl:if test="$aligns[$pos]">
                      <xsl:attribute name="style">
                        <xsl:text>text-align: </xsl:text>
                        <xsl:value-of select="$aligns[$pos]"/>
                      </xsl:attribute>
                    </xsl:if>
                    <xsl:apply-templates/>
                  </th>
                </xsl:for-each>
              </tr>
            </xsl:for-each>
          </thead>
        </xsl:for-each>
        <xsl:for-each select="(db:tgroup | tgroup)[1]/(db:tbody | tbody)">
          <tbody>
            <xsl:for-each select="db:row | row">
              <tr>
                <xsl:for-each select="db:entry | entry">
                  <xsl:variable name="pos" select="position()"/>
                  <td>
                    <xsl:if test="$aligns[$pos]">
                      <xsl:attribute name="style">
                        <xsl:text>text-align: </xsl:text>
                        <xsl:value-of select="$aligns[$pos]"/>
                      </xsl:attribute>
                    </xsl:if>
                    <xsl:apply-templates/>
                  </td>
                </xsl:for-each>
              </tr>
            </xsl:for-each>
          </tbody>
        </xsl:for-each>
      </table>
    </div>
  </xsl:template>

  <!-- CÓDIGO EN BLOQUE (SC-42): EL BLOQUE DE gbc:bloque-html
       (codigo-comun.xsl), COMÚN CON LAS OTRAS SALIDAS DIGITALES, CON LAS
       LÍNEAS COLOREADAS POR colorear_codigo.sh -->
  <xsl:template match="db:programlisting | programlisting">
    <!-- SIN codigo_dir EL BLOQUE SALE SIN COLOR: SE AVISA, COMO EN EL PDF.
         LOS GENERADORES LA PASAN SIEMPRE -->
    <xsl:if test="normalize-space($codigo_dir) = ''">
      <xsl:message>[código] codigo_dir vacío: el bloque sale sin color</xsl:message>
    </xsl:if>
    <xsl:call-template name="gbc:bloque-html">
      <xsl:with-param name="el" select="."/>
      <xsl:with-param name="ns" select="'http://www.w3.org/1999/xhtml'"/>
      <xsl:with-param name="dir" select="$codigo_dir"/>
    </xsl:call-template>
  </xsl:template>

  <!-- LISTADO (SC-42): EL BLOQUE Y EL PIE «Código N», NUMERADO COMO EN
       EL PDF (nl:numero-listado). NO ENTRA EN EL PANEL DE FIGURAS -->
  <xsl:template match="db:example[@role = 'listado'] | example[@role = 'listado']" priority="5">
    <div class="gb-listado" id="{@xml:id}">
      <xsl:apply-templates select="db:programlisting | programlisting"/>
      <div class="fig-caption">
        <span class="fig-label">Código <xsl:value-of select="nl:numero-listado(., $piezasLibro)"/></span>
        <xsl:if test="normalize-space((db:title | title)[1]) != ''">
          <xsl:text>. </xsl:text>
          <xsl:apply-templates select="(db:title | title)[1]/node()"/>
        </xsl:if>
      </div>
    </div>
  </xsl:template>

  <!-- CÓDIGO INLINE (literal) → <code> -->
  <xsl:template match="db:literal | literal">
    <code class="code-inline"><xsl:apply-templates/></code>
  </xsl:template>

  <!-- LISTA DE DEFINICIÓN (variablelist) → <dl>.
       varlistentry > term → <dt>; varlistentry > listitem → <dd>. -->
  <xsl:template match="db:variablelist | variablelist">
    <dl class="lista-definicion">
      <xsl:for-each select="db:varlistentry | varlistentry">
        <xsl:for-each select="db:term | term">
          <dt><xsl:apply-templates/></dt>
        </xsl:for-each>
        <xsl:for-each select="db:listitem | listitem">
          <dd>
            <!-- SI EL listitem TIENE UN SOLO para, DESENVOLVERLO -->
            <xsl:choose>
              <xsl:when test="count(*) = 1 and (db:para | para)">
                <xsl:apply-templates select="(db:para | para)/node()"/>
              </xsl:when>
              <xsl:otherwise>
                <xsl:apply-templates/>
              </xsl:otherwise>
            </xsl:choose>
          </dd>
        </xsl:for-each>
      </xsl:for-each>
    </dl>
  </xsl:template>

  <!-- ==========================================================
       EPÍGRAFE (epigraph) → cita al inicio con atribución
       ==========================================================
       Estructura DocBook: <epigraph><attribution>...</attribution>
       <para>...</para></epigraph>. La atribución va al pie, alineada
       a la derecha. -->
  <xsl:template match="db:epigraph | epigraph">
    <div class="epigrafe">
      <xsl:for-each select="db:para | para">
        <p class="epigrafe-texto"><xsl:apply-templates/></p>
      </xsl:for-each>
      <!-- EL TEXTO PUEDE SER UN VERSO (SC-49): SUS ESTROFAS SON LOS
           <literallayout> DEL EPÍGRAFE -->
      <xsl:if test="db:literallayout[@role='verse'] | literallayout[@role='verse']">
        <xsl:call-template name="verso-html">
          <xsl:with-param name="poema" select="."/>
          <xsl:with-param name="clase" select="'verso-epigrafe'"/>
        </xsl:call-template>
      </xsl:if>
      <!-- LA ATRIBUCIÓN VA ABAJO, SIN RAYA (SC-35), Y CONSERVA SUS MARCAS -->
      <xsl:if test="db:attribution | attribution">
        <p class="epigrafe-atrib">
          <xsl:apply-templates select="(db:attribution | attribution)[1]/node()"/>
        </p>
      </xsl:if>
    </div>
  </xsl:template>

  <!-- ==========================================================
       ALERTAS / RECUADROS (admonitions + sidebar)
       ==========================================================
       EL VIEJO ::: {.box type="X"} SE RETIRÓ (SC-41): recuadros.lua LO
       FRENA. ESTAS PLANTILLAS QUEDAN PARA LOS CALLOUTS QUE VIENEN.
       Lo que el filtro Lua producía:
         - type="info"      → <sidebar role="info">
         - type="warning"   → <warning>
         - type="note"      → <note>
         - type="tip"       → <tip>
         - type="important" → <important>
         - type="caution"   → <caution>
       Cada uno se emite como .alerta con una clase de tipo que
       controla color e icono. Un template auxiliar unifica la
       estructura (icono a la izquierda, contenido a la derecha). -->
  <xsl:template match="db:note | note">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="'note'"/>
      <xsl:with-param name="etiqueta" select="'Nota'"/>
    </xsl:call-template>
  </xsl:template>
  <xsl:template match="db:tip | tip">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="'tip'"/>
      <xsl:with-param name="etiqueta" select="'Sugerencia'"/>
    </xsl:call-template>
  </xsl:template>
  <xsl:template match="db:important | important">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="'important'"/>
      <xsl:with-param name="etiqueta" select="'Importante'"/>
    </xsl:call-template>
  </xsl:template>
  <xsl:template match="db:warning | warning">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="'warning'"/>
      <xsl:with-param name="etiqueta" select="'Advertencia'"/>
    </xsl:call-template>
  </xsl:template>
  <xsl:template match="db:caution | caution">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="'caution'"/>
      <xsl:with-param name="etiqueta" select="'Precaución'"/>
    </xsl:call-template>
  </xsl:template>
  <!-- MATERIAL SUPLEMENTARIO (sidebar role="supplementary") → recuadro
       con etiqueta propia y el xml:id conservado para referencia. -->
  <xsl:template match="db:sidebar[@role='supplementary'] | sidebar[@role='supplementary']">
    <div class="suplementario">
      <xsl:if test="@xml:id">
        <xsl:attribute name="id"><xsl:value-of select="@xml:id"/></xsl:attribute>
      </xsl:if>
      <div class="suplementario-etiqueta">Material suplementario</div>
      <div class="suplementario-cuerpo">
        <xsl:apply-templates/>
      </div>
    </div>
  </xsl:template>

  <!-- RECUADROS (SC-41): sidebar role recuadro Y recuadro-barra, DE
       fenced-divs-to-elements-db.lua. MISMA SALIDA QUE jats-to-html.
       PRIORIDAD 5: POR ENCIMA DEL sidebar GENÉRICO -->
  <xsl:template match="db:sidebar[@role = ('recuadro', 'recuadro-barra')] |
                       sidebar[@role = ('recuadro', 'recuadro-barra')]" priority="5">
    <div class="recuadro{if (@role = 'recuadro-barra') then ' recuadro-barra' else ''}">
      <xsl:if test="@role = 'recuadro-barra'">
        <p class="recuadro-titulo"><xsl:apply-templates select="(db:title | title)[1]/node()"/></p>
      </xsl:if>
      <div class="recuadro-cuerpo">
        <xsl:apply-templates select="* except (db:title | title | db:info | info)"/>
      </div>
    </div>
  </xsl:template>

  <!-- SIDEBAR: recuadro genérico. role determina el tipo (ej. info). -->
  <xsl:template match="db:sidebar | sidebar">
    <xsl:call-template name="emitir-alerta">
      <xsl:with-param name="tipo" select="if (@role != '') then @role else 'info'"/>
      <xsl:with-param name="etiqueta"
                      select="if (@role = 'info') then 'Información' else 'Nota'"/>
    </xsl:call-template>
  </xsl:template>

  <!-- ESTRUCTURA COMÚN DE ALERTA: icono a la izquierda + contenido -->
  <xsl:template name="emitir-alerta">
    <xsl:param name="tipo"/>
    <xsl:param name="etiqueta"/>
    <div class="alerta alerta-{$tipo}" role="note">
      <div class="alerta-icono" aria-hidden="true"></div>
      <div class="alerta-cuerpo">
        <xsl:apply-templates/>
      </div>
    </div>
  </xsl:template>

  <!-- ==========================================================
       VERSO (SC-49): <blockquote role="verso">, UN <literallayout>
       POR ESTROFA Y UN <phrase role="linea"> POR VERSO
       (verso-comun.xsl). SALE div.verso CON UN div.estrofa POR
       ESTROFA Y UN span.verso-linea POR VERSO; LA SANGRÍA ES LA
       CLASE nivel-N, QUE EL CSS RESUELVE CON text-indent (1,5 em
       POR NIVEL, EL \vgap DEL PDF). LOS VERSOS CONSERVAN SUS MARCAS,
       CITAS Y NOTAS.
       ========================================================== -->
  <xsl:template match="db:blockquote[@role='verso'] | blockquote[@role='verso']" priority="5">
    <xsl:call-template name="verso-html">
      <xsl:with-param name="poema" select="."/>
    </xsl:call-template>
  </xsl:template>

  <!-- UN <literallayout role="verse"> SUELTO SOLO PUEDE SER DE UN
       CANÓNICO VIEJO: SE FRENA (gbvr:frenar-si-viejo). SI NO LO FUERA,
       SALE COMO UN POEMA DE UNA ESTROFA. -->
  <xsl:template match="db:literallayout[@role='verse'] | literallayout[@role='verse']" priority="5">
    <xsl:call-template name="verso-html">
      <xsl:with-param name="poema" select="."/>
    </xsl:call-template>
  </xsl:template>

  <!-- ============================================
       PLANTILLA : verso-html
       PROPÓSITO : ESCRIBE UN POEMA
       PARÁMETROS: poema — blockquote, epigraph O literallayout;
                   clase — clase de más (verso-epigrafe EN UN EPÍGRAFE)
       ============================================ -->
  <xsl:template name="verso-html">
    <xsl:param name="poema" as="element()"/>
    <xsl:param name="clase" as="xs:string" select="''"/>
    <xsl:variable name="estrofas" select="if (local-name($poema) = 'literallayout')
                                          then $poema else gbvr:estrofas($poema)"/>
    <xsl:call-template name="gbvr:frenar-si-viejo">
      <xsl:with-param name="estrofas" select="$estrofas"/>
    </xsl:call-template>
    <div class="{normalize-space(concat('verso ', $clase))}">
      <xsl:for-each select="$estrofas">
        <div class="estrofa">
          <xsl:for-each select="gbvr:versos(.)">
            <xsl:variable name="nivel" select="gbvr:nivel(.)"/>
            <span class="verso-linea{if ($nivel gt 0) then concat(' nivel-', $nivel) else ''}">
              <xsl:apply-templates/>
            </span>
          </xsl:for-each>
        </div>
      </xsl:for-each>
    </div>
  </xsl:template>

  <!-- LITERALLAYOUT GENÉRICO (sin role verse) → pre simple -->
  <xsl:template match="db:literallayout | literallayout">
    <pre class="literallayout"><xsl:value-of select="."/></pre>
  </xsl:template>

  <!-- FROUFROU (SC-36): TRES ASTERISCOS A 1 cm, CENTRADOS. CADA UNO EN
       SU span Y SIN ESPACIOS ENTRE ELLOS: LA DISTANCIA LA DA EL MARGEN,
       NO LA FUENTE. role="separator" PARA LOS LECTORES DE PANTALLA. -->
  <xsl:template match="db:para[@role='froufrou'] | para[@role='froufrou']" priority="5">
    <div class="froufrou" role="separator"><span>*</span><span>*</span><span>*</span></div>
  </xsl:template>

  <!-- ==========================================================
       CONVERSACIÓN (SC-43): qandaset role="conversacion"
       ==========================================================
       UN div.conversacion; CADA TURNO, UN div.turno CON SU CLASE
       (turno-pregunta | turno-respuesta). LA ETIQUETA, EN MAYÚSCULAS
       (gbv:etiqueta), ABRE EL PRIMER PÁRRAFO EN UN span.turno-etiqueta:
       NEGRITA Y, EN EL HTML, EL COLOR DE LA HOJA DE ESTILOS, EN LOS DOS
       TURNOS. LA ACOTACIÓN ES UN p.acotacion. -->
  <xsl:template match="db:qandaset[@role = 'conversacion'] | qandaset[@role = 'conversacion']">
    <div class="conversacion">
      <xsl:apply-templates select="*"/>
    </div>
  </xsl:template>

  <xsl:template match="db:qandaentry | qandaentry">
    <xsl:apply-templates select="db:question | question | db:answer | answer"/>
  </xsl:template>

  <xsl:template match="db:question | question | db:answer | answer">
    <xsl:variable name="bloques" select="gbv:bloques(.)"/>
    <div class="turno {if (gbv:es-pregunta(.)) then 'turno-pregunta' else 'turno-respuesta'}">
      <xsl:choose>
        <!-- LO HABITUAL: LA ETIQUETA ABRE EL PRIMER PÁRRAFO, EN LÍNEA -->
        <xsl:when test="$bloques[1][self::db:para or self::para]">
          <p>
            <span class="turno-etiqueta"><xsl:value-of select="gbv:etiqueta(.)"/></span>
            <xsl:text> </xsl:text>
            <xsl:apply-templates select="$bloques[1]/node()"/>
          </p>
          <xsl:apply-templates select="$bloques[position() gt 1]"/>
        </xsl:when>
        <!-- UN TURNO QUE EMPIEZA CON UNA LISTA U OTRO BLOQUE: LA ETIQUETA
             VA SOLA EN SU PÁRRAFO -->
        <xsl:otherwise>
          <p><span class="turno-etiqueta"><xsl:value-of select="gbv:etiqueta(.)"/></span></p>
          <xsl:apply-templates select="$bloques"/>
        </xsl:otherwise>
      </xsl:choose>
    </div>
  </xsl:template>

  <xsl:template match="db:para[@role = 'acotacion'] | para[@role = 'acotacion']">
    <p class="acotacion"><xsl:apply-templates/></p>
  </xsl:template>

  <!-- EMPHASIS → EM / STRONG SEGÚN role -->
  <xsl:template match="db:emphasis | emphasis">
    <!-- LOS role DE PANDOC (SC-30): strong/bold, smallcaps, strikethrough
         Y underline. SIN LOS TRES ÚLTIMOS SALÍAN EN BASTARDILLA. LOS
         ELEMENTOS SON LOS QUE USA EL ESCRITOR HTML DE PANDOC: <del>, <u>
         Y UNA CLASE PARA LAS VERSALITAS, QUE DEFINE LA HOJA DE ESTILOS. -->
    <xsl:choose>
      <xsl:when test="@role = 'bold' or @role = 'strong'">
        <strong><xsl:apply-templates/></strong>
      </xsl:when>
      <xsl:when test="@role = 'smallcaps'">
        <span class="versalitas"><xsl:apply-templates/></span>
      </xsl:when>
      <xsl:when test="@role = 'strikethrough'">
        <del><xsl:apply-templates/></del>
      </xsl:when>
      <xsl:when test="@role = 'underline'">
        <u><xsl:apply-templates/></u>
      </xsl:when>
      <xsl:otherwise>
        <em><xsl:apply-templates/></em>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- SUPERÍNDICE Y SUBÍNDICE (SC-30). NO HABÍA PLANTILLA: LA REGLA
       INCORPORADA DEJABA EL TEXTO, Y x^2^ SALÍA «x2». -->
  <xsl:template match="db:superscript | superscript">
    <sup><xsl:apply-templates/></sup>
  </xsl:template>
  <xsl:template match="db:subscript | subscript">
    <sub><xsl:apply-templates/></sub>
  </xsl:template>


  <!-- FOOTNOTE → MARCA <sup> NUMERADA POR CAPÍTULO.
       LLEVA data-fn-id Y data-fn-text PARA QUE EL JS CONSTRUYA
       EL PANEL DE NOTAS Y CABLEE LA NAVEGACIÓN CRUZADA.
       CLASES fn-ref ALINEADAS CON REVISTAS.
       NUMERACIÓN CORRELATIVA POR CAPÍTULO CON xsl:number. -->
  <xsl:template match="db:footnote | footnote">
    <xsl:variable name="num">
      <xsl:number count="db:footnote | footnote"
                  from="db:chapter | db:preface | db:appendix | db:dedication
                        | db:colophon | db:glossary
                        | chapter | preface | appendix | dedication
                        | colophon | glossary"
                  level="any"/>
    </xsl:variable>
    <!-- EL CONTENIDO DE LA NOTA VA AL data-fn-text COMO HTML
         SERIALIZADO, Y EL JS LO INYECTA EN EL PANEL CON innerHTML.
         ANTES IBA COMO TEXTO PLANO (MODO texto-plano): EL PANEL PERDÍA
         LA BASTARDILLA, Y UN «<» DEL TEXTO SE LEÍA COMO MARCADO. EL
         MODO nota-panel CONSERVA EL FORMATO EN LÍNEA Y DEJA LA CITA COMO
         TEXTO RESUELTO, SIN EL ENLACE CON onclick: EL ÍTEM DEL PANEL YA
         TIENE EL SUYO. -->
    <xsl:variable name="notaHtml">
      <xsl:apply-templates select="db:para | para" mode="nota-panel"/>
    </xsl:variable>
    <sup class="fn-ref nota-ref"
         data-fn-id="{$num}"
         data-fn-text="{normalize-space(serialize($notaHtml,
                          map{'method':'html', 'html-version':5.0, 'indent':false()}))}"
         onclick="highlightPanel('notas','{$num}')"
         style="cursor:pointer">
      <xsl:value-of select="$num"/>
    </sup>
  </xsl:template>

  <!-- ==========================================================
       MODO nota-panel: EL CONTENIDO DE UNA NOTA PARA EL PANEL LATERAL
       ==========================================================
       CONSERVA LO QUE ES FORMATO DEL TEXTO —BASTARDILLA, NEGRITA,
       SUPERÍNDICE, SUBÍNDICE, CÓDIGO, ENLACES— Y DESARMA LO DEMÁS.
       LA CITA PASA POR EL MODO texto-plano, QUE LA DIBUJA RESUELTA
       «(Autor, año)» SIN ENLACE. LAS COMILLAS LAS PONE quote.xsl, QUE
       ATIENDE TODOS LOS MODOS. CADA PÁRRAFO DE LA NOTA ES UN <p>.
       LOS ELEMENTOS VAN SIN ESPACIO DE NOMBRES (xmlns=""): SI NO, LA
       SERIALIZACIÓN ESCRIBE xmlns="http://www.w3.org/1999/xhtml" EN CADA
       UNO. normalize-space SOBRE LO SERIALIZADO QUITA LA SANGRÍA QUE
       TRAE EL CANÓNICO; EN HTML EL ESPACIO SE COLAPSA IGUAL. -->
  <xsl:template match="*" mode="nota-panel">
    <xsl:apply-templates mode="nota-panel"/>
  </xsl:template>
  <xsl:template match="text()" mode="nota-panel">
    <xsl:value-of select="."/>
  </xsl:template>
  <xsl:template match="db:para | para" mode="nota-panel">
    <p xmlns=""><xsl:apply-templates mode="nota-panel"/></p>
  </xsl:template>
  <xsl:template match="db:emphasis | emphasis" mode="nota-panel">
    <xsl:choose>
      <xsl:when test="@role = 'bold' or @role = 'strong'">
        <strong xmlns=""><xsl:apply-templates mode="nota-panel"/></strong>
      </xsl:when>
      <xsl:when test="@role = 'smallcaps'">
        <span xmlns="" class="versalitas"><xsl:apply-templates mode="nota-panel"/></span>
      </xsl:when>
      <xsl:when test="@role = 'strikethrough'">
        <del xmlns=""><xsl:apply-templates mode="nota-panel"/></del>
      </xsl:when>
      <xsl:when test="@role = 'underline'">
        <u xmlns=""><xsl:apply-templates mode="nota-panel"/></u>
      </xsl:when>
      <xsl:otherwise>
        <em xmlns=""><xsl:apply-templates mode="nota-panel"/></em>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  <xsl:template match="db:superscript | superscript" mode="nota-panel">
    <sup xmlns=""><xsl:apply-templates mode="nota-panel"/></sup>
  </xsl:template>
  <xsl:template match="db:subscript | subscript" mode="nota-panel">
    <sub xmlns=""><xsl:apply-templates mode="nota-panel"/></sub>
  </xsl:template>
  <xsl:template match="db:literal | literal | db:code | code" mode="nota-panel">
    <code xmlns=""><xsl:apply-templates mode="nota-panel"/></code>
  </xsl:template>
  <xsl:template match="db:link | link" mode="nota-panel">
    <a xmlns="" href="{@xlink:href}" target="_blank" rel="noopener noreferrer">
      <xsl:apply-templates mode="nota-panel"/>
    </a>
  </xsl:template>
  <xsl:template match="db:biblioref | biblioref" mode="nota-panel">
    <xsl:apply-templates select="." mode="texto-plano"/>
  </xsl:template>
  <xsl:template match="db:phrase[@role='cite-prefix'] | phrase[@role='cite-prefix']
                     | db:phrase[@role='cite-suffix'] | phrase[@role='cite-suffix']"
                mode="nota-panel"/>

  <!-- MODO texto-plano: SERIALIZA EL CONTENIDO DE UNA NOTA A TEXTO
       SIN MARKUP, PARA EL data-fn-text. -->
  <xsl:template match="*" mode="texto-plano">
    <xsl:apply-templates mode="texto-plano"/>
    <xsl:text> </xsl:text>
  </xsl:template>
  <xsl:template match="text()" mode="texto-plano">
    <xsl:value-of select="."/>
  </xsl:template>

  <!-- TEMPLATE ESPECÍFICO PARA biblioref EN MODO texto-plano:
       EL biblioref ES EMPTY (RC-DB-01), ASÍ QUE EL GENÉRICO "*" NO
       PRODUCE NADA Y LA CITA SE PIERDE DEL data-fn-text. SOLUCIÓN
       (PORTADA DE jats-to-html.xsl): RENDERIZAR EL biblioref EN MODO
       DEFAULT (QUE PRODUCE "(Autor, año)" O "[N]") Y EXTRAER EL TEXTO
       PLANO CON string(). ASÍ LA NOTA MUESTRA LA CITA RESUELTA EN LUGAR
       DE PERDERLA. NO HAY RECURSIÓN: texto-plano Y default SON MODOS
       DISTINTOS. -->
  <xsl:template match="db:biblioref | biblioref" mode="texto-plano">
    <xsl:variable name="render">
      <xsl:apply-templates select="."/>
    </xsl:variable>
    <xsl:value-of select="string($render)"/>
  </xsl:template>
  <!-- LOS phrase DE PREFIJO Y SUFIJO NO SE IMPRIMEN EN LA NOTA: LA CITA,
       QUE EN ESTE MODO SE DIBUJA EN MODO DEFAULT, YA LOS ABSORBE DENTRO DEL
       PARÉNTESIS. ANTES ESTA PLANTILLA LOS IMPRIMÍA OTRA VEZ, Y EL SUFIJO
       SALÍA DOBLE: «(Hodges et al., 2020, p. 17 p. 17 …» -->
  <xsl:template match="db:phrase[@role='cite-prefix'] | phrase[@role='cite-prefix']
                     | db:phrase[@role='cite-suffix'] | phrase[@role='cite-suffix']"
                mode="texto-plano"/>

  <!-- ==========================================================
       ========= MARCAS DE CITA EN EL TEXTO (biblioref) =========
       ==========================================================
       Renderiza las marcas de cita del cuerpo según $estilo_cita:
         - APA / ISO690 (author-date): (Autor, año) / Autor (año)
         - Vancouver / IEEE (numérico): [N]
       Portado del jats-to-html.xsl al vocabulario DocBook.

       VOCABULARIO DOCBOOK (RC-DB-01: biblioref es EMPTY):
         <phrase role="cite-prefix">ver</phrase>
         <biblioref linkend="bib-X" role="suppress|author-in-text"/>
         <phrase role="cite-suffix">p. 5</phrase>
       El modo viaja en @role; prefijo/sufijo como phrase HERMANOS.

       AGRUPACIÓN POR ADYACENCIA: citas consecutivas [@a; @b] llegan
       como biblioref separados por texto ', '. Se agrupan detectando
       adyacencia, saltando los phrase de prefijo/sufijo intercalados. -->

  <!-- DESPACHADOR: author-date o numérico según estilo -->
  <xsl:template match="db:biblioref | biblioref">
    <xsl:choose>
      <!-- CON citas.html: EL TEXTO DE biblatex (SC-57) -->
      <xsl:when test="$gbct:tex4ht">
        <xsl:call-template name="cita-tex4ht"/>
      </xsl:when>
      <xsl:when test="$estilo_cita = 'vancouver' or $estilo_cita = 'ieee'">
        <xsl:call-template name="xref-numerico-db"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:call-template name="xref-autor-anio-db"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       CITAS DESDE citas.html (SC-57)
       ==========================================================
       EL GRUPO LO DIBUJA SU PRIMER biblioref CON EL TEXTO QUE ESCRIBIÓ
       biblatex; LOS DEMÁS NO EMITEN NADA. EL AGRUPAMIENTO ES EL DEL PDF
       (cita-comun.xsl): ASÍ EL id ES EL MISMO QUE PUSO LA PASADA. -->
  <xsl:template name="cita-tex4ht">
    <xsl:if test="not(gbct:es-continuacion(., $estilo_cita))">
      <xsl:apply-templates select="gbct:fragmento-cita(., nl:pieza-de(.))" mode="gbct:fragmento">
        <xsl:with-param name="grupo" select="gbct:grupo-desde(., $estilo_cita)" tunnel="yes"/>
      </xsl:apply-templates>
    </xsl:if>
  </xsl:template>

  <!-- EL ENLACE DE UNA CITA A SU REFERENCIA (CONTRATO DE
       cita-fragmentos.xsl): EL MISMO QUE ARMAN LAS PLANTILLAS POR ESTILO -->
  <xsl:template name="gbct:enlace-cita">
    <xsl:param name="rid" as="xs:string"/>
    <xsl:param name="contenido"/>
    <a class="xref-bibr cita-ref" data-ref-id="{$rid}"
       onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
      <xsl:copy-of select="$contenido"/>
    </a>
  </xsl:template>

  <!-- EL SEPARADOR ENTRE DOS CITAS, CON citas.html: SE SUPRIME SOLO SI LA
       CITA QUE SIGUE QUEDÓ EN EL GRUPO DE LA ANTERIOR (EL DELIMITADOR LO
       PUSO biblatex); SI NO, ES TEXTO. LA MISMA REGLA QUE EL PDF. GANA AL
       SUPRESOR DE ABAJO, QUE SUPRIME TODO SEPARADOR ENTRE DOS CITAS -->
  <xsl:template match="text()[$gbct:tex4ht][gbct:es-separador(.)]
                             [exists(gbct:biblioref-tras-separador(.))]"
                mode="#default texto-plano nota-panel" priority="10">
    <xsl:if test="not(gbct:es-continuacion(gbct:biblioref-tras-separador(.), $estilo_cita))">
      <xsl:value-of select="."/>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       PANEL DE REFERENCIAS DESDE citas.html (SC-57)
       ==========================================================
       LAS ENTRADAS QUE IMPRIMIÓ biblatex, EN SU ORDEN: LAS MISMAS QUE
       EL PDF. CADA UNA SE UNE CON SU biblioentry POR LA CLAVE, PARA EL
       data-ref-id QUE USAN EL PANEL Y LAS CITAS. LA BIBLIOGRAFÍA ES LA
       DEL CAPÍTULO SI TRAE <bibliography>; SI NO, LA CONSOLIDADA. -->
  <xsl:template name="panel-refs-tex4ht">
    <xsl:param name="capitulo"/>
    <xsl:variable name="marca" select="gbct:marca-bib($capitulo)"/>
    <xsl:variable name="fuente"
                  select="if ($marca = 'libro') then ($book/db:bibliography | $book/bibliography)
                          else $capitulo//db:bibliography"/>
    <!-- LA MARCA SE EXIGE CUANDO HAY UNA BIBLIOGRAFÍA QUE LA PIDA: SIN
         ELLA, citas.html ES DE OTRO CANÓNICO -->
    <xsl:variable name="entradas"
                  select="gbct:entradas-bib($marca, exists($fuente), gbct:estilo-numerico($estilo_cita))"/>
    <!-- EN UN ESTILO NUMÉRICO, LA SANGRÍA DE LA ETIQUETA MÁS ANCHA -->
    <xsl:variable name="clase-num" select="gbct:clase-etiquetas($entradas)"/>
    <xsl:choose>
      <xsl:when test="exists($entradas)">
        <xsl:for-each select="$entradas">
          <xsl:variable name="clave" select="gbct:clave-entrada(.)"/>
          <xsl:variable name="entrada"
                        select="($fuente//db:biblioentry)[gbct:clave(@xml:id) = $clave][1]"/>
          <xsl:if test="empty($entrada)">
            <xsl:message terminate="yes">
              <xsl:text>[docbook-to-html] biblatex imprimió </xsl:text>
              <xsl:value-of select="$clave"/>
              <xsl:text> y la bibliografía del canónico no la tiene (</xsl:text>
              <xsl:value-of select="$marca"/>
              <xsl:text>).</xsl:text>
            </xsl:message>
          </xsl:if>
          <!-- ref-biblatex: LA SANGRÍA FRANCESA DE gbpublisher.css, SOLO PARA
               ESTAS ENTRADAS: LA HOJA ES COMÚN CON REVISTAS -->
          <div class="panel-item ref-item ref-biblatex{$clase-num}"
               data-ref-id="{$entrada/@xml:id}"
               onclick="irAlTexto('{$entrada/@xml:id}')"
               style="cursor:pointer">
            <xsl:call-template name="gbct:etiqueta">
              <xsl:with-param name="dd" select="."/>
            </xsl:call-template>
            <xsl:apply-templates select="." mode="gbct:fragmento"/>
          </div>
        </xsl:for-each>
      </xsl:when>
      <xsl:otherwise>
        <p class="drawer-vacio">Sin referencias.</p>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       SUPRESORES: phrase de prefijo/sufijo y separadores de grupo
       ==========================================================
       Los phrase cite-prefix/cite-suffix los ABSORBE el template del
       biblioref (para meterlos dentro del paréntesis en author-date).
       Se suprimen aquí para que no se rendericen sueltos. -->
  <xsl:template match="db:phrase[@role='cite-prefix'] | phrase[@role='cite-prefix']"/>
  <xsl:template match="db:phrase[@role='cite-suffix'] | phrase[@role='cite-suffix']"/>

  <!-- SUPRIMIR EL WHITESPACE RESIDUAL QUE SEPARA UN phrase (PREFIJO O
       SUFIJO, YA ABSORBIDO POR EL biblioref) DEL TEXTO CONTIGUO. SIN
       ESTO, EL NAVEGADOR COLAPSA ESE SALTO DE LÍNEA A UN ESPACIO Y
       QUEDA ' .' O '( ' ALREDEDOR DE LA CITA.
       CASO 1: whitespace ENTRE biblioref Y SU phrase-suffix. -->
  <xsl:template match="text()[normalize-space(.) = '']
    [preceding-sibling::node()[1][self::db:biblioref or self::biblioref]]
    [following-sibling::node()[1][self::db:phrase[@role='cite-suffix'] or self::phrase[@role='cite-suffix']]]"
    mode="#default texto-plano nota-panel"/>
  <!-- CASO 2: whitespace ENTRE un phrase-prefix Y SU biblioref. -->
  <xsl:template match="text()[normalize-space(.) = '']
    [preceding-sibling::node()[1][self::db:phrase[@role='cite-prefix'] or self::phrase[@role='cite-prefix']]]
    [following-sibling::node()[1][self::db:biblioref or self::biblioref]]"
    mode="#default texto-plano nota-panel"/>

  <!-- SUPRIMIR EL TEXTO SEPARADOR ', ' / '; ' ENTRE DOS biblioref
       DE UN MISMO GRUPO (LA AGRUPACIÓN LO EMITE EL PRIMERO).
       SE COMPARA CONTRA EL VECINO NO-WHITESPACE.
       ESTOS TRES SUPRESORES VALEN TAMBIÉN EN LOS MODOS texto-plano Y
       nota-panel, LOS DE LAS NOTAS: SIN ESO, EN UNA NOTA EL SEPARADOR Y
       LOS ESPACIOS SE ESCAPABAN ALREDEDOR DE LA CITA. -->
  <xsl:template match="text()[matches(., '^\s*[,;]\s*$')]
    [preceding-sibling::node()[not(self::text() and normalize-space(.)='')][1]
       [self::db:biblioref or self::biblioref
        or self::db:phrase[@role='cite-suffix'] or self::phrase[@role='cite-suffix']]]
    [following-sibling::node()[not(self::text() and normalize-space(.)='')][1]
       [self::db:biblioref or self::biblioref
        or self::db:phrase[@role='cite-prefix'] or self::phrase[@role='cite-prefix']]]"
    mode="#default texto-plano nota-panel"/>

  <!-- ==========================================================
       AUXILIAR: prefijo/sufijo hermanos de un biblioref
       ==========================================================
       Devuelven el phrase adyacente (o vacío). El prefijo es el
       phrase inmediatamente anterior; el sufijo, el posterior. -->
  <xsl:template name="phrase-prefijo-de">
    <!-- EL PHRASE PREFIJO PUEDE ESTAR SEPARADO DEL biblioref POR UN
         text() DE SOLO ESPACIOS (SALTO DE LÍNEA + SANGRÍA DEL CANÓNICO).
         SE BUSCA EL PRIMER preceding-sibling NO-WHITESPACE. -->
    <xsl:variable name="prev"
      select="preceding-sibling::node()[not(self::text() and normalize-space(.) = '')][1]"/>
    <xsl:if test="$prev[self::db:phrase[@role='cite-prefix'] or self::phrase[@role='cite-prefix']]">
      <xsl:apply-templates select="$prev/node()"/>
      <xsl:text> </xsl:text>
    </xsl:if>
  </xsl:template>

  <xsl:template name="phrase-sufijo-de">
    <!-- ÍDEM: EL PHRASE SUFIJO PUEDE ESTAR SEPARADO POR WHITESPACE. -->
    <xsl:variable name="next"
      select="following-sibling::node()[not(self::text() and normalize-space(.) = '')][1]"/>
    <xsl:if test="$next[self::db:phrase[@role='cite-suffix'] or self::phrase[@role='cite-suffix']]">
      <xsl:text>, </xsl:text>
      <xsl:apply-templates select="$next/node()"/>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: resolver autor de una cita desde su biblioentry
       ==========================================================
       Busca el biblioentry por xml:id (= linkend) y devuelve el
       surname formateado: 1 autor → "Apellido"; 2 → "A y B";
       3+ → "A et al.". Usa autores, o editores como fallback. -->
  <xsl:template name="resolver-autor-cita-db">
    <xsl:param name="rid"/>
    <xsl:variable name="entry"
                  select="(//db:biblioentry | //biblioentry)[@xml:id = $rid][1]"/>
    <xsl:variable name="personas"
                  select="$entry/db:author | $entry/author"/>
    <xsl:variable name="editores"
                  select="$entry/db:editor | $entry/editor"/>
    <xsl:choose>
      <xsl:when test="$personas">
        <xsl:call-template name="formatear-surnames-cita">
          <xsl:with-param name="lista" select="$personas"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$editores">
        <xsl:call-template name="formatear-surnames-cita">
          <xsl:with-param name="lista" select="$editores"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <!-- SIN AUTOR: USAR EL citekey VISIBLE (SIN PREFIJO bib-) -->
        <xsl:value-of select="if (starts-with($rid, 'bib-'))
                              then substring-after($rid, 'bib-') else $rid"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- FORMATEA SURNAMES SEGÚN CANTIDAD (1 / 2 / 3+) -->
  <xsl:template name="formatear-surnames-cita">
    <xsl:param name="lista"/>
    <xsl:variable name="n" select="count($lista)"/>
    <xsl:choose>
      <xsl:when test="$n = 1">
        <xsl:value-of select="normalize-space(($lista[1]/db:personname/db:surname
                                              | $lista[1]/personname/surname)[1])"/>
      </xsl:when>
      <xsl:when test="$n = 2">
        <xsl:value-of select="normalize-space(($lista[1]/db:personname/db:surname
                                              | $lista[1]/personname/surname)[1])"/>
        <xsl:text> y </xsl:text>
        <xsl:value-of select="normalize-space(($lista[2]/db:personname/db:surname
                                              | $lista[2]/personname/surname)[1])"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="normalize-space(($lista[1]/db:personname/db:surname
                                              | $lista[1]/personname/surname)[1])"/>
        <xsl:text> et al.</xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- AÑO DE UNA CITA DESDE SU biblioentry (pubdate) -->
  <xsl:template name="resolver-anio-cita-db">
    <xsl:param name="rid"/>
    <xsl:variable name="entry"
                  select="(//db:biblioentry | //biblioentry)[@xml:id = $rid][1]"/>
    <xsl:value-of select="normalize-space(($entry/db:pubdate | $entry/pubdate)[1])"/>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: detectar si un biblioref es PRIMERO de su grupo
       ==========================================================
       Es primero si NO hay, inmediatamente antes (saltando su phrase
       prefijo), un separador ',/;' precedido por otro biblioref/sufijo. -->
  <xsl:template name="es-primera-cita-grupo">
    <!-- NODO ANTERIOR NO-WHITESPACE, SALTANDO EL PHRASE DE PREFIJO SI EXISTE -->
    <xsl:variable name="prev1"
      select="preceding-sibling::node()[not(self::text() and normalize-space(.)='')][1]"/>
    <xsl:variable name="ancla"
      select="if ($prev1[self::db:phrase[@role='cite-prefix'] or self::phrase[@role='cite-prefix']])
              then preceding-sibling::node()[not(self::text() and normalize-space(.)='')][2]
              else $prev1"/>
    <!-- ES PRIMERA SI EL ANCLA NO ES UN SEPARADOR DE GRUPO -->
    <xsl:sequence select="not($ancla[self::text() and matches(., '^\s*[,;]\s*$')])"/>
  </xsl:template>

  <!-- ==========================================================
       AUTHOR-DATE (APA / ISO690): (Autor, año) con 3 modos
       ==========================================================
       Modos: normal (Autor, año) · suppress (año) · author-in-text
       Autor (año). Prefijo/sufijo dentro del paréntesis. Agrupa
       citas consecutivas con '; '. -->
  <xsl:template name="xref-autor-anio-db">
    <xsl:variable name="rid" select="@linkend"/>
    <xsl:variable name="modo" select="if (@role != '') then @role else 'normal'"/>
    <xsl:variable name="autor">
      <xsl:call-template name="resolver-autor-cita-db">
        <xsl:with-param name="rid" select="$rid"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="anio">
      <xsl:call-template name="resolver-anio-cita-db">
        <xsl:with-param name="rid" select="$rid"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="esPrimera">
      <xsl:call-template name="es-primera-cita-grupo"/>
    </xsl:variable>
    <!-- ¿ES LA ÚLTIMA DEL GRUPO? EL SIGUIENTE (SALTANDO SUFIJO) NO ES SEP -->
    <xsl:variable name="next1"
      select="following-sibling::node()[not(self::text() and normalize-space(.)='')][1]"/>
    <xsl:variable name="anclaSig"
      select="if ($next1[self::db:phrase[@role='cite-suffix'] or self::phrase[@role='cite-suffix']])
              then following-sibling::node()[not(self::text() and normalize-space(.)='')][2]
              else $next1"/>
    <xsl:variable name="esUltima"
      select="not($anclaSig[self::text() and matches(., '^\s*[,;]\s*$')])"/>

    <xsl:choose>

      <!-- AUTHOR-IN-TEXT: Autor (año) — SIN PARÉNTESIS EXTERIOR -->
      <xsl:when test="$modo = 'author-in-text'">
        <!-- PREFIJO ANTES DEL AUTOR (RARO EN ESTE MODO, PERO SE RESPETA) -->
        <xsl:call-template name="phrase-prefijo-de"/>
        <a class="xref-bibr cita-ref" data-ref-id="{$rid}"
           onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
          <xsl:value-of select="$autor"/>
        </a>
        <xsl:text> (</xsl:text>
        <a class="xref-bibr cita-ref" data-ref-id="{$rid}"
           onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
          <xsl:value-of select="$anio"/>
        </a>
        <xsl:call-template name="phrase-sufijo-de"/>
        <xsl:text>)</xsl:text>
      </xsl:when>

      <!-- SUPPRESS: (año) — SIN AUTOR -->
      <xsl:when test="$modo = 'suppress'">
        <xsl:if test="$esPrimera = true()">
          <xsl:text>(</xsl:text>
          <xsl:call-template name="phrase-prefijo-de"/>
        </xsl:if>
        <!-- UNA CITA QUE NO ES LA PRIMERA DEL GRUPO TAMBIÉN PUEDE LLEVAR
             PREFIJO: [@a; en @b]. ANTES SE PERDÍA SIN AVISO -->
        <xsl:if test="$esPrimera = false()">
          <xsl:text>; </xsl:text>
          <xsl:call-template name="phrase-prefijo-de"/>
        </xsl:if>
        <a class="xref-bibr cita-ref" data-ref-id="{$rid}"
           onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
          <xsl:value-of select="$anio"/>
          <xsl:call-template name="phrase-sufijo-de"/>
        </a>
        <xsl:if test="$esUltima"><xsl:text>)</xsl:text></xsl:if>
      </xsl:when>

      <!-- NORMAL: (Autor, año) -->
      <xsl:otherwise>
        <xsl:if test="$esPrimera = true()">
          <xsl:text>(</xsl:text>
          <xsl:call-template name="phrase-prefijo-de"/>
        </xsl:if>
        <!-- UNA CITA QUE NO ES LA PRIMERA DEL GRUPO TAMBIÉN PUEDE LLEVAR
             PREFIJO: [@a; en @b]. ANTES SE PERDÍA SIN AVISO -->
        <xsl:if test="$esPrimera = false()">
          <xsl:text>; </xsl:text>
          <xsl:call-template name="phrase-prefijo-de"/>
        </xsl:if>
        <a class="xref-bibr cita-ref" data-ref-id="{$rid}"
           onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
          <xsl:value-of select="$autor"/>
          <xsl:if test="$anio != ''">
            <xsl:text>, </xsl:text><xsl:value-of select="$anio"/>
          </xsl:if>
          <xsl:call-template name="phrase-sufijo-de"/>
        </a>
        <xsl:if test="$esUltima"><xsl:text>)</xsl:text></xsl:if>
      </xsl:otherwise>

    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       NUMÉRICO (Vancouver / IEEE): [N]
       ==========================================================
       N = posición del biblioentry en la bibliography del capítulo
       (reinicia por capítulo). Agrupa consecutivas como [1,2,3],
       un <a> por número. Prefijo antes del corchete, sufijo dentro. -->
  <xsl:template name="xref-numerico-db">
    <xsl:variable name="rid" select="@linkend"/>
    <xsl:variable name="modo" select="if (@role != '') then @role else 'normal'"/>
    <xsl:variable name="esPrimera">
      <xsl:call-template name="es-primera-cita-grupo"/>
    </xsl:variable>
    <xsl:variable name="next1"
      select="following-sibling::node()[not(self::text() and normalize-space(.)='')][1]"/>
    <xsl:variable name="anclaSig"
      select="if ($next1[self::db:phrase[@role='cite-suffix'] or self::phrase[@role='cite-suffix']])
              then following-sibling::node()[not(self::text() and normalize-space(.)='')][2]
              else $next1"/>
    <xsl:variable name="esUltima"
      select="not($anclaSig[self::text() and matches(., '^\s*[,;]\s*$')])"/>

    <!-- AUTHOR-IN-TEXT: EN NUMÉRICO SE EMITE 'Autor [N]'. EL AUTOR VA
         ANTES DEL CORCHETE (SOLO PARA LA PRIMERA CITA DEL GRUPO). -->
    <xsl:if test="$modo = 'author-in-text' and $esPrimera = true()">
      <xsl:variable name="autor">
        <xsl:call-template name="resolver-autor-cita-db">
          <xsl:with-param name="rid" select="$rid"/>
        </xsl:call-template>
      </xsl:variable>
      <a class="xref-vancouver cita-ref" data-ref-id="{$rid}"
         onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
        <xsl:value-of select="$autor"/>
      </a>
      <xsl:text> </xsl:text>
    </xsl:if>

    <!-- PREFIJO ANTES DEL CORCHETE (SOLO EN LA PRIMERA DEL GRUPO) -->
    <xsl:if test="$esPrimera = true()">
      <xsl:call-template name="phrase-prefijo-de"/>
      <xsl:text>[</xsl:text>
    </xsl:if>
    <xsl:if test="$esPrimera = false()"><xsl:text>,</xsl:text></xsl:if>

    <!-- EL NÚMERO: POSICIÓN DEL biblioentry EN LA bibliography -->
    <xsl:variable name="num">
      <xsl:call-template name="numero-referencia-db">
        <xsl:with-param name="rid" select="$rid"/>
      </xsl:call-template>
    </xsl:variable>
    <a class="xref-vancouver cita-ref" data-ref-id="{$rid}"
       onclick="highlightPanel('refs','{$rid}')" style="cursor:pointer">
      <xsl:value-of select="$num"/>
    </a>

    <!-- SUFIJO DENTRO DEL CORCHETE (EN LA ÚLTIMA DEL GRUPO) -->
    <xsl:if test="$esUltima">
      <xsl:call-template name="phrase-sufijo-de"/>
      <xsl:text>]</xsl:text>
    </xsl:if>
  </xsl:template>

  <!-- NÚMERO DE UNA REFERENCIA: POSICIÓN EN LA bibliography DEL CAP.
       CUENTA biblioentry PRECEDENTES DENTRO DE LA MISMA bibliography. -->
  <xsl:template name="numero-referencia-db">
    <xsl:param name="rid"/>
    <xsl:variable name="entry"
                  select="(//db:biblioentry | //biblioentry)[@xml:id = $rid][1]"/>
    <xsl:choose>
      <xsl:when test="$entry">
        <xsl:value-of select="count($entry[1]/preceding-sibling::db:biblioentry
                                    | $entry[1]/preceding-sibling::biblioentry) + 1"/>
      </xsl:when>
      <!-- CITA HUÉRFANA: linkend SIN biblioentry -->
      <xsl:otherwise>
        <xsl:text>?</xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <!-- LINK EXTERNO → A -->
  <xsl:template match="db:link | link">
    <a href="{@xlink:href}" target="_blank" rel="noopener noreferrer">
      <xsl:apply-templates/>
    </a>
  </xsl:template>

  <!-- TÍTULO SUELTO: NO EMITIR (SE MANEJA EN LOS TEMPLATES CONTENEDORES) -->
  <xsl:template match="db:title | title"/>

  <!-- TEXTO: COPIAR NORMALIZANDO ESPACIOS DE FORMA SUAVE -->
  <!-- NO USAR normalize-space GLOBAL PARA NO COLAPSAR ESPACIOS ENTRE
       ELEMENTOS INLINE; SE COPIA EL TEXTO TAL CUAL. -->
  <xsl:template match="text()">
    <xsl:value-of select="."/>
  </xsl:template>

  <!-- MARCAS DE ÍNDICE (SC-77): EN EL HTML Y EL EPUB NO HAY ÍNDICES
       (DECISIÓN DE ALBERTO, 30/10/2026; LA PIEZA LA OMITE LA MATRIZ DE
       m_PiezasLibro). EL indexterm NO SE IMPRIME EN NINGÚN MODO: SIN ESTA
       PLANTILLA, LOS CATCH-ALL QUE PROCESAN LOS HIJOS DEJARÍAN EL TEXTO
       DEL TÉRMINO EN EL CUERPO («Borges, Jorge Luisinfancia»). -->
  <xsl:template match="db:indexterm | indexterm" mode="#all"/>

  <!-- CATCH-ALL: ELEMENTOS NO CONTEMPLADOS AÚN → PROCESAR HIJOS.
       EVITA QUE CONTENIDO DESCONOCIDO DESAPAREZCA SILENCIOSAMENTE. -->
  <xsl:template match="*">
    <xsl:apply-templates/>
  </xsl:template>

  <!-- ==========================================================
       BIBLIOENTRY EN MODO panel-ref (Fase 3)
       ==========================================================
       Renderiza cada entrada bibliográfica en el panel de referencias.
       Por ahora un formato funcional único (autor-título-editorial-año)
       para habilitar la navegación cruzada. La bifurcación por estilo
       (APA/Vancouver/ISO690/IEEE) se optimiza en fase posterior.

       El data-ref-id (el xml:id bib-XXX) permite que:
       - la marca [cita] del centro ancle a esta entrada (ida)
       - el click en esta entrada lleve a la primera cita (vuelta)
       onclick=irAlTexto para la navegación inversa (bidireccional en libros). -->
  <!-- ==========================================================
       BIBLIOENTRY EN MODO panel-ref — 4 ESTILOS DE CITA
       ==========================================================
       Rendering de cada referencia según $estilo_cita, portado del
       jats-to-html.xsl de revistas al vocabulario DocBook biblioentry.
       Estilos: apa | vancouver | iso690 | ieee + fallback autor-año.

       MAPEO DE VOCABULARIO JATS → DOCBOOK:
         person-group[@type='author']/name → author/personname
         surname/given-names               → surname/firstname
         article-title / chapter-title     → title
         source                            → citetitle
         year                              → pubdate
         volume / issue                    → volumenum / issuenum
         fpage-lpage                       → artpagenums
         publisher-name / publisher-loc    → publishername / address/city
         pub-id[@type='doi']               → biblioid[@class='doi'] -->
  <xsl:template match="db:biblioentry | biblioentry" mode="panel-ref">
    <div class="panel-item ref-item"
         data-ref-id="{@xml:id}"
         onclick="irAlTexto('{@xml:id}')"
         style="cursor:pointer">
      <!-- NÚMERO DE REFERENCIA: SOLO EN ESTILOS NUMÉRICOS (vancouver, ieee).
           ES EL ANCLA VISUAL QUE CONECTA LA MARCA [n] DEL CUERPO CON LA
           ENTRADA DEL DRAWER. SE CALCULA CON numero-referencia-db (EL MISMO
           QUE USAN LAS MARCAS), PASÁNDOLE EL PROPIO xml:id, ASÍ EL NÚMERO
           COINCIDE EXACTAMENTE. EN APA/ISO690 (AUTOR-AÑO) NO SE EMITE. -->
      <xsl:if test="$estilo_cita = 'vancouver' or $estilo_cita = 'ieee'">
        <span class="ref-numero">
          <xsl:text>[</xsl:text>
          <xsl:call-template name="numero-referencia-db">
            <xsl:with-param name="rid" select="string(@xml:id)"/>
          </xsl:call-template>
          <xsl:text>] </xsl:text>
        </span>
      </xsl:if>
      <xsl:choose>

        <!-- ══════════ VANCOUVER ══════════ -->
        <xsl:when test="$estilo_cita = 'vancouver'">
          <xsl:call-template name="ref-personas-db">
            <xsl:with-param name="estilo" select="'vancouver'"/>
          </xsl:call-template>
          <xsl:text>. </xsl:text>

          <!-- TÍTULO (redonda) -->
          <xsl:if test="db:title | title">
            <span class="ref-title-roman">
              <xsl:value-of select="normalize-space((db:title | title)[1])"/>
              <xsl:text>. </xsl:text>
            </span>
          </xsl:if>

          <!-- FUENTE / LIBRO (cursiva) -->
          <xsl:if test="db:citetitle | citetitle">
            <span class="ref-source-italic">
              <xsl:value-of select="normalize-space((db:citetitle | citetitle)[1])"/>
            </span>
          </xsl:if>

          <!-- TESIS: [tipo]. Institución -->
          <xsl:call-template name="ref-tesis-db">
            <xsl:with-param name="estilo" select="'vancouver'"/>
          </xsl:call-template>

          <!-- AÑO;VOLUMEN(NÚMERO):PÁGINAS -->
          <xsl:if test="db:pubdate | pubdate">
            <xsl:text>. </xsl:text>
            <span class="ref-year"><xsl:value-of select="normalize-space((db:pubdate | pubdate)[1])"/></span>
          </xsl:if>
          <xsl:if test="db:volumenum | volumenum">
            <xsl:text>;</xsl:text>
            <xsl:value-of select="normalize-space((db:volumenum | volumenum)[1])"/>
          </xsl:if>
          <xsl:if test="db:issuenum | issuenum">
            <xsl:text>(</xsl:text>
            <xsl:value-of select="normalize-space((db:issuenum | issuenum)[1])"/>
            <xsl:text>)</xsl:text>
          </xsl:if>
          <xsl:if test="db:artpagenums | artpagenums">
            <xsl:text>:</xsl:text>
            <xsl:value-of select="normalize-space((db:artpagenums | artpagenums)[1])"/>
          </xsl:if>

          <!-- EDITORIAL: CIUDAD: EDITORIAL -->
          <xsl:call-template name="ref-editorial-db">
            <xsl:with-param name="sep-inicial" select="'. '"/>
          </xsl:call-template>
          <xsl:text>.</xsl:text>

          <xsl:call-template name="ref-doi-db">
            <xsl:with-param name="etiqueta" select="'DOI: '"/>
          </xsl:call-template>
        </xsl:when>

        <!-- ══════════ APA 7 ══════════ -->
        <xsl:when test="$estilo_cita = 'apa'">
          <xsl:call-template name="ref-personas-db">
            <xsl:with-param name="estilo" select="'apa'"/>
          </xsl:call-template>

          <!-- AÑO ENTRE PARÉNTESIS -->
          <xsl:if test="db:pubdate | pubdate">
            <span class="ref-year">
              <xsl:text> (</xsl:text>
              <xsl:value-of select="normalize-space((db:pubdate | pubdate)[1])"/>
              <xsl:text>). </xsl:text>
            </span>
          </xsl:if>

          <!-- TÍTULO DEL ARTÍCULO/CAPÍTULO (redonda, sin cursiva en APA) -->
          <xsl:if test="db:title | title">
            <span class="ref-title-roman">
              <xsl:value-of select="normalize-space((db:title | title)[1])"/>
              <xsl:text>. </xsl:text>
            </span>
          </xsl:if>

          <!-- FUENTE / LIBRO (cursiva) -->
          <xsl:if test="db:citetitle | citetitle">
            <span class="ref-source-italic">
              <xsl:value-of select="normalize-space((db:citetitle | citetitle)[1])"/>
            </span>
          </xsl:if>

          <!-- TESIS: [Tipo, Institución] tras el título/fuente -->
          <xsl:call-template name="ref-tesis-db">
            <xsl:with-param name="estilo" select="'apa'"/>
          </xsl:call-template>

          <!-- VOLUMEN (cursiva), NÚMERO (paréntesis) -->
          <xsl:if test="db:volumenum | volumenum">
            <xsl:text>, </xsl:text>
            <em><xsl:value-of select="normalize-space((db:volumenum | volumenum)[1])"/></em>
          </xsl:if>
          <xsl:if test="db:issuenum | issuenum">
            <xsl:text>(</xsl:text>
            <xsl:value-of select="normalize-space((db:issuenum | issuenum)[1])"/>
            <xsl:text>)</xsl:text>
          </xsl:if>

          <!-- PÁGINAS -->
          <xsl:if test="db:artpagenums | artpagenums">
            <xsl:text>, </xsl:text>
            <xsl:value-of select="normalize-space((db:artpagenums | artpagenums)[1])"/>
          </xsl:if>

          <!-- EDITORIAL (APA libros: solo editorial, sin ciudad desde 7ª ed.) -->
          <xsl:variable name="pubname-apa"
                        select="normalize-space((db:publisher/db:publishername
                                                | publisher/publishername)[1])"/>
          <xsl:if test="$pubname-apa != ''">
            <xsl:text>. </xsl:text>
            <xsl:value-of select="$pubname-apa"/>
          </xsl:if>

          <!-- DOI como URL sin etiqueta (APA 7) -->
          <xsl:call-template name="ref-doi-db">
            <xsl:with-param name="etiqueta" select="'https://doi.org/'"/>
            <xsl:with-param name="solo-url" select="true()"/>
          </xsl:call-template>
        </xsl:when>

        <!-- ══════════ ISO 690 (autor-fecha, versalitas) ══════════ -->
        <xsl:when test="$estilo_cita = 'iso690'">
          <xsl:call-template name="ref-personas-db">
            <xsl:with-param name="estilo" select="'iso690'"/>
          </xsl:call-template>

          <!-- AÑO ENTRE PARÉNTESIS -->
          <xsl:if test="db:pubdate | pubdate">
            <span class="ref-year">
              <xsl:text> (</xsl:text>
              <xsl:value-of select="normalize-space((db:pubdate | pubdate)[1])"/>
              <xsl:text>). </xsl:text>
            </span>
          </xsl:if>

          <!-- TÍTULO ENTRE COMILLAS -->
          <xsl:if test="db:title | title">
            <span class="ref-title-roman">
              <xsl:text>&#x201C;</xsl:text>
              <xsl:value-of select="normalize-space((db:title | title)[1])"/>
              <xsl:text>&#x201D;. </xsl:text>
            </span>
          </xsl:if>

          <!-- FUENTE / LIBRO (cursiva) -->
          <xsl:if test="db:citetitle | citetitle">
            <span class="ref-source-italic">
              <xsl:value-of select="normalize-space((db:citetitle | citetitle)[1])"/>
            </span>
          </xsl:if>

          <!-- TESIS: . Tipo. Institución -->
          <xsl:call-template name="ref-tesis-db">
            <xsl:with-param name="estilo" select="'iso690'"/>
          </xsl:call-template>

          <!-- VOLUMEN, NÚMERO -->
          <xsl:if test="db:volumenum | volumenum">
            <xsl:text>, vol. </xsl:text>
            <xsl:value-of select="normalize-space((db:volumenum | volumenum)[1])"/>
          </xsl:if>
          <xsl:if test="db:issuenum | issuenum">
            <xsl:text>, n.&#xBA; </xsl:text>
            <xsl:value-of select="normalize-space((db:issuenum | issuenum)[1])"/>
          </xsl:if>

          <!-- PÁGINAS -->
          <xsl:if test="db:artpagenums | artpagenums">
            <xsl:text>, pp. </xsl:text>
            <xsl:value-of select="normalize-space((db:artpagenums | artpagenums)[1])"/>
          </xsl:if>

          <!-- EDITORIAL: CIUDAD: EDITORIAL -->
          <xsl:call-template name="ref-editorial-db">
            <xsl:with-param name="sep-inicial" select="'. '"/>
          </xsl:call-template>
          <xsl:text>.</xsl:text>

          <xsl:call-template name="ref-doi-db">
            <xsl:with-param name="etiqueta" select="'DOI: '"/>
          </xsl:call-template>
        </xsl:when>

        <!-- ══════════ IEEE (inicial primero, año al final) ══════════ -->
        <xsl:when test="$estilo_cita = 'ieee'">
          <xsl:call-template name="ref-personas-db">
            <xsl:with-param name="estilo" select="'ieee'"/>
          </xsl:call-template>
          <xsl:text>. </xsl:text>

          <!-- TÍTULO ENTRE COMILLAS, TERMINADO EN COMA -->
          <xsl:if test="db:title | title">
            <span class="ref-title-roman">
              <xsl:text>&#x201C;</xsl:text>
              <xsl:value-of select="normalize-space((db:title | title)[1])"/>
              <xsl:text>,&#x201D;</xsl:text>
            </span>
          </xsl:if>

          <!-- FUENTE / LIBRO (cursiva) -->
          <xsl:if test="db:citetitle | citetitle">
            <span class="ref-source-italic">
              <xsl:text> </xsl:text>
              <xsl:value-of select="normalize-space((db:citetitle | citetitle)[1])"/>
            </span>
          </xsl:if>

          <!-- TESIS: , tipo, Institución -->
          <xsl:call-template name="ref-tesis-db">
            <xsl:with-param name="estilo" select="'ieee'"/>
          </xsl:call-template>

          <!-- VOLUMEN, NÚMERO -->
          <xsl:if test="db:volumenum | volumenum">
            <xsl:text>, vol. </xsl:text>
            <xsl:value-of select="normalize-space((db:volumenum | volumenum)[1])"/>
          </xsl:if>
          <xsl:if test="db:issuenum | issuenum">
            <xsl:text>, n.&#xBA; </xsl:text>
            <xsl:value-of select="normalize-space((db:issuenum | issuenum)[1])"/>
          </xsl:if>

          <!-- PÁGINAS -->
          <xsl:if test="db:artpagenums | artpagenums">
            <xsl:text>, pp. </xsl:text>
            <xsl:value-of select="normalize-space((db:artpagenums | artpagenums)[1])"/>
          </xsl:if>

          <!-- EDITORIAL: CIUDAD: EDITORIAL -->
          <xsl:call-template name="ref-editorial-db">
            <xsl:with-param name="sep-inicial" select="'. '"/>
          </xsl:call-template>

          <!-- AÑO AL FINAL -->
          <xsl:if test="db:pubdate | pubdate">
            <xsl:text>, </xsl:text>
            <span class="ref-year"><xsl:value-of select="normalize-space((db:pubdate | pubdate)[1])"/></span>
          </xsl:if>
          <xsl:text>.</xsl:text>

          <xsl:call-template name="ref-doi-db">
            <xsl:with-param name="etiqueta" select="'DOI: '"/>
          </xsl:call-template>
        </xsl:when>

        <!-- ══════════ FALLBACK: AUTOR-AÑO GENÉRICO ══════════ -->
        <xsl:otherwise>
          <xsl:call-template name="ref-personas-db">
            <xsl:with-param name="estilo" select="'fallback'"/>
          </xsl:call-template>
          <xsl:if test="db:pubdate | pubdate">
            <xsl:text> (</xsl:text>
            <span class="ref-year"><xsl:value-of select="normalize-space((db:pubdate | pubdate)[1])"/></span>
            <xsl:text>). </xsl:text>
          </xsl:if>
          <xsl:if test="db:title | title">
            <span class="ref-title-roman">
              <xsl:value-of select="normalize-space((db:title | title)[1])"/>
              <xsl:text>. </xsl:text>
            </span>
          </xsl:if>
          <xsl:if test="db:citetitle | citetitle">
            <span class="ref-source-italic">
              <xsl:value-of select="normalize-space((db:citetitle | citetitle)[1])"/>
            </span>
          </xsl:if>
          <xsl:call-template name="ref-editorial-db">
            <xsl:with-param name="sep-inicial" select="'. '"/>
          </xsl:call-template>
          <xsl:text>.</xsl:text>
          <xsl:call-template name="ref-doi-db">
            <xsl:with-param name="etiqueta" select="'DOI: '"/>
          </xsl:call-template>
        </xsl:otherwise>

      </xsl:choose>
    </div>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ref-personas-db
       ==========================================================
       Emite autores (o editores como fallback) de un biblioentry
       DocBook según el estilo. Encapsula los 4 formatos de nombre.
       Portado del jats-to-html.xsl (person-group → author/editor). -->
  <xsl:template name="ref-personas-db">
    <xsl:param name="estilo" as="xs:string"/>

    <span class="ref-authors">
      <xsl:choose>
        <!-- HAY AUTORES -->
        <xsl:when test="db:author | author">
          <xsl:for-each select="db:author | author">
            <xsl:call-template name="ref-una-persona-db">
              <xsl:with-param name="estilo" select="$estilo"/>
              <xsl:with-param name="total" select="last()"/>
            </xsl:call-template>
          </xsl:for-each>
        </xsl:when>
        <!-- FALLBACK: EDITORES CON MARCA (Ed.)/(Eds.) -->
        <xsl:when test="db:editor | editor">
          <!-- LOS NOMBRES VAN A UNA VARIABLE ANTES DE ESCRIBIRSE: LA MARCA
               NECESITA SABER SI TERMINAN EN PUNTO PARA DECIDIR LA MAYÚSCULA,
               COMO HACE biblatex -->
          <xsl:variable name="nombres">
            <xsl:for-each select="db:editor | editor">
              <xsl:call-template name="ref-una-persona-db">
                <xsl:with-param name="estilo" select="$estilo"/>
                <xsl:with-param name="total" select="last()"/>
              </xsl:call-template>
            </xsl:for-each>
          </xsl:variable>
          <xsl:copy-of select="$nombres"/>
          <!-- MARCA SEGÚN EL ROL DEL EDITOR: (Ed.), (Comp.), (Coord.)...
               LA REGLA VIVE EN marca-editor.xsl -->
          <xsl:call-template name="marca-editor-db">
            <xsl:with-param name="estilo" select="$estilo"/>
            <xsl:with-param name="editores" select="db:editor | editor"/>
            <xsl:with-param name="tras_punto"
                            select="ends-with(normalize-space(string($nombres)), '.')"/>
          </xsl:call-template>
        </xsl:when>
      </xsl:choose>
    </span>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ref-una-persona-db
       ==========================================================
       Emite UNA persona (surname/firstname) en el formato del estilo,
       con el separador correcto según su posición en la lista. -->
  <xsl:template name="ref-una-persona-db">
    <xsl:param name="estilo" as="xs:string"/>
    <xsl:param name="total" as="xs:integer"/>

    <xsl:variable name="pn" select="db:personname | personname"/>
    <xsl:variable name="surname" select="normalize-space($pn/db:surname | $pn/surname)"/>
    <xsl:variable name="firstname" select="normalize-space($pn/db:firstname | $pn/firstname)"/>

    <xsl:choose>
      <!-- VANCOUVER: Apellido II (iniciales pegadas sin puntos) -->
      <xsl:when test="$estilo = 'vancouver'">
        <xsl:value-of select="$surname"/>
        <xsl:if test="$firstname != ''">
          <xsl:text> </xsl:text>
          <!-- INICIALES SIN PUNTOS NI ESPACIOS: 'Juan Carlos' → 'JC'.
               EN DOCBOOK firstname VIENE COMPLETO, HAY QUE ABREVIAR. -->
          <xsl:for-each select="tokenize(normalize-space($firstname), '\s+')">
            <xsl:value-of select="substring(., 1, 1)"/>
          </xsl:for-each>
        </xsl:if>
        <xsl:if test="position() != last()"><xsl:text>, </xsl:text></xsl:if>
      </xsl:when>

      <!-- APA: Apellido, I. I. -->
      <xsl:when test="$estilo = 'apa'">
        <xsl:value-of select="$surname"/>
        <xsl:if test="$firstname != ''">
          <xsl:text>, </xsl:text>
          <xsl:call-template name="iniciales-apa">
            <xsl:with-param name="nombres" select="$firstname"/>
          </xsl:call-template>
        </xsl:if>
        <xsl:choose>
          <xsl:when test="position() = last() - 1"><xsl:text>, &amp; </xsl:text></xsl:when>
          <xsl:when test="position() != last()"><xsl:text>, </xsl:text></xsl:when>
        </xsl:choose>
      </xsl:when>

      <!-- ISO 690: APELLIDO (versalitas), Nombre -->
      <xsl:when test="$estilo = 'iso690'">
        <span style="font-variant:small-caps">
          <xsl:value-of select="upper-case($surname)"/>
        </span>
        <xsl:if test="$firstname != ''">
          <xsl:text>, </xsl:text>
          <xsl:value-of select="$firstname"/>
        </xsl:if>
        <xsl:if test="position() != last()"><xsl:text>; </xsl:text></xsl:if>
      </xsl:when>

      <!-- IEEE: I. Apellido (inicial primero) -->
      <xsl:when test="$estilo = 'ieee'">
        <xsl:if test="$firstname != ''">
          <!-- EXTRAER INICIALES: EN DOCBOOK firstname VIENE COMPLETO
               ('Marcela'), NO ABREVIADO. iniciales-apa PRODUCE 'M.' -->
          <xsl:call-template name="iniciales-apa">
            <xsl:with-param name="nombres" select="$firstname"/>
          </xsl:call-template>
          <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:value-of select="$surname"/>
        <xsl:choose>
          <xsl:when test="position() = last() - 1 and last() &gt; 1"><xsl:text> and </xsl:text></xsl:when>
          <xsl:when test="position() != last()"><xsl:text>, </xsl:text></xsl:when>
        </xsl:choose>
      </xsl:when>

      <!-- FALLBACK: Apellido, Nombre -->
      <xsl:otherwise>
        <xsl:value-of select="$surname"/>
        <xsl:if test="$firstname != ''">
          <xsl:text>, </xsl:text>
          <xsl:value-of select="$firstname"/>
        </xsl:if>
        <xsl:if test="position() != last()"><xsl:text>; </xsl:text></xsl:if>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ref-editorial-db
       ==========================================================
       Emite "Ciudad: Editorial" desde publisher/publishername +
       publisher/address/city. Convierte " and " → " y " en el nombre. -->
  <xsl:template name="ref-editorial-db">
    <xsl:param name="sep-inicial" as="xs:string" select="'. '"/>

    <xsl:variable name="pubname"
                  select="normalize-space((db:publisher/db:publishername
                                          | publisher/publishername)[1])"/>
    <xsl:variable name="pubcity"
                  select="normalize-space((db:publisher/db:address/db:city
                                          | publisher/address/city)[1])"/>
    <xsl:if test="$pubname != '' or $pubcity != ''">
      <xsl:value-of select="$sep-inicial"/>
      <xsl:if test="$pubcity != ''">
        <xsl:value-of select="$pubcity"/>
        <xsl:text>: </xsl:text>
      </xsl:if>
      <xsl:if test="$pubname != ''">
        <xsl:value-of select="replace($pubname, '(\s)and(\s)', '$1y$2')"/>
      </xsl:if>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ref-doi-db
       ==========================================================
       Emite el DOI como enlace, con etiqueta configurable. -->
  <xsl:template name="ref-doi-db">
    <xsl:param name="etiqueta" as="xs:string" select="'DOI: '"/>
    <xsl:param name="solo-url" as="xs:boolean" select="false()"/>

    <xsl:variable name="doi"
                  select="normalize-space((db:biblioid[@class='doi']
                                          | biblioid[@class='doi'])[1])"/>
    <xsl:if test="$doi != ''">
      <div class="ref-doi">
        <a href="https://doi.org/{$doi}" target="_blank" rel="noopener noreferrer">
          <xsl:choose>
            <xsl:when test="$solo-url">
              <xsl:value-of select="$etiqueta"/><xsl:value-of select="$doi"/>
            </xsl:when>
            <xsl:otherwise>
              <xsl:value-of select="$etiqueta"/><xsl:value-of select="$doi"/>
            </xsl:otherwise>
          </xsl:choose>
        </a>
      </div>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ref-tesis-db
       ==========================================================
       Emite el tipo de tesis + institución en el formato del estilo.
       Solo aplica si el biblioentry es una tesis (otherpubwork='thesis').
       El tipo (nombre en español) viene de bibliomisc[@role='thesis-type'],
       ya resuelto por Gambas desde cmb_biblatex. Si no hay thesis-type,
       usa "Tesis" genérico. La institución sale de orgname.
       FORMATOS:
         apa:       [Tesis Doctoral, Universidad X]
         vancouver: [tesis doctoral]. Universidad X
         iso690:    Tesis Doctoral. Universidad X
         ieee:      tesis doctoral, Universidad X -->
  <xsl:template name="ref-tesis-db">
    <xsl:param name="estilo" as="xs:string"/>

    <!-- ¿ES TESIS? SOLO ACTÚA SI otherpubwork='thesis' -->
    <xsl:variable name="es-tesis"
                  select="(@otherpubwork = 'thesis')
                          or (db:citetitle/@pubwork = 'thesis')
                          or (citetitle/@pubwork = 'thesis')"/>

    <xsl:if test="$es-tesis">
      <!-- TIPO: bibliomisc[@role='thesis-type'] O "Tesis" GENÉRICO -->
      <xsl:variable name="tipo-tesis">
        <xsl:variable name="tt"
          select="normalize-space((db:bibliomisc[@role='thesis-type']
                                  | bibliomisc[@role='thesis-type'])[1])"/>
        <xsl:choose>
          <xsl:when test="$tt != ''"><xsl:value-of select="$tt"/></xsl:when>
          <xsl:otherwise><xsl:text>Tesis</xsl:text></xsl:otherwise>
        </xsl:choose>
      </xsl:variable>

      <!-- INSTITUCIÓN: orgname -->
      <xsl:variable name="institucion"
        select="normalize-space((db:orgname | orgname)[1])"/>

      <xsl:choose>
        <!-- APA: [Tesis Doctoral, Universidad X] -->
        <xsl:when test="$estilo = 'apa'">
          <xsl:text> [</xsl:text>
          <xsl:value-of select="$tipo-tesis"/>
          <xsl:if test="$institucion != ''">
            <xsl:text>, </xsl:text>
            <xsl:value-of select="$institucion"/>
          </xsl:if>
          <xsl:text>]</xsl:text>
        </xsl:when>

        <!-- VANCOUVER: [tesis doctoral]. Universidad X (tipo en minúscula) -->
        <xsl:when test="$estilo = 'vancouver'">
          <xsl:text> [</xsl:text>
          <xsl:value-of select="lower-case($tipo-tesis)"/>
          <xsl:text>]</xsl:text>
          <xsl:if test="$institucion != ''">
            <xsl:text>. </xsl:text>
            <xsl:value-of select="$institucion"/>
          </xsl:if>
        </xsl:when>

        <!-- ISO 690: Tesis Doctoral. Universidad X -->
        <xsl:when test="$estilo = 'iso690'">
          <xsl:text>. </xsl:text>
          <xsl:value-of select="$tipo-tesis"/>
          <xsl:if test="$institucion != ''">
            <xsl:text>. </xsl:text>
            <xsl:value-of select="$institucion"/>
          </xsl:if>
        </xsl:when>

        <!-- IEEE: tesis doctoral, Universidad X (minúscula) -->
        <xsl:when test="$estilo = 'ieee'">
          <xsl:text>, </xsl:text>
          <xsl:value-of select="lower-case($tipo-tesis)"/>
          <xsl:if test="$institucion != ''">
            <xsl:text>, </xsl:text>
            <xsl:value-of select="$institucion"/>
          </xsl:if>
        </xsl:when>
      </xsl:choose>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: iniciales-apa (idéntico a revistas)
       ==========================================================
       "Juan Carlos" → "J. C." -->
  <xsl:template name="iniciales-apa">
    <xsl:param name="nombres"/>
    <xsl:for-each select="tokenize(normalize-space($nombres), '\s+')">
      <xsl:value-of select="substring(., 1, 1)"/>
      <xsl:text>.</xsl:text>
      <xsl:if test="position() != last()"><xsl:text> </xsl:text></xsl:if>
    </xsl:for-each>
  </xsl:template>

  <!-- ==========================================================
       ========= FASE 4: METADATOS COMPLETOS POR CAPÍTULO =======
       ==========================================================
       Orquestador: emite Highwire + Dublin Core + Open Graph +
       Twitter Cards + JSON-LD Schema.org para cada capítulo.

       FUENTES DE DATOS:
       - Del capítulo (cambia): $capInfo (título, autores, abstract,
         keywords, DOI, licencia).
       - Del libro (heredado, constante): variables globales de Fase 1
         ($titulo_libro, $isbn_print, $editorial, $anio_publicacion,
         $idioma_principal, $imagen_tapa, $doi_libro).

       BASE DOCUMENTAL (Google Scholar Inclusion Guidelines):
       - citation_title = título del capítulo (NO el del libro).
       - citation_book_title = título del libro contenedor.
       - citation_isbn / citation_publisher / citation_publication_date
         para la obra contenedora.
       - DC como complemento (last resort per Scholar); precisión de
         "capítulo" en JSON-LD @type=Chapter (schema.org). -->
  <xsl:template name="emitir-metadatos-capitulo">
    <xsl:param name="capitulo"/>
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>

    <!-- VARIABLES DERIVADAS DEL CAPÍTULO, REUSADAS POR TODOS LOS BLOQUES -->
    <xsl:variable name="capDoi"
                  select="normalize-space(($capInfo/db:biblioid[@class='doi']
                                          | $capInfo/biblioid[@class='doi'])[1])"/>
    <xsl:variable name="capResumen"
                  select="normalize-space(($capInfo/db:abstract/db:para
                                          | $capInfo/abstract/para)[1])"/>
    <xsl:variable name="capLicUrl"
                  select="normalize-space(($capInfo/db:legalnotice[@role='licencia']/db:para/db:link/@xlink:href
                                          | $capInfo/legalnotice[@role='licencia']/para/link/@xlink:href)[1])"/>
    <xsl:variable name="capLang">
      <xsl:choose>
        <xsl:when test="normalize-space($capitulo/@xml:lang) != ''">
          <xsl:value-of select="$capitulo/@xml:lang"/>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="$idioma_principal"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <xsl:call-template name="meta-highwire-cap">
      <xsl:with-param name="capInfo" select="$capInfo"/>
      <xsl:with-param name="capTitulo" select="$capTitulo"/>
      <xsl:with-param name="capDoi" select="$capDoi"/>
      <xsl:with-param name="capResumen" select="$capResumen"/>
      <xsl:with-param name="capLang" select="$capLang"/>
    </xsl:call-template>

    <xsl:call-template name="meta-dc-cap">
      <xsl:with-param name="capInfo" select="$capInfo"/>
      <xsl:with-param name="capTitulo" select="$capTitulo"/>
      <xsl:with-param name="capDoi" select="$capDoi"/>
      <xsl:with-param name="capResumen" select="$capResumen"/>
      <xsl:with-param name="capLicUrl" select="$capLicUrl"/>
      <xsl:with-param name="capLang" select="$capLang"/>
    </xsl:call-template>

    <xsl:call-template name="meta-og-twitter-cap">
      <xsl:with-param name="capTitulo" select="$capTitulo"/>
      <xsl:with-param name="capResumen" select="$capResumen"/>
      <xsl:with-param name="capLang" select="$capLang"/>
    </xsl:call-template>

    <xsl:call-template name="meta-jsonld-cap">
      <xsl:with-param name="capInfo" select="$capInfo"/>
      <xsl:with-param name="capTitulo" select="$capTitulo"/>
      <xsl:with-param name="capDoi" select="$capDoi"/>
      <xsl:with-param name="capResumen" select="$capResumen"/>
    </xsl:call-template>
  </xsl:template>

  <!-- ==========================================================
       BLOQUE 1: HIGHWIRE PRESS (Google Scholar) — CAPÍTULO
       ========================================================== -->
  <xsl:template name="meta-highwire-cap">
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>
    <xsl:param name="capDoi"/>
    <xsl:param name="capResumen"/>
    <xsl:param name="capLang"/>

    <xsl:comment> METADATOS: Highwire Press — Google Scholar (capítulo) </xsl:comment>

    <!-- TÍTULO DEL CAPÍTULO (NO EL DEL LIBRO) -->
    <meta name="citation_title" content="{$capTitulo}"/>

    <!-- TÍTULO DEL LIBRO CONTENEDOR -->
    <meta name="citation_book_title" content="{$titulo_libro}"/>

    <!-- AUTORES DEL CAPÍTULO CON ORCID Y AFILIACIÓN -->
    <xsl:for-each select="$capInfo/db:author | $capInfo/author">
      <meta name="citation_author"
            content="{normalize-space(db:personname/db:surname | personname/surname)}, {normalize-space(db:personname/db:firstname | personname/firstname)}"/>
      <xsl:variable name="orcid_url" select="(db:uri[@type='orcid'] | uri[@type='orcid'])[1]"/>
      <xsl:if test="$orcid_url != ''">
        <meta name="citation_author_orcid" content="{$orcid_url}"/>
      </xsl:if>
      <xsl:variable name="orgname" select="(db:affiliation/db:orgname | affiliation/orgname)[1]"/>
      <xsl:if test="$orgname != ''">
        <meta name="citation_author_institution" content="{normalize-space($orgname)}"/>
      </xsl:if>
    </xsl:for-each>

    <!-- DATOS HEREDADOS DE LA OBRA CONTENEDORA -->
    <xsl:if test="$capDoi != ''">
      <meta name="citation_doi" content="{$capDoi}"/>
    </xsl:if>
    <xsl:if test="$isbn_print != ''">
      <meta name="citation_isbn" content="{$isbn_print}"/>
    </xsl:if>
    <xsl:if test="$isbn_electronic != ''">
      <meta name="citation_isbn" content="{$isbn_electronic}"/>
    </xsl:if>
    <xsl:if test="$editorial != ''">
      <meta name="citation_publisher" content="{$editorial}"/>
    </xsl:if>
    <xsl:if test="$anio_cita != ''">
      <meta name="citation_publication_date" content="{$anio_cita}"/>
    </xsl:if>

    <meta name="citation_language" content="{$capLang}"/>

    <!-- RESUMEN DEL CAPÍTULO SI TIENE -->
    <xsl:if test="$capResumen != ''">
      <meta name="citation_abstract" content="{$capResumen}"/>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       BLOQUE 2: DUBLIN CORE — CAPÍTULO
       ==========================================================
       DC como complemento (Scholar lo trata como last resort).
       DC.type = Text (valor DCMI oficial); la precisión "capítulo"
       va en el JSON-LD (@type=Chapter). -->
  <xsl:template name="meta-dc-cap">
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>
    <xsl:param name="capDoi"/>
    <xsl:param name="capResumen"/>
    <xsl:param name="capLicUrl"/>
    <xsl:param name="capLang"/>

    <xsl:comment> METADATOS: Dublin Core (capítulo) </xsl:comment>

    <meta name="DC.title" content="{$capTitulo}"/>
    <meta name="DC.language" content="{$capLang}"/>
    <meta name="DC.type" content="Text"/>
    <meta name="DC.format" content="text/html"/>

    <!-- OBRA CONTENEDORA -->
    <meta name="DC.relation.ispartof" content="{$titulo_libro}"/>

    <xsl:if test="$editorial != ''">
      <meta name="DC.publisher" content="{$editorial}"/>
    </xsl:if>
    <xsl:if test="$capDoi != ''">
      <meta name="DC.identifier" content="https://doi.org/{$capDoi}"/>
    </xsl:if>
    <xsl:if test="$anio_cita != ''">
      <meta name="DC.date" content="{$anio_cita}"/>
    </xsl:if>
    <xsl:if test="$capResumen != ''">
      <meta name="DC.description" content="{$capResumen}"/>
    </xsl:if>
    <xsl:if test="$capLicUrl != ''">
      <meta name="DC.rights" content="{$capLicUrl}"/>
    </xsl:if>

    <!-- AUTORES COMO DC.creator -->
    <xsl:for-each select="$capInfo/db:author | $capInfo/author">
      <meta name="DC.creator"
            content="{normalize-space(db:personname/db:surname | personname/surname)}, {normalize-space(db:personname/db:firstname | personname/firstname)}"/>
    </xsl:for-each>

    <!-- KEYWORDS COMO DC.subject (UNO POR TÉRMINO, TODOS LOS IDIOMAS) -->
    <xsl:for-each select="$capInfo/db:keywordset/db:keyword | $capInfo/keywordset/keyword">
      <meta name="DC.subject" content="{normalize-space(.)}"/>
    </xsl:for-each>
  </xsl:template>

  <!-- ==========================================================
       BLOQUE 3: OPEN GRAPH + TWITTER CARDS — CAPÍTULO
       ========================================================== -->
  <xsl:template name="meta-og-twitter-cap">
    <xsl:param name="capTitulo"/>
    <xsl:param name="capResumen"/>
    <xsl:param name="capLang"/>

    <xsl:comment> METADATOS: Open Graph + Twitter Cards (capítulo) </xsl:comment>

    <!-- og:type=book: el capítulo es parte de un libro -->
    <meta property="og:type" content="book"/>
    <meta property="og:title" content="{$capTitulo}"/>
    <meta property="og:site_name" content="{$titulo_libro}"/>
    <meta property="og:locale" content="{$capLang}"/>
    <xsl:if test="$capResumen != ''">
      <meta property="og:description" content="{$capResumen}"/>
    </xsl:if>
    <xsl:if test="$imagen_tapa != ''">
      <meta property="og:image" content="{$imagen_tapa}"/>
    </xsl:if>
    <xsl:if test="$isbn_print != ''">
      <meta property="og:book:isbn" content="{$isbn_print}"/>
    </xsl:if>

    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:title" content="{$capTitulo}"/>
    <xsl:if test="$capResumen != ''">
      <meta name="twitter:description" content="{$capResumen}"/>
    </xsl:if>
    <xsl:if test="$imagen_tapa != ''">
      <meta name="twitter:image" content="{$imagen_tapa}"/>
    </xsl:if>
  </xsl:template>

  <!-- ==========================================================
       BLOQUE 4: JSON-LD Schema.org — CAPÍTULO (@type=Chapter)
       ==========================================================
       El capítulo es un Chapter que es isPartOf un Book.
       El Book lleva su publisher (Organization) e isbn.
       Los autores son Person con affiliation Organization.
       Construido con xsl:text para control preciso del JSON. -->
  <xsl:template name="meta-jsonld-cap">
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>
    <xsl:param name="capDoi"/>
    <xsl:param name="capResumen"/>

    <xsl:comment> METADATOS: Schema.org JSON-LD (Chapter) </xsl:comment>

    <script type="application/ld+json">
      <xsl:text>{"@context":"https://schema.org","@type":"Chapter",</xsl:text>
      <xsl:text>"name":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$capTitulo"/></xsl:call-template>
      <xsl:text>"</xsl:text>

      <!-- DOI COMO identifier -->
      <xsl:if test="$capDoi != ''">
        <xsl:text>,"identifier":{"@type":"PropertyValue","propertyID":"DOI","value":"</xsl:text>
        <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$capDoi"/></xsl:call-template>
        <xsl:text>"}</xsl:text>
      </xsl:if>

      <!-- ABSTRACT -->
      <xsl:if test="$capResumen != ''">
        <xsl:text>,"abstract":"</xsl:text>
        <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$capResumen"/></xsl:call-template>
        <xsl:text>"</xsl:text>
      </xsl:if>

      <!-- AUTORES (Person CON affiliation) -->
      <xsl:if test="$capInfo/db:author | $capInfo/author">
        <xsl:text>,"author":[</xsl:text>
        <xsl:for-each select="$capInfo/db:author | $capInfo/author">
          <xsl:if test="position() &gt; 1"><xsl:text>,</xsl:text></xsl:if>
          <xsl:text>{"@type":"Person","name":"</xsl:text>
          <xsl:call-template name="escapar-json">
            <xsl:with-param name="txt"
              select="concat(normalize-space(db:personname/db:firstname | personname/firstname),
                             ' ',
                             normalize-space(db:personname/db:surname | personname/surname))"/>
          </xsl:call-template>
          <xsl:text>"</xsl:text>
          <xsl:variable name="orgname" select="(db:affiliation/db:orgname | affiliation/orgname)[1]"/>
          <xsl:if test="$orgname != ''">
            <xsl:text>,"affiliation":{"@type":"Organization","name":"</xsl:text>
            <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="normalize-space($orgname)"/></xsl:call-template>
            <xsl:text>"}</xsl:text>
          </xsl:if>
          <xsl:variable name="orcid_url" select="(db:uri[@type='orcid'] | uri[@type='orcid'])[1]"/>
          <xsl:if test="$orcid_url != ''">
            <xsl:text>,"identifier":"</xsl:text>
            <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="normalize-space($orcid_url)"/></xsl:call-template>
            <xsl:text>"</xsl:text>
          </xsl:if>
          <xsl:text>}</xsl:text>
        </xsl:for-each>
        <xsl:text>]</xsl:text>
      </xsl:if>

      <!-- isPartOf: EL LIBRO CONTENEDOR -->
      <xsl:text>,"isPartOf":{"@type":"Book","name":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$titulo_libro"/></xsl:call-template>
      <xsl:text>"</xsl:text>
      <xsl:if test="$isbn_print != ''">
        <xsl:text>,"isbn":"</xsl:text>
        <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$isbn_print"/></xsl:call-template>
        <xsl:text>"</xsl:text>
      </xsl:if>
      <xsl:if test="$editorial != ''">
        <xsl:text>,"publisher":{"@type":"Organization","name":"</xsl:text>
        <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$editorial"/></xsl:call-template>
        <xsl:text>"}</xsl:text>
      </xsl:if>
      <xsl:if test="$anio_cita != ''">
        <xsl:text>,"datePublished":"</xsl:text>
        <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$anio_cita"/></xsl:call-template>
        <xsl:text>"</xsl:text>
      </xsl:if>
      <xsl:text>}</xsl:text>

      <xsl:text>}</xsl:text>
    </script>
  </xsl:template>

  <!-- ==========================================================
       AUXILIAR: ESCAPAR STRING PARA JSON
       ==========================================================
       Escapa backslash, comilla doble y saltos de línea, que son
       los caracteres que romperían el JSON embebido en el script. -->
  <xsl:template name="escapar-json">
    <xsl:param name="txt" as="xs:string"/>
    <xsl:variable name="t1" select="replace($txt, '\\', '\\\\')"/>
    <xsl:variable name="t2" select="replace($t1, '&quot;', '\\&quot;')"/>
    <xsl:variable name="t3" select="replace($t2, '&#10;', ' ')"/>
    <xsl:variable name="t4" select="replace($t3, '&#13;', ' ')"/>
    <xsl:variable name="t5" select="replace($t4, '&#9;', ' ')"/>
    <xsl:value-of select="$t5"/>
  </xsl:template>

  <!-- ==========================================================
       ============= FASE 5: WIDGET "CÓMO CITAR" ================
       ==========================================================
       - emitir-widget-citar: el bloque visual (botones + área + copiar).
         Reutilizable en index (libro) y en capítulo.
       - emitir-citadata-libro / emitir-citadata-capitulo: el <script>
         inline con var citaData = {...} que el gbpublisher.js consume.
         Se inyecta ANTES del <script src> externo (Opción A, Fase 1). -->

  <!-- WIDGET VISUAL: BOTONES DE FORMATO + ÁREA DE CITA + COPIAR.
       Estructura alineada con revistas para reusar CSS (.citar-wrapper,
       .citar-toggle, .citar-formatos, .citar-btn, .citar-texto,
       .citar-copiar) e IDs que el JS espera (citar-output para el área,
       citar-copiar-btn para el botón). El <details> lo hace colapsable.
       El JS inicializa el contenido en DOMContentLoaded (APA por defecto). -->
  <xsl:template name="emitir-widget-citar">
    <div class="citar-wrapper">
      <details>
        <summary class="citar-toggle">Cómo citar</summary>
        <div class="citar-formatos">
          <button class="citar-btn active" onclick="mostrarFormato(this,'apa')">APA</button>
          <button class="citar-btn" onclick="mostrarFormato(this,'ieee')">IEEE</button>
          <button class="citar-btn" onclick="mostrarFormato(this,'vancouver')">Vancouver</button>
          <button class="citar-btn" onclick="mostrarFormato(this,'bibtex')">BibTeX</button>
          <button class="citar-btn" onclick="mostrarFormato(this,'ris')">RIS</button>
        </div>
        <pre class="citar-texto" id="citar-output"></pre>
        <button class="citar-copiar" id="citar-copiar-btn" onclick="copiarCita()">Copiar</button>
      </details>
    </div>
  </xsl:template>

  <!-- INYECCIÓN DE citaData PARA EL LIBRO (index.html) -->
  <xsl:template name="emitir-citadata-libro">
    <script>
      <xsl:text>var citaData = {</xsl:text>
      <xsl:text>"tipo":"libro",</xsl:text>
      <xsl:text>"titulo":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$titulo_libro"/></xsl:call-template>
      <xsl:text>","editorial":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$editorial"/></xsl:call-template>
      <xsl:text>","ciudad":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$ciudad_pub"/></xsl:call-template>
      <xsl:text>","isbn":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$isbn_print"/></xsl:call-template>
      <xsl:text>","doi":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$doi_libro"/></xsl:call-template>
      <xsl:text>","url":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$url_libro"/></xsl:call-template>
      <xsl:text>","anio":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$anio_cita"/></xsl:call-template>
      <xsl:text>",</xsl:text>

      <!-- AUTORES DEL LIBRO -->
      <xsl:text>"autores":[</xsl:text>
      <xsl:for-each select="$info/db:author | $info/author">
        <xsl:if test="position() &gt; 1"><xsl:text>,</xsl:text></xsl:if>
        <xsl:call-template name="persona-json"><xsl:with-param name="persona" select="."/></xsl:call-template>
      </xsl:for-each>
      <xsl:text>],</xsl:text>

      <!-- EDITORES DEL LIBRO -->
      <xsl:text>"editores":[</xsl:text>
      <xsl:for-each select="$info/db:editor | $info/editor">
        <xsl:if test="position() &gt; 1"><xsl:text>,</xsl:text></xsl:if>
        <xsl:call-template name="persona-json"><xsl:with-param name="persona" select="."/></xsl:call-template>
      </xsl:for-each>
      <!-- ROL Y ABREVIATURA DE LOS EDITORES. LA ABREVIATURA SALE DE
           marca-editor.xsl: gbpublisher.js NO TIENE TABLA PROPIA -->
      <xsl:text>],"rolEditores":"</xsl:text>
      <xsl:call-template name="escapar-json">
        <xsl:with-param name="txt" select="string((($info/db:editor | $info/editor)/@role)[1])"/>
      </xsl:call-template>
      <xsl:text>","abrevEditores":"</xsl:text>
      <xsl:call-template name="abreviatura-editor-db">
        <xsl:with-param name="editores" select="$info/db:editor | $info/editor"/>
      </xsl:call-template>
      <xsl:text>"</xsl:text>

      <xsl:text>};</xsl:text>
    </script>
  </xsl:template>

  <!-- INYECCIÓN DE citaData PARA UN CAPÍTULO (h-*.html) -->
  <xsl:template name="emitir-citadata-capitulo">
    <xsl:param name="capInfo"/>
    <xsl:param name="capTitulo"/>

    <xsl:variable name="capDoi"
                  select="normalize-space(($capInfo/db:biblioid[@class='doi']
                                          | $capInfo/biblioid[@class='doi'])[1])"/>
    <script>
      <xsl:text>var citaData = {</xsl:text>
      <xsl:text>"tipo":"capitulo",</xsl:text>
      <xsl:text>"titulo":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$capTitulo"/></xsl:call-template>
      <xsl:text>","tituloLibro":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$titulo_libro"/></xsl:call-template>
      <xsl:text>","editorial":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$editorial"/></xsl:call-template>
      <xsl:text>","ciudad":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$ciudad_pub"/></xsl:call-template>
      <xsl:text>","doi":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$capDoi"/></xsl:call-template>
      <xsl:text>","url":"","anio":"</xsl:text>
      <xsl:call-template name="escapar-json"><xsl:with-param name="txt" select="$anio_cita"/></xsl:call-template>
      <xsl:text>",</xsl:text>

      <!-- AUTORES DEL CAPÍTULO -->
      <xsl:text>"autores":[</xsl:text>
      <xsl:for-each select="$capInfo/db:author | $capInfo/author">
        <xsl:if test="position() &gt; 1"><xsl:text>,</xsl:text></xsl:if>
        <xsl:call-template name="persona-json"><xsl:with-param name="persona" select="."/></xsl:call-template>
      </xsl:for-each>
      <xsl:text>],</xsl:text>

      <!-- EDITORES DEL LIBRO (PARA "En: ...") -->
      <xsl:text>"editores":[</xsl:text>
      <xsl:for-each select="$info/db:editor | $info/editor">
        <xsl:if test="position() &gt; 1"><xsl:text>,</xsl:text></xsl:if>
        <xsl:call-template name="persona-json"><xsl:with-param name="persona" select="."/></xsl:call-template>
      </xsl:for-each>
      <!-- ROL Y ABREVIATURA DE LOS EDITORES. LA ABREVIATURA SALE DE
           marca-editor.xsl: gbpublisher.js NO TIENE TABLA PROPIA -->
      <xsl:text>],"rolEditores":"</xsl:text>
      <xsl:call-template name="escapar-json">
        <xsl:with-param name="txt" select="string((($info/db:editor | $info/editor)/@role)[1])"/>
      </xsl:call-template>
      <xsl:text>","abrevEditores":"</xsl:text>
      <xsl:call-template name="abreviatura-editor-db">
        <xsl:with-param name="editores" select="$info/db:editor | $info/editor"/>
      </xsl:call-template>
      <xsl:text>"</xsl:text>

      <xsl:text>};</xsl:text>
    </script>
  </xsl:template>

  <!-- AUXILIAR: UNA PERSONA COMO {"apellido":"X","nombre":"Y"} -->
  <xsl:template name="persona-json">
    <xsl:param name="persona"/>
    <xsl:variable name="pn" select="$persona/db:personname | $persona/personname"/>
    <xsl:text>{"apellido":"</xsl:text>
    <xsl:call-template name="escapar-json">
      <xsl:with-param name="txt" select="normalize-space($pn/db:surname | $pn/surname)"/>
    </xsl:call-template>
    <xsl:text>","nombre":"</xsl:text>
    <xsl:call-template name="escapar-json">
      <xsl:with-param name="txt" select="normalize-space($pn/db:firstname | $pn/firstname)"/>
    </xsl:call-template>
    <xsl:text>"}</xsl:text>
  </xsl:template>

  <!-- ==========================================================
       PLANTILLA: fila-compartir
       Genera la fila de iconos de redes sociales para compartir.
       Reusable: la llama el index (con url del libro) y cada
       página de capítulo (con url del capítulo). Portada de
       jats-to-html.xsl (mismos SVG inline, color institucional).
       Parámetros:
         url    : URL absoluta a compartir
         titulo : título a incluir en el texto de compartir
       ========================================================== -->
  <xsl:template name="fila-compartir">
    <xsl:param name="url" as="xs:string"/>
    <xsl:param name="titulo" as="xs:string"/>
    <xsl:if test="$url != ''">
      <div class="meta-compartir">
        <xsl:variable name="url-enc" select="encode-for-uri($url)"/>
        <xsl:variable name="tit-enc" select="encode-for-uri($titulo)"/>
                <!-- BLUESKY -->
                <a class="compartir-icono"
                   href="https://bsky.app/intent/compose?text={$url-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en Bluesky">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M439.8 358.7C436.5 358.3 433.1 357.9 429.8 357.4C433.2 357.8 436.5 358.3 439.8 358.7zM320 291.1C293.9 240.4 222.9 145.9 156.9 99.3C93.6 54.6 69.5 62.3 53.6 69.5C35.3 77.8 32 105.9 32 122.4C32 138.9 41.1 258 47 277.9C66.5 343.6 136.1 365.8 200.2 358.6C203.5 358.1 206.8 357.7 210.2 357.2C206.9 357.7 203.6 358.2 200.2 358.6C106.3 372.6 22.9 406.8 132.3 528.5C252.6 653.1 297.1 501.8 320 425.1C342.9 501.8 369.2 647.6 505.6 528.5C608 425.1 533.7 372.5 439.8 358.6C436.5 358.2 433.1 357.8 429.8 357.3C433.2 357.7 436.5 358.2 439.8 358.6C503.9 365.7 573.4 343.5 593 277.9C598.9 258 608 139 608 122.4C608 105.8 604.7 77.7 586.4 69.5C570.6 62.4 546.4 54.6 483.2 99.3C417.1 145.9 346.1 240.4 320 291.1z"/></svg>
                </a>
                <!-- ENVELOPE -->
                <a class="compartir-icono"
                   href="mailto:?subject={$tit-enc}&amp;body={$url-enc}"
                   title="Compartir por email">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M125.4 128C91.5 128 64 155.5 64 189.4C64 190.3 64 191.1 64.1 192L64 192L64 448C64 483.3 92.7 512 128 512L512 512C547.3 512 576 483.3 576 448L576 192L575.9 192C575.9 191.1 576 190.3 576 189.4C576 155.5 548.5 128 514.6 128L125.4 128zM528 256.3L528 448C528 456.8 520.8 464 512 464L128 464C119.2 464 112 456.8 112 448L112 256.3L266.8 373.7C298.2 397.6 341.7 397.6 373.2 373.7L528 256.3zM112 189.4C112 182 118 176 125.4 176L514.6 176C522 176 528 182 528 189.4C528 193.6 526 197.6 522.7 200.1L344.2 335.5C329.9 346.3 310.1 346.3 295.8 335.5L117.3 200.1C114 197.6 112 193.6 112 189.4z"/></svg>
                </a>
                <!-- FACEBOOK -->
                <a class="compartir-icono"
                   href="https://www.facebook.com/sharer/sharer.php?u={$url-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en Facebook">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M576 320C576 178.6 461.4 64 320 64C178.6 64 64 178.6 64 320C64 440 146.7 540.8 258.2 568.5L258.2 398.2L205.4 398.2L205.4 320L258.2 320L258.2 286.3C258.2 199.2 297.6 158.8 383.2 158.8C399.4 158.8 427.4 162 438.9 165.2L438.9 236C432.9 235.4 422.4 235 409.3 235C367.3 235 351.1 250.9 351.1 292.2L351.1 320L434.7 320L420.3 398.2L351 398.2L351 574.1C477.8 558.8 576 450.9 576 320z"/></svg>
                </a>
                <!-- LINKEDIN -->
                <a class="compartir-icono"
                   href="https://www.linkedin.com/sharing/share-offsite/?url={$url-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en LinkedIn">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M512 96L127.9 96C110.3 96 96 110.5 96 128.3L96 511.7C96 529.5 110.3 544 127.9 544L512 544C529.6 544 544 529.5 544 511.7L544 128.3C544 110.5 529.6 96 512 96zM231.4 480L165 480L165 266.2L231.5 266.2L231.5 480L231.4 480zM198.2 160C219.5 160 236.7 177.2 236.7 198.5C236.7 219.8 219.5 237 198.2 237C176.9 237 159.7 219.8 159.7 198.5C159.7 177.2 176.9 160 198.2 160zM480.3 480L413.9 480L413.9 376C413.9 351.2 413.4 319.3 379.4 319.3C344.8 319.3 339.5 346.3 339.5 374.2L339.5 480L273.1 480L273.1 266.2L336.8 266.2L336.8 295.4L337.7 295.4C346.6 278.6 368.3 260.9 400.6 260.9C467.8 260.9 480.3 305.2 480.3 362.8L480.3 480z"/></svg>
                </a>
                <!-- REDDIT -->
                <a class="compartir-icono"
                   href="https://www.reddit.com/submit?url={$url-enc}&amp;title={$tit-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en Reddit">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M64 320C64 178.6 178.6 64 320 64C461.4 64 576 178.6 576 320C576 461.4 461.4 576 320 576L101.1 576C87.4 576 80.6 559.5 90.2 549.8L139 501C92.7 454.7 64 390.7 64 320zM413.6 217.6C437.2 217.6 456.3 198.5 456.3 174.9C456.3 151.3 437.2 132.2 413.6 132.2C393 132.2 375.8 146.8 371.8 166.2C337.3 169.9 310.4 199.2 310.4 234.6L310.4 234.8C272.9 236.4 238.6 247.1 211.4 263.9C201.3 256.1 188.6 251.4 174.9 251.4C141.9 251.4 115.1 278.2 115.1 311.2C115.1 335.2 129.2 355.8 149.5 365.3C151.5 434.7 227.1 490.5 320.1 490.5C413.1 490.5 488.8 434.6 490.7 365.2C510.9 355.6 524.8 335 524.8 311.2C524.8 278.2 498 251.4 465 251.4C451.3 251.4 438.7 256 428.6 263.8C401.2 246.8 366.5 236.1 328.6 234.7L328.6 234.5C328.6 209.1 347.5 188 372 184.6C376.4 203.4 393.3 217.4 413.5 217.4L413.6 217.6zM241.1 310.9C257.8 310.9 270.6 328.5 269.6 350.2C268.6 371.9 256.1 379.8 239.3 379.8C222.5 379.8 207.9 371 208.9 349.3C209.9 327.6 224.3 311 241 311L241.1 310.9zM431.2 349.2C432.2 370.9 417.5 379.7 400.8 379.7C384.1 379.7 371.5 371.8 370.5 350.1C369.5 328.4 382.3 310.8 399 310.8C415.7 310.8 430.2 327.4 431.1 349.1L431.2 349.2zM383.1 405.9C372.8 430.5 348.5 447.8 320.1 447.8C291.7 447.8 267.4 430.5 257.1 405.9C255.9 403 257.9 399.7 261 399.4C279.4 397.5 299.3 396.5 320.1 396.5C340.9 396.5 360.8 397.5 379.2 399.4C382.3 399.7 384.3 403 383.1 405.9z"/></svg>
                </a>
                <!-- RESEARCHGATE -->
                <a class="compartir-icono"
                   href="https://www.researchgate.net/search?q={$tit-enc}"
                   target="_blank" rel="noopener noreferrer" title="Buscar en ResearchGate">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M96 96L96 544L544 544L544 96L96 96zM358.2 430.4C351.6 433.4 325 436.4 308.2 416.2C299 405.6 282.9 382.9 266 352.6C257.1 352.6 251.3 352.6 244.6 352L244.6 398.4C244.6 421.9 250.6 419.6 270.4 422.3L270.4 430.4C263.5 430.1 247.3 429.6 234.8 429.6C221.7 429.6 208.7 430.2 201.2 430.4L201.2 422.3C216.7 419.4 223.2 421 223.2 398.4L223.2 289C223.2 266.4 216.8 268 201.2 265.1L201.2 257C227 258 254.3 256.4 272.1 256.4C303.8 256.4 328 270.8 328 302C328 323.1 311.3 344.2 288.8 349.5C302.4 373.7 318.8 395.1 331 408.4C338.2 416.2 348.2 423.1 358.2 423.1L358.2 430.4zM381.1 295.4C357.8 295.4 348.9 279.7 348.9 263.2L348.9 231C348.9 218.8 357.7 200.6 382.9 200.6C408.1 200.6 413.3 218.5 413.3 218.5L402.6 225.7C402.6 225.7 397.1 213.2 382.9 213.2C375 213.2 363.2 220.5 363.2 232.9L363.2 259.7C363.2 273.1 369.8 283 381.1 283C395.2 283 402.6 272.1 402.6 256.2L384.7 256.2L384.7 245.5L415.1 245.5C415.1 266 419.8 295.4 381.1 295.4zM264.6 340.1C255.2 340.1 251 339.8 244.6 339.3L244.6 269.6C251 269 259.6 269 267.1 269C290.4 269 304.3 281.2 304.3 303.5C304.3 325.4 289.3 340.1 264.6 340.1z"/></svg>
                </a>
                <!-- TELEGRAM -->
                <a class="compartir-icono"
                   href="https://t.me/share/url?url={$url-enc}&amp;text={$tit-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en Telegram">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M320 72C183 72 72 183 72 320C72 457 183 568 320 568C457 568 568 457 568 320C568 183 457 72 320 72zM435 240.7C431.3 279.9 415.1 375.1 406.9 419C403.4 437.6 396.6 443.8 390 444.4C375.6 445.7 364.7 434.9 350.7 425.7C328.9 411.4 316.5 402.5 295.4 388.5C270.9 372.4 286.8 363.5 300.7 349C304.4 345.2 367.8 287.5 369 282.3C369.2 281.6 369.3 279.2 367.8 277.9C366.3 276.6 364.2 277.1 362.7 277.4C360.5 277.9 325.6 300.9 258.1 346.5C248.2 353.3 239.2 356.6 231.2 356.4C222.3 356.2 205.3 351.4 192.6 347.3C177.1 342.3 164.7 339.6 165.8 331C166.4 326.5 172.5 322 184.2 317.3C256.5 285.8 304.7 265 328.8 255C397.7 226.4 412 221.4 421.3 221.2C423.4 221.2 427.9 221.7 430.9 224.1C432.9 225.8 434.1 228.2 434.4 230.8C434.9 234 435 237.3 434.8 240.6z"/></svg>
                </a>
                <!-- WHATSAPP -->
                <a class="compartir-icono"
                   href="https://wa.me/?text={$url-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en WhatsApp">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M476.9 161.1C435 119.1 379.2 96 319.9 96C197.5 96 97.9 195.6 97.9 318C97.9 357.1 108.1 395.3 127.5 429L96 544L213.7 513.1C246.1 530.8 282.6 540.1 319.8 540.1L319.9 540.1C442.2 540.1 544 440.5 544 318.1C544 258.8 518.8 203.1 476.9 161.1zM319.9 502.7C286.7 502.7 254.2 493.8 225.9 477L219.2 473L149.4 491.3L168 423.2L163.6 416.2C145.1 386.8 135.4 352.9 135.4 318C135.4 216.3 218.2 133.5 320 133.5C369.3 133.5 415.6 152.7 450.4 187.6C485.2 222.5 506.6 268.8 506.5 318.1C506.5 419.9 421.6 502.7 319.9 502.7zM421.1 364.5C415.6 361.7 388.3 348.3 383.2 346.5C378.1 344.6 374.4 343.7 370.7 349.3C367 354.9 356.4 367.3 353.1 371.1C349.9 374.8 346.6 375.3 341.1 372.5C308.5 356.2 287.1 343.4 265.6 306.5C259.9 296.7 271.3 297.4 281.9 276.2C283.7 272.5 282.8 269.3 281.4 266.5C280 263.7 268.9 236.4 264.3 225.3C259.8 214.5 255.2 216 251.8 215.8C248.6 215.6 244.9 215.6 241.2 215.6C237.5 215.6 231.5 217 226.4 222.5C221.3 228.1 207 241.5 207 268.8C207 296.1 226.9 322.5 229.6 326.2C232.4 329.9 268.7 385.9 324.4 410C359.6 425.2 373.4 426.5 391 423.9C401.7 422.3 423.8 410.5 428.4 397.5C433 384.5 433 373.4 431.6 371.1C430.3 368.6 426.6 367.2 421.1 364.5z"/></svg>
                </a>
                <!-- X-TWITTER -->
                <a class="compartir-icono"
                   href="https://twitter.com/intent/tweet?url={$url-enc}&amp;text={$tit-enc}"
                   target="_blank" rel="noopener noreferrer" title="Compartir en X">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="#2D5A8E" d="M453.2 112L523.8 112L369.6 288.2L551 528L409 528L297.7 382.6L170.5 528L99.8 528L264.7 339.5L90.8 112L236.4 112L336.9 244.9L453.2 112zM428.4 485.8L467.5 485.8L215.1 152L173.1 152L428.4 485.8z"/></svg>
                </a>
      </div>
    </xsl:if>
  </xsl:template>


  <!-- ==========================================================
       SEPARADOR DE UNA LISTA DE AUTORES
       ==========================================================
       Lo que va antes del nombre en la posición $pos de $total:
       nada, coma, o la conjunción antes del último: «A», «A y B»,
       «A, B y C». $nombre es la palabra que sigue —el nombre de
       pila— y decide entre «y» y «e».
       REGLA DE LA RAE (DPD, «y»): «e» ANTE i- O hi- CON SONIDO DE
       VOCAL («Pérez e Ibáñez», «Ana e Hilda»); «y» SI ESA i SIN
       TILDE FORMA DIPTONGO CON LA VOCAL SIGUIENTE («Ana y
       Iolanda», «agua y hielo»). LA MISMA REGLA QUE
       m_PrimerasLibro.Conjuncion EN LA PORTADA Y EL PDF. -->
  <xsl:template name="separador-autoria">
    <xsl:param name="pos"/>
    <xsl:param name="total"/>
    <xsl:param name="nombre"/>
    <xsl:variable name="sinH" select="replace(normalize-space($nombre), '^[hH]', '')"/>
    <xsl:choose>
      <xsl:when test="$pos = 1"/>
      <xsl:when test="$pos &lt; $total">
        <xsl:text>, </xsl:text>
      </xsl:when>
      <xsl:when test="matches($sinH, '^[iI][aeiouáéíóúüAEIOUÁÉÍÓÚÜ]')">
        <xsl:text> y </xsl:text>
      </xsl:when>
      <xsl:when test="matches($sinH, '^[iIíÍ]')">
        <xsl:text> e </xsl:text>
      </xsl:when>
      <xsl:otherwise>
        <xsl:text> y </xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

</xsl:stylesheet>