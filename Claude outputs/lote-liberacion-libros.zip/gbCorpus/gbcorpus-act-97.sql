-- ============================================================
-- gbCorpus — actualización 97: corte de título y nota con símbolo
--            liberados para libros (SC-63, SC-86)
-- Esquema: 2
-- Origen: conversación del 11/11/2026. Prueba de Alberto en Linux
--         Mint con «El Atlántico de los exilios»: PDF, HTML y EPUB.
--         Decisión de Alberto: se habilitan en libros; en revistas
--         quedan pendientes para la refactorización del módulo, en
--         otra conversación.
-- Fecha:  2026-11-11
-- Aplicar: después de act-96. Va con gbShortcodes datos-v5-026.sql.
--
-- ALTAS: ninguna.
--
-- MODIFICA:
--   SC-63   PROBADO EN MINT: el arreglo de GV-192 y la liberación;
--           pendiente
--   SC-86   PROBADO EN MINT (sección nueva); pendiente
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-96 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 96;
INSERT INTO verificacion SELECT 'SC-63 pendiente', pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10). En el panel (corte-titulo, en borrador hasta probarlo en una revista, SC-34): en una revista, la inserción y las tres salidas, después de la refactorización del módulo de revistas; en los dos productos, los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda. Revistas: `jats-to-latex.xsl` escribe `\gbCorteTitulo` en `sec/title/break`, y la segunda línea cae debajo del número (GV-192); se corrige con la refactorización, como en el libro (`\gbCorteSeccion`).' FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-86 pendiente', pendiente = 'Probar en Mint con un libro real: PDF (la llamada y la nota al pie, el sumario y los marcadores sin la nota), HTML (el panel), EPUB (epubcheck), la inserción desde el panel y un caso que frene. Revistas, después de su refactorización: el canónico JATS (fn/@symbol con <label>), las hojas JATS y los sabores SciELO y Redalyc. El ODT.' FROM entradas WHERE codigo = 'SC-86';
INSERT INTO verificacion SELECT 'SC-86 sin prueba en Mint', instr(cuerpo, 'PROBADO EN MINT') = 0 FROM entradas WHERE codigo = 'SC-86';
INSERT INTO verificacion SELECT 'SC-63 ancla una vez', (length(cuerpo) - length(replace(cuerpo, 'La fila sigue en borrador hasta probarla en una revista (gbShortcodes `datos-v5-024.sql`).', ''))) = length('La fila sigue en borrador hasta probarla en una revista (gbShortcodes `datos-v5-024.sql`).') FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-86 ancla una vez', (length(cuerpo) - length(replace(cuerpo, 'siete vínculos para las siete numeradas.', ''))) = length('siete vínculos para las siete numeradas.') FROM entradas WHERE codigo = 'SC-86';

-- ------------------------------------------------------------
-- 2. SC-63
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'La fila sigue en borrador hasta probarla en una revista (gbShortcodes `datos-v5-024.sql`).', 'La fila sigue en borrador hasta probarla en una revista (gbShortcodes `datos-v5-024.sql`).

Alberto, 11/11, en el mismo libro, con el arreglo de GV-192 (contrato 23): la segunda línea del título de sección queda alineada con el texto del título en el PDF; el HTML y el EPUB, sin cambios. Liberado para libros con gbShortcodes `datos-v5-026.sql`. En revistas, la fila queda `no_aplica` hasta la refactorización del módulo de revistas, que la retoma (decisión de Alberto, 11/11).'),
       pendiente = 'Falta en Mint, en libros: un caso que frene en la conversión (corte al final, dos seguidos o dentro de una bastardilla), el control corte_fuera_de_titulo y los avisos del panel que no se vieron (# del capítulo, al principio, al final, dentro de una palabra, pegado a otro corte). Revistas, en la refactorización del módulo (otra conversación): `jats-to-latex.xsl` escribe `\gbCorteTitulo` en `sec/title/break` y la segunda línea cae debajo del número (GV-192), se corrige con `\gbCorteSeccion` como en el libro; después, la fila corte-titulo pasa de no_aplica a borrador y se prueba en una revista. El ODT, cuando se encare (decisión de Alberto, 21/10).',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 liberado', instr(cuerpo, 'datos-v5-026.sql') > 0 FROM entradas WHERE codigo = 'SC-63';

-- ------------------------------------------------------------
-- 3. SC-86
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'siete vínculos para las siete numeradas.', 'siete vínculos para las siete numeradas.

PROBADO EN MINT

Alberto, 11/11, con un libro real («El Atlántico de los exilios»): en el PDF, la llamada * en la apertura del título, sin corchetes, y al pie la nota con el mismo símbolo entre las numeradas, que siguen [2], *, [3]; en el HTML, la llamada * y «Nota *» en el panel; en el EPUB, la llamada * y la nota emergente encabezada por *. Liberada para libros con gbShortcodes `datos-v5-026.sql` (decisión de Alberto, 11/11).'),
       pendiente = 'Falta en Mint: epubcheck del EPUB, la inserción desde el panel, la ayuda y un caso que frene. Revistas, en la refactorización del módulo (otra conversación): el canónico JATS (fn/@symbol con <label>), jats-to-latex, jats-to-html, jats-to-epub, los sabores SciELO y Redalyc, y la fila nota-simbolo de no_aplica a borrador. El ODT.',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-86';
INSERT INTO verificacion SELECT 'SC-86 probado', instr(cuerpo, 'PROBADO EN MINT') > 0 FROM entradas WHERE codigo = 'SC-86';

COMMIT;

SELECT codigo, estado, pendiente FROM entradas WHERE codigo IN ('SC-63','SC-86') ORDER BY numero;
