-- ============================================================
-- datos-v5-026: corte-titulo y nota-simbolo liberados para libros
-- ------------------------------------------------------------
-- Modifica:
--   corte-titulo: liberado para libros; revistas pasa de borrador a
--   no_aplica hasta la refactorización del módulo de revistas, que lo
--   retoma (decisión de Alberto, 11/11). SC-34 no deja liberar en un
--   producto con el otro en borrador.
--   nota-simbolo: liberado para libros (revistas ya era no_aplica).
--   Las dos, sin pendiente: lo que falta va en SC-63 y SC-86 (SC-34).
--   Probadas por Alberto en Mint (11/11) con «El Atlántico de los
--   exilios»: PDF, HTML y EPUB; el corte con el contrato 23 (GV-192).
-- Después: reexportar el catálogo (SC-34).
-- Esquema: 5
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE _verif (paso TEXT, ok INTEGER CHECK (ok = 1));

-- --- 1. PRECONDICIONES: datos-v5-024 Y datos-v5-025 APLICADOS, SIN CAMBIOS ---
INSERT INTO _verif SELECT 'corte-titulo en borrador', COUNT(*) = 1 FROM shortcodes
  WHERE nombre = 'corte-titulo' AND estado_libro = 'borrador' AND estado_revista = 'borrador'
    AND pendiente = 'Para liberar (SC-34: en los dos productos a la vez): probar en Mint con una revista, después de la refactorización en curso del módulo de revistas: la inserción desde el panel, un aviso y las tres salidas. En los dos: los avisos que faltan (# del capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte) y la ayuda con el ejemplo coloreado. En libros, lo probado está en SC-63.';
INSERT INTO _verif SELECT 'nota-simbolo en borrador', COUNT(*) = 1 FROM shortcodes
  WHERE nombre = 'nota-simbolo' AND estado_libro = 'borrador' AND estado_revista = 'no_aplica'
    AND pendiente = 'Probar en Mint con un libro: la inserción desde el panel, la ayuda con el ejemplo coloreado, el PDF, el HTML y el EPUB del documento de prueba, y un caso que frene.';
INSERT INTO _verif SELECT 'ayuda completa', COUNT(*) = 2 FROM shortcodes
  WHERE nombre IN ('corte-titulo', 'nota-simbolo')
    AND que_es IS NOT NULL AND ejemplo IS NOT NULL AND como_sale IS NOT NULL;

-- --- 2. LIBERACIÓN ---
UPDATE shortcodes SET
  estado_libro = 'liberado',
  estado_revista = 'no_aplica',
  pendiente = NULL,
  fecha_modificacion = datetime('now','localtime')
 WHERE nombre = 'corte-titulo';
UPDATE shortcodes SET
  estado_libro = 'liberado',
  pendiente = NULL,
  fecha_modificacion = datetime('now','localtime')
 WHERE nombre = 'nota-simbolo';

INSERT INTO _verif SELECT 'las dos liberadas', COUNT(*) = 2 FROM shortcodes
  WHERE nombre IN ('corte-titulo', 'nota-simbolo')
    AND estado_libro = 'liberado' AND estado_revista = 'no_aplica' AND pendiente IS NULL;

DROP TABLE _verif;

COMMIT;

SELECT nombre, estado_libro, estado_revista FROM shortcodes
 WHERE nombre IN ('corte-titulo', 'nota-simbolo') ORDER BY nombre;
