# Lote 2 del HTML integrado: el marco que publica gbWeb (5/11/2026)

Al construir, el portal publica en `docs/marco/` lo que un libro integrado necesita para verse dentro del portal:

- la cabecera y el pie en cada idioma;
- la hoja de estilo;
- las fuentes;
- el logo;
- un manifiesto con el sha256 de cada archivo.

El lote suma además la monoespaciada Noto Sans Mono.

Ninguna página del portal cambia. Generé el sitio con la hoja vieja y con la nueva, con los mismos datos, y las páginas salen idénticas byte a byte. Solo aparece la carpeta `marco/`, y la hoja de estilo cambia de nombre porque suma las fuentes nuevas.

No toca la base. Todo va en el repositorio de gbWeb, con el IDE cerrado.

## Qué trae el zip

| Archivo | |
|---|---|
| `.hidden/xslt/portal.xsl` | **completo.** Ver «La hoja» |
| `.hidden/css/estilo.css` | **completo.** Suma Noto Sans Mono |
| `.hidden/engine/construir_sitio.sh` | **completo.** Ver «La construcción» |
| `.hidden/sitio/fuentes/noto-sans-mono-normal-{400,600}-{latin,latin-ext}.woff2` | **nuevos** (4) |
| `.hidden/sitio/fuentes/LEEME.md` | **completo.** Documenta de dónde sale Noto Sans Mono y cómo se rehace |

## La monoespaciada

- **Origen:** Noto Sans Mono 2.014, bajada del repositorio `google/fonts` (`ofl/notosansmono/`). El nombre y la licencia (OFL) están confirmados en su `METADATA.pb`. «Noto Mono» es el nombre viejo; la familia de hoy es Noto Sans Mono.
- **Archivos:** pesos 400 y 600, juegos `latin` y `latin-ext`, hechos igual que los de Noto Serif. No hay cursiva porque la familia no la tiene.
- **Licencia:** su `OFL.txt` es idéntico al de Noto Serif (tienen el mismo sha256), así que vale el que ya está.
- **En la hoja:** la variable `--font-mono` y la regla `code, pre, kbd, samp`.

## La hoja (`portal.xsl`)

La cabecera y el pie salen del esqueleto de página y pasan a dos plantillas propias, `cabecera` y `pie`. El portal las usa igual que antes, y el marco las usa con `marco = true()`.

En el marco, la cabecera cambia en cuatro cosas:

- **Enlaces con la dirección completa del portal**, en el idioma del marco: `https://…/en/catalogo/index.html`.
- **Logo relativo al fragmento** (`../media/logo-portal-….svg`). gbpublisher lo copia junto con el marco, así el libro no depende de que el portal responda.
- **Compartir lleva los patrones con `{u}` y `{t}`**, por ejemplo `https://www.facebook.com/sharer.php?u={u}&t={t}`. gbpublisher los completa en cada página del libro con su dirección y su título.
- **Sin banderas.**

Los fragmentos son XML bien formado (`marco/<idioma>/cabecera.html` y `pie.html`), para que gbpublisher los lea con `doc()`. Solo se generan si el portal tiene cargada su dirección: sin ella no hay enlaces completos.

## La construcción (`construir_sitio.sh`)

Apartado 7b nuevo, «Marco para los libros». A los fragmentos que escribió la XSLT les suma:

- `marco/marco.css`: la hoja del portal, con nombre fijo, porque gbpublisher la busca por ese nombre;
- `marco/fuentes/`: las WOFF2 con su `OFL.txt`;
- `marco/media/`: el logo;
- `marco/marco.xml`, el manifiesto:

```xml
<marco portal="L-IMAGO" url-base="https://albertomoyano.github.io/L-IMAGO/">
  <archivo ruta="en/cabecera.html" sha256="936e97e7…"/>
  …
  <archivo ruta="marco.css" sha256="47cd5d2e…"/>
  <archivo ruta="media/logo-portal-d2be17d1.svg" sha256="d2be17d1…"/>
  …
</marco>
```

El manifiesto lista los archivos en orden fijo y sin fecha, así que dos construcciones dan la misma huella. En el lote 3, gbpublisher baja `marco.xml`, baja cada archivo, controla su sha256 y copia todo dentro del libro.

Además:

- la cuenta de páginas ya no incluye los fragmentos del marco;
- las fuentes se copian con `OFL*.txt`.

## Lo que hay que mirar en Mint

1. Construí y desplegá L-IMAGO.
2. Abrí `https://albertomoyano.github.io/L-IMAGO/marco/marco.xml`: tiene que listar 25 archivos.
3. Abrí `…/marco/es/cabecera.html`: se ve la cabecera sin estilo, que es lo esperado porque es un fragmento.

## Verificado en el contenedor

- **Páginas idénticas:** con los mismos datos, las páginas del portal salen idénticas antes y después del lote.
- **El marco completo:** 25 archivos en tres grupos:
  - la cabecera y el pie de cada idioma, 6 fragmentos, todos XML bien formado;
  - 16 fuentes y su licencia;
  - la hoja y el logo.
- **Las huellas:** cada sha256 del manifiesto coincide con su archivo.
- **La cabecera en inglés:** menú en inglés con enlaces completos, sin banderas, y compartir con `{u}` y `{t}`.
- **Determinismo:** dos construcciones dan la misma huella de `docs/`.
- **Enlaces:** 1761 enlaces locales, ninguno roto, contando el logo de los fragmentos.
