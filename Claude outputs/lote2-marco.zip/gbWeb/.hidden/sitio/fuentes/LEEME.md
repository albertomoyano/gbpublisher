# Noto Serif y Noto Sans Mono para los portales de gbWeb

Archivos fijos: `construir_sitio.sh` los copia tal cual a `docs/fuentes/`. No se regeneran en cada construcción.

## Origen

- Noto Serif 2.015, fuente variable, del repositorio `google/fonts` (`ofl/notoserif/`), bajada el 4/11/2026.
- `NotoSerif[wdth,wght].ttf`: sha256 `4d8e6761424656867019081a1a01336f3cb086982682698714054fc33f782713`.
- `NotoSerif-Italic[wdth,wght].ttf`: sha256 `e87acbc6c0efd0d9a20d6a8cbbda2b266c14be3a3a6f5af8ec9d7b2460570ad1`.
- Licencia: SIL Open Font License 1.1 (`OFL.txt`). Se publica con las fuentes, como pide la licencia.

## Qué hay

Pesos 400 y 600 (el 600 es el que usa el HTML del libro en gbpublisher), redonda y bastardilla, ancho 100. Cada uno partido en tres juegos, con el mismo `unicode-range` en `estilo.css`. El navegador baja solo los juegos que usa la página.

| Juego | Para qué |
|---|---|
| `latin` | español, inglés, portugués, comillas «», rayas, € |
| `latin-ext` | Ł, ő, ş y el resto del latín extendido |
| `greek` | griego, también politónico |

## Cómo se rehacen

Con fontTools y brotli (`pip install fonttools brotli`):

```
fonttools varLib.instancer NotoSerif[wdth,wght].ttf wght=600 wdth=100 -o tmp.ttf
pyftsubset tmp.ttf --unicodes="<rango del juego>" --flavor=woff2 --layout-features='*' --output-file=noto-serif-normal-600-latin.woff2
```

Los rangos están en `estilo.css`. fontTools estampa la fecha en el archivo: dos generaciones no dan los mismos bytes. Por eso se generan una vez y se guardan.

## Noto Sans Mono (5/11/2026)

La monoespaciada, de la misma familia (decisión de Alberto): la usan el código de los libros integrados al portal, que toman esta hoja con el marco, y cualquier `code` o `pre` del portal.

- Noto Sans Mono 2.014, fuente variable, del repositorio `google/fonts` (`ofl/notosansmono/`), bajada el 5/11/2026.
- `NotoSansMono[wdth,wght].ttf`: sha256 `2cb2adb378a8f574213e23df697050b83c54c27df465a2015552740b2769a081`.
- Licencia: SIL Open Font License 1.1. El `OFL.txt` de Noto Sans Mono es idéntico al de Noto Serif (los dos son del proyecto `notofonts/latin-greek-cyrillic`; mismo sha256): vale el que ya está.
- Pesos 400 y 600, ancho 100, sin cursiva (la familia no la tiene). Juegos `latin` y `latin-ext`, con los mismos rangos que Noto Serif. Sin `greek`: el código no lo necesita.
- Se rehacen igual: `fonttools varLib.instancer NotoSansMono[wdth,wght].ttf wght=600 wdth=100 -o tmp.ttf` y `pyftsubset` con el rango del juego.
