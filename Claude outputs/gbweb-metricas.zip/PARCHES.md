# Entrega: la ventana «Métricas» en la ficha (4/11/2026)

En cada ficha, debajo del resumen, aparece un botón «Métricas». Abre una ventana con:

- los totales: visitas a la ficha y descargas del PDF y del EPUB;
- el uso por mes, en un gráfico;
- las citas;
- dónde se lee, por país.

**Los datos son simulados**, y la ventana lo dice en una franja amarilla, en los tres idiomas. El portal es público, así que nadie los va a tomar por reales.

No toca la base: no hay script de esquema.

## Qué trae el zip

Todo va en la raíz del repositorio de gbWeb, con el IDE **cerrado**.

| Archivo | |
|---|---|
| `.src/m_Metricas.module` | **nuevo.** Escribe el bloque `<metricas>` de cada libro |
| `.src/m_Sitio.module` | **completo.** Es el tuyo; suma el apartado 5c, que llama a `m_Metricas` |
| `.hidden/xslt/portal.xsl` | **completo.** Es el tuyo; suma la ventana, el gráfico y sus textos |
| `.hidden/css/estilo.css` | **completo.** Es el tuyo; suma el apartado 8b |
| `.hidden/sitio/iconos/chart-simple.svg`, `xmark.svg` | **nuevos.** Font Awesome 7.2.0, de `solid/`, de tu `z-fontawesome` |

`construir_sitio.sh` no cambia.

## Cómo está hecho

**La forma de construir es la 2, la que elegiste.**
- gbWeb pone los datos en `sitio.xml` al construir, como una foto.
- La XSLT los dibuja.
- Quien lee el portal no consulta a nadie.

**Hoy los datos son simulados.**
- `m_Metricas` los inventa con un generador que usa el id del libro como semilla.
- La serie son 24 meses que terminan en un mes fijo, octubre de 2026.
- Nada depende de la fecha del día, así que dos construcciones dan la misma huella.
- El bloque lleva `simulado="si"`, y eso es lo que hace aparecer el aviso.

El bloque que escribe en `sitio.xml` tiene esta forma:

```xml
<metricas simulado="si" corte-ano="2026" corte-mes="10">
  <mes ano="2024" mes="11" visitas="106" pdf="31" epub="13"/>
  …
  <citas total="28" recientes="18"/>
  <pais codigo="AR" pc="43"/>
  …
  <pais codigo="otros" pc="14"/>
</metricas>
```

**Cuando tengamos las fuentes reales**, cambia solo de dónde salen los números dentro de `m_Metricas`. El bloque y la XSLT quedan como están.

**Las descargas** solo cuentan si el libro las ofrece, con la misma regla que los botones: acceso abierto o mixto, con la URL cargada. Un libro solo a la venta muestra únicamente las visitas.

**Sin JavaScript**, igual que el resumen.
- Una casilla oculta abre la ventana.
- El fondo oscuro y la X son etiquetas de esa misma casilla, y la cierran.
- Así funciona también en el visor de gbWeb, cuyo motor de navegador es viejo.
- El precio: Esc no la cierra.

**El gráfico** es un SVG que calcula la XSLT, con las coordenadas en texto fijo.
- Al pasar el mouse por un punto se ve su valor.
- En el teléfono, la ventana ocupa una sola columna.

**Los textos** de la ventana están en los tres idiomas. Los nombres de los países salen de una tabla en la XSLT, y los miles van con punto en castellano y portugués y con coma en inglés.

## Para que lo vea tu socio

1. Copiá los archivos.
2. Abrí el portal.
3. Construí.
4. Desplegá.

Con eso queda en https://albertomoyano.github.io/L-IMAGO/. Si GitHub Pages tarda, la hoja de estilo nueva igual entra enseguida, porque cambia de nombre.

## Verificado en el contenedor

- **Compila:** gbWeb completo, con gbc3 3.19.
- **`sitio.xml`:** los 18 libros llevan su bloque, y ningún país sale con 0 %.
- **La ventana:** se abre y se cierra con la X y con el fondo.
  - Capturas en español, inglés y teléfono, de un libro mixto (con descargas) y de uno solo a la venta (sin ellas).
- **Determinismo:** dos construcciones dan la misma huella.
- **Enlaces:** 1758 enlaces locales, ninguno roto.
