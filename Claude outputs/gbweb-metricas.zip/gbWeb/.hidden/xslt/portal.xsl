<?xml version="1.0" encoding="UTF-8"?>
<!--
  portal.xsl — gbWeb
  ============================================================================
  Del sitio.xml que escribe gbWeb (m_Sitio) al sitio estático del portal, en
  una sola corrida (SC-80, CÓMO SE ARMA). Cada página en tres idiomas: el
  español en la raíz, los otros en en/ y pt/ (SC-80, IDIOMAS).

    index.html               inicio: imagen destacada y los 4 libros más
                             nuevos («Últimos títulos», en dos columnas),
                             con un enlace al catálogo
    catalogo/index.html      el catálogo entero, de a 8 en dos columnas
                             (catalogo/2/…)
    libro/<id>/index.html    la ficha de cada libro (la URL es el id), con
                             sus puntos de venta, la ventana «Métricas» y
                             4 libros sugeridos
    <clave>/index.html       las páginas escritas (sobre-la-editorial/…)

  EL MENÚ SALE DE menu.xml: LA MATRIZ FIJA DE PÁGINAS DE CADA CLASE DE
  PORTAL. LAS PÁGINAS ESCRITAS SON EL MARKDOWN DE paginas/ DEL PORTAL, QUE
  construir_sitio.sh PASA CON PANDOC A tmp/paginas/<clave>.<idioma>.xml
  (UN <div> BIEN FORMADO). LA PÁGINA EXISTE SI ESTÁ SU VERSIÓN EN ESPAÑOL;
  SIN LA TRADUCCIÓN, VA EL ESPAÑOL CON lang="es".

  LA CABECERA Y EL PIE SON LOS MISMOS EN TODAS LAS PÁGINAS (DECISIÓN DE
  ALBERTO). La cabecera: franja con el logo y el menú, filete, buscador e
  idiomas. El buscador está plantado y todavía no busca: falta el índice.

  PARÁMETROS (los pasa construir_sitio.sh; las rutas son relativas a la raíz)
    logo                media/logo-portal-<sha8>.<ext>, o vacío: el código
                        del portal como texto
    destacada           media/destacada-<sha8>.<ext>: la imagen de inicio
    destacada_ancho     sus medidas, para que el navegador reserve el lugar
    destacada_alto

  DETERMINISMO (SC-80): el orden es el del XML, que ya viene ordenado
  (SC-81); no hay fecha de generación; las rutas son relativas.
  ============================================================================
-->
<xsl:stylesheet version="2.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:gbw="urn:gbweb:funciones"
    exclude-result-prefixes="xs gbw">

  <!-- SIN META DE TIPO AGREGADA POR SAXON: LA PÁGINA LLEVA SU PROPIO charset -->
  <xsl:output method="html" version="5.0" encoding="UTF-8" indent="yes" include-content-type="no"/>

  <xsl:param name="logo" as="xs:string" select="''"/>
  <xsl:param name="destacada" as="xs:string" select="''"/>
  <xsl:param name="destacada_ancho" as="xs:string" select="''"/>
  <xsl:param name="destacada_alto" as="xs:string" select="''"/>
  <!-- LA HOJA DE ESTILO PUBLICADA: estilo-<sha8>.css (construir_sitio.sh) -->
  <xsl:param name="estilo" as="xs:string" select="'estilo.css'"/>

  <xsl:variable name="codigo" select="string(/sitio/@codigo)"/>

  <!-- LOS DATOS DEL PORTAL (ESQUEMA gbweb 1.2.0). SIN NOMBRE, VA EL CÓDIGO;
       SIN URL DEL SITIO, NO HAY BOTONES DE COMPARTIR NI VISTA PREVIA, QUE
       NECESITAN DIRECCIONES COMPLETAS -->
  <xsl:variable name="datos" select="/sitio/datos"/>
  <xsl:variable name="nombre" select="if ($datos/nombre) then string($datos/nombre) else $codigo"/>
  <xsl:variable name="url_base" select="string($datos/url-base)"/>

  <!-- LOS ÍCONOS (FONT AWESOME FREE 7.2.0, CC BY 4.0: LA ATRIBUCIÓN VIAJA
       EN EL COMENTARIO DE CADA SVG), JUNTO A LAS HOJAS EN ../sitio/iconos/ -->
  <xsl:variable name="dir_iconos" select="resolve-uri('../sitio/iconos/', static-base-uri())"/>

  <!-- LAS REDES PARA COMPARTIR, EN ORDEN (DECISIÓN DE ALBERTO: TODAS). {u}
       ES LA DIRECCIÓN DE LA PÁGINA Y {t} SU TÍTULO, LOS DOS CODIFICADOS.
       LOS PATRONES: DOCUMENTACIÓN DE X (WEB INTENT) Y DE BLUESKY (INTENT
       LINKS); LOS DEMÁS, LOS DE USO PÚBLICO DE CADA RED -->
  <xsl:variable name="compartir" as="element()*">
    <r icono="facebook" nombre="Facebook" patron="https://www.facebook.com/sharer.php?u={{u}}&amp;t={{t}}"/>
    <r icono="x" nombre="X" patron="https://twitter.com/intent/tweet?url={{u}}&amp;text={{t}}"/>
    <r icono="linkedin" nombre="LinkedIn" patron="https://www.linkedin.com/sharing/share-offsite/?url={{u}}"/>
    <r icono="whatsapp" nombre="WhatsApp" patron="https://api.whatsapp.com/send/?text={{t}}%20{{u}}"/>
    <r icono="telegram" nombre="Telegram" patron="https://telegram.me/share/url?url={{u}}&amp;text={{t}}"/>
    <r icono="bluesky" nombre="Bluesky" patron="https://bsky.app/intent/compose?text={{t}}%20{{u}}"/>
    <r icono="reddit" nombre="Reddit" patron="https://www.reddit.com/submit?url={{u}}&amp;title={{t}}"/>
    <r icono="envelope" nombre="correo" patron="mailto:?subject={{t}}&amp;body={{u}}"/>
  </xsl:variable>

  <!-- LOS NOMBRES DE LAS REDES DE LOS PERFILES (portal_red) -->
  <xsl:variable name="nombres_redes" as="element()*">
    <r tipo="facebook" nombre="Facebook"/>
    <r tipo="x" nombre="X"/>
    <r tipo="linkedin" nombre="LinkedIn"/>
    <r tipo="bluesky" nombre="Bluesky"/>
    <r tipo="telegram" nombre="Telegram"/>
    <r tipo="reddit" nombre="Reddit"/>
    <r tipo="researchgate" nombre="ResearchGate"/>
    <r tipo="instagram" nombre="Instagram"/>
    <r tipo="youtube" nombre="YouTube"/>
  </xsl:variable>
  <xsl:variable name="libros" select="/sitio/libro"/>

  <!-- LAS TIENDAS (libro_venta, gbpublisher 1.21.0), EN EL ORDEN DE LOS
       BOTONES. LOS NOMBRES SON MARCAS: NO SE TRADUCEN. TRES ÍCONOS SON DE
       FONT AWESOME (SVG, CON EL COLOR DEL TEXTO); MERCADO LIBRE NO ESTÁ AHÍ
       Y VA SU LOGO EN PNG, EN COLOR -->
  <xsl:variable name="tiendas" as="element()*">
    <r tienda="amazon" nombre="Amazon" svg="amazon"/>
    <r tienda="apple" nombre="Apple Books" svg="apple"/>
    <r tienda="google" nombre="Google Play" svg="google-play"/>
    <r tienda="mercadolibre" nombre="Mercado Libre" png="mercadolibre.png"/>
  </xsl:variable>

  <!-- LOS PAÍSES DE LA VENTANA «MÉTRICAS», POR SU CÓDIGO ISO 3166 -->
  <xsl:variable name="paises" as="element()*">
    <p c="AR" es="Argentina" en="Argentina" pt="Argentina"/>
    <p c="MX" es="México"    en="Mexico"    pt="México"/>
    <p c="CL" es="Chile"     en="Chile"     pt="Chile"/>
    <p c="ES" es="España"    en="Spain"     pt="Espanha"/>
    <p c="BR" es="Brasil"    en="Brazil"    pt="Brasil"/>
    <p c="CO" es="Colombia"  en="Colombia"  pt="Colômbia"/>
    <p c="UY" es="Uruguay"   en="Uruguay"   pt="Uruguai"/>
    <p c="otros" es="Otros"  en="Others"    pt="Outros"/>
  </xsl:variable>

  <!-- LOS MILES: CON PUNTO EN CASTELLANO Y PORTUGUÉS, CON COMA EN INGLÉS -->
  <xsl:decimal-format name="punto" decimal-separator="," grouping-separator="."/>

  <!-- EL CATÁLOGO idiomas DE gbpublisher TRAE EL NOMBRE EN CASTELLANO Y EN
       INGLÉS. EL PORTUGUÉS, PARA LOS IDIOMAS MÁS COMUNES; LOS DEMÁS VAN EN
       CASTELLANO -->
  <xsl:variable name="idiomas_pt" as="element()*">
    <i c="es" n="Espanhol"/>
    <i c="en" n="Inglês"/>
    <i c="pt" n="Português"/>
    <i c="fr" n="Francês"/>
    <i c="it" n="Italiano"/>
    <i c="de" n="Alemão"/>
    <i c="ca" n="Catalão"/>
    <i c="gl" n="Galego"/>
    <i c="eu" n="Basco"/>
    <i c="la" n="Latim"/>
    <i c="gn" n="Guarani"/>
    <i c="qu" n="Quíchua"/>
  </xsl:variable>

  <!-- DECISIONES DE ALBERTO: 4 LIBROS EN EL INICIO; EL CATÁLOGO, ENTERO Y
       DE A 8 POR PÁGINA -->
  <xsl:variable name="en_inicio" select="4" as="xs:integer"/>
  <xsl:variable name="por_pagina" select="8" as="xs:integer"/>
  <xsl:variable name="total_paginas" as="xs:integer"
      select="max((1, xs:integer(ceiling(count($libros) div $por_pagina))))"/>

  <!-- LA MATRIZ DE ESTA CLASE DE PORTAL (menu.xml, JUNTO A ESTA HOJA) -->
  <!-- EL TIPO VA EN SU VARIABLE: DENTRO DEL PREDICADO, «/» SERÍA LA RAÍZ DE
       menu.xml Y NO LA DE sitio.xml -->
  <xsl:variable name="tipo" select="string(/sitio/@tipo)"/>
  <xsl:variable name="matriz" select="doc('menu.xml')/menu/tipo[@t = $tipo]"/>

  <!-- LAS PÁGINAS ESCRITAS, AL LADO DE sitio.xml: tmp/paginas/ -->
  <xsl:variable name="dir_paginas" select="resolve-uri('paginas/', base-uri(/))"/>

  <!-- LAS PÁGINAS ESCRITAS QUE EL PORTAL USA: LAS QUE TIENEN SU ESPAÑOL -->
  <xsl:variable name="escritas" as="element()*"
      select="$matriz//item[not(@genera)][doc-available(concat($dir_paginas, @clave, '.es.xml'))]"/>

  <!-- LOS IDIOMAS, EN EL ORDEN DE LAS BANDERAS -->
  <xsl:variable name="idiomas" select="('es', 'en', 'pt')"/>

  <!-- ======================================================================
       TEXTOS DEL PORTAL. TODO LO DEL PORTAL SE TRADUCE; LOS DATOS DE LOS
       LIBROS VAN TAL CUAL (SC-80)
       ====================================================================== -->

  <xsl:variable name="textos">
    <t c="idioma"            es="Español"              en="English"             pt="Português"/>
    <t c="catalogo"          es="Catálogo"             en="Catalogue"           pt="Catálogo"/>
    <t c="compartir"         es="Compartir"            en="Share"               pt="Compartilhar"/>
    <t c="compartir-en"      es="Compartir en"         en="Share on"            pt="Compartilhar em"/>
    <t c="enviar-correo"     es="Enviar por correo"    en="Send by email"       pt="Enviar por e-mail"/>
    <t c="desde"             es="Desde"                en="Since"               pt="Desde"/>
    <t c="redes"             es="Redes"                en="Social media"        pt="Redes"/>
    <t c="ver-catalogo"      es="Ver el catálogo"      en="See the catalogue"   pt="Ver o catálogo"/>
    <t c="buscar"            es="Buscar"               en="Search"              pt="Pesquisar"/>
    <t c="anterior"          es="Página anterior"      en="Previous page"       pt="Página anterior"/>
    <t c="siguiente"         es="Página siguiente"     en="Next page"           pt="Página seguinte"/>
    <t c="sin-libros"        es="Todavía no hay libros en el catálogo." en="There are no books in the catalogue yet." pt="Ainda não há livros no catálogo."/>
    <t c="tapa-de"           es="Tapa de"              en="Cover of"            pt="Capa de"/>
    <t c="publicacion"       es="Publicación"          en="Published"           pt="Publicação"/>
    <t c="coleccion"         es="Colección"            en="Series"              pt="Coleção"/>
    <t c="isbn-impreso"      es="ISBN impreso"         en="Print ISBN"          pt="ISBN impresso"/>
    <t c="isbn-electronico"  es="ISBN electrónico"     en="E-ISBN"              pt="ISBN eletrônico"/>
    <t c="paginas"           es="Páginas"              en="Pages"               pt="Páginas"/>
    <t c="pp"                es="págs."                en="pp."                 pt="págs."/>
    <t c="licencia"          es="Licencia"             en="License"             pt="Licença"/>
    <t c="orcid-de"          es="ORCID de"             en="ORCID of"            pt="ORCID de"/>
    <t c="resumen"           es="Resumen"              en="Abstract"            pt="Resumo"/>
    <t c="leer"              es="Leer en línea"        en="Read online"         pt="Ler online"/>
    <t c="pdf"               es="Descargar PDF"        en="Download PDF"        pt="Baixar PDF"/>
    <t c="epub"              es="Descargar EPUB"       en="Download EPUB"       pt="Baixar EPUB"/>
    <t c="comprar"           es="Comprar"              en="Buy"                 pt="Comprar"/>
    <t c="idioma-libro"      es="Idioma"               en="Language"            pt="Idioma"/>
    <t c="ultimos"           es="Últimos títulos"      en="Latest titles"       pt="Últimos títulos"/>
    <t c="sugeridos"         es="Otros libros sugeridos" en="Other suggested books" pt="Outros livros sugeridos"/>
    <t c="metricas"          es="Métricas"             en="Metrics"             pt="Métricas"/>
    <t c="m-cerrar"          es="Cerrar"               en="Close"               pt="Fechar"/>
    <t c="m-simulado"        es="Datos simulados: así se verán las métricas del libro." en="Simulated data: this is how the book metrics will look." pt="Dados simulados: assim serão exibidas as métricas do livro."/>
    <t c="m-total"           es="Total"                en="Total"               pt="Total"/>
    <t c="m-fichas"          es="visitas a la ficha"   en="page views"          pt="visitas à página"/>
    <t c="m-pdf"             es="descargas del PDF"    en="PDF downloads"       pt="downloads do PDF"/>
    <t c="m-epub"            es="descargas del EPUB"   en="EPUB downloads"      pt="downloads do EPUB"/>
    <t c="m-desde"           es="Desde"                en="Since"               pt="Desde"/>
    <t c="m-visitas"         es="visitas"              en="views"               pt="visitas"/>
    <t c="m-descargas"       es="descargas (PDF + EPUB)" en="downloads (PDF + EPUB)" pt="downloads (PDF + EPUB)"/>
    <t c="m-uso"             es="Uso por mes"          en="Use per month"       pt="Uso por mês"/>
    <t c="m-citas"           es="Citas"                en="Citations"           pt="Citações"/>
    <t c="m-citas-unidad"    es="citas"                en="citations"           pt="citações"/>
    <t c="m-citas-total"     es="citas en total"       en="total citations"     pt="citações no total"/>
    <t c="m-citas-recientes" es="en los últimos 2 años" en="in the last 2 years" pt="nos últimos 2 anos"/>
    <t c="m-paises"          es="Dónde se lee"         en="Where it is read"    pt="Onde é lido"/>
    <t c="m-paises-nota"     es="Por país, sobre el total" en="By country, share of the total" pt="Por país, sobre o total"/>
    <t c="agotado"           es="Agotado"              en="Out of stock"        pt="Esgotado"/>
    <t c="descatalogado"     es="Descatalogado"        en="Out of print"        pt="Fora de catálogo"/>
    <t c="rol-editor"        es="Edición"              en="Editors"             pt="Organização"/>
    <t c="rol-compilador"    es="Compilación"          en="Compilers"           pt="Compilação"/>
    <t c="rol-coordinador"   es="Coordinación"         en="Coordinators"        pt="Coordenação"/>
    <t c="rol-prologuista_externo" es="Prólogo"        en="Foreword"            pt="Prefácio"/>
    <t c="rol-traductor"     es="Traducción"           en="Translation"         pt="Tradução"/>
    <t c="rol-ilustrador"    es="Ilustraciones"        en="Illustrations"       pt="Ilustrações"/>
    <t c="rol-director_coleccion" es="Dirección de la colección" en="Series editor" pt="Direção da coleção"/>
    <t c="de"                es="de"                   en=""                    pt="de"/>
  </xsl:variable>

  <xsl:variable name="meses" as="element()*">
    <m es="enero"      en="January"   pt="janeiro"/>
    <m es="febrero"    en="February"  pt="fevereiro"/>
    <m es="marzo"      en="March"     pt="março"/>
    <m es="abril"      en="April"     pt="abril"/>
    <m es="mayo"       en="May"       pt="maio"/>
    <m es="junio"      en="June"      pt="junho"/>
    <m es="julio"      en="July"      pt="julho"/>
    <m es="agosto"     en="August"    pt="agosto"/>
    <m es="septiembre" en="September" pt="setembro"/>
    <m es="octubre"    en="October"   pt="outubro"/>
    <m es="noviembre"  en="November"  pt="novembro"/>
    <m es="diciembre"  en="December"  pt="dezembro"/>
  </xsl:variable>

  <!-- UN TEXTO EN UN IDIOMA. UNA CLAVE QUE FALTA SALE ENTRE CORCHETES: SE VE
       EN LA PÁGINA Y NO PASA INADVERTIDA -->
  <xsl:function name="gbw:t" as="xs:string">
    <xsl:param name="clave" as="xs:string"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:variable name="fila" select="$textos/t[@c = $clave]"/>
    <xsl:sequence select="if ($fila) then string($fila/@*[local-name() = $idioma]) else concat('[', $clave, ']')"/>
  </xsl:function>

  <!-- LA FECHA DE PUBLICACIÓN: «septiembre de 2024», «September 2024» -->
  <xsl:function name="gbw:fecha" as="xs:string">
    <xsl:param name="libro" as="element()"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:variable name="mes" select="if ($libro/@mes) then string($meses[xs:integer($libro/@mes)]/@*[local-name() = $idioma]) else ''"/>
    <xsl:variable name="de" select="gbw:t('de', $idioma)"/>
    <xsl:sequence select="normalize-space(string-join(($mes, if ($mes ne '' and $de ne '') then $de else (), string($libro/@ano)), ' '))"/>
  </xsl:function>

  <!-- DE LA RUTA DE UNA PÁGINA A LA RAÍZ DEL SITIO: UN «../» POR CARPETA -->
  <xsl:function name="gbw:raiz" as="xs:string">
    <xsl:param name="ruta" as="xs:string"/>
    <xsl:sequence select="string-join(for $i in 1 to string-length(replace($ruta, '[^/]', '')) return '../', '')"/>
  </xsl:function>

  <!-- LA CARPETA DE UN IDIOMA: EL ESPAÑOL EN LA RAÍZ -->
  <xsl:function name="gbw:prefijo" as="xs:string">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:sequence select="if ($idioma eq 'es') then '' else concat($idioma, '/')"/>
  </xsl:function>

  <!-- LA RUTA DE UNA PÁGINA DEL CATÁLOGO DENTRO DE SU IDIOMA -->
  <xsl:function name="gbw:pagina" as="xs:string">
    <xsl:param name="n" as="xs:integer"/>
    <xsl:sequence select="if ($n eq 1) then 'catalogo/' else concat('catalogo/', $n, '/')"/>
  </xsl:function>

  <!-- UN ENLACE DE COMPARTIR: EL PATRÓN CON LA DIRECCIÓN Y EL TÍTULO
       CODIFICADOS (encode-for-uri) -->
  <xsl:function name="gbw:compartir" as="xs:string">
    <xsl:param name="patron" as="xs:string"/>
    <xsl:param name="url" as="xs:string"/>
    <xsl:param name="titulo" as="xs:string"/>
    <xsl:sequence select="replace(replace($patron, '\{u\}', encode-for-uri($url)), '\{t\}', encode-for-uri($titulo))"/>
  </xsl:function>

  <!-- EL NOMBRE DE UN ELEMENTO DE LA MATRIZ EN UN IDIOMA -->
  <xsl:function name="gbw:nombre" as="xs:string">
    <xsl:param name="item" as="element()"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:sequence select="string($item/@*[local-name() = $idioma])"/>
  </xsl:function>

  <!-- UN NÚMERO ENTERO CON LOS MILES DEL IDIOMA DE LA PÁGINA -->
  <xsl:function name="gbw:numero" as="xs:string">
    <xsl:param name="n" as="xs:double"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:sequence select="if ($idioma eq 'en') then format-number($n, '#,##0') else format-number($n, '#.##0', 'punto')"/>
  </xsl:function>

  <!-- EL IDIOMA BASE DE UN CÓDIGO BCP 47: «pt-BR» → «pt» -->
  <xsl:function name="gbw:base" as="xs:string">
    <xsl:param name="codigo" as="xs:string"/>
    <xsl:sequence select="lower-case(tokenize($codigo, '-')[1])"/>
  </xsl:function>

  <!-- EL NOMBRE DEL IDIOMA DEL LIBRO EN EL DE LA PÁGINA. SIN NOMBRE EN EL
       CATÁLOGO, EL CÓDIGO -->
  <xsl:function name="gbw:nombre-idioma" as="xs:string">
    <xsl:param name="libro" as="element()"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:variable name="n" select="$libro/idioma-nombre"/>
    <xsl:variable name="pt" select="$idiomas_pt[@c = gbw:base(string($libro/@idioma))]/@n"/>
    <xsl:sequence select="string((
        if ($idioma eq 'en') then $n/@en else (),
        if ($idioma eq 'pt') then $pt else (),
        $n/@es,
        $libro/@idioma)[1])"/>
  </xsl:function>

  <!-- UNA PALABRA CLAVE NORMALIZADA PARA COMPARAR: SIN TILDES, EN
       MINÚSCULAS, CON LOS ESPACIOS JUNTOS («Política » = «politica») -->
  <xsl:function name="gbw:clave" as="xs:string">
    <xsl:param name="texto" as="xs:string"/>
    <xsl:sequence select="normalize-space(lower-case(replace(normalize-unicode($texto, 'NFD'), '\p{Mn}', '')))"/>
  </xsl:function>

  <!-- TODAS LAS PALABRAS CLAVE DE UN LIBRO, EN SUS TRES IDIOMAS -->
  <xsl:function name="gbw:claves" as="xs:string*">
    <xsl:param name="libro" as="element()"/>
    <xsl:sequence select="distinct-values(for $g in $libro/palabras-clave, $k in tokenize($g, '[,;]') return gbw:clave($k))[. ne '']"/>
  </xsl:function>

  <!-- LOS 4 LIBROS SUGERIDOS (DECISIÓN DE ALBERTO), POR ESCALONES:
         1. los que comparten una persona (por su id, cualquier rol menos la
            dirección de la colección, que es de la colección)
         2. los que comparten una palabra clave
         3. los de la misma colección
         4. el resto
       CADA ESCALÓN EN EL ORDEN DEL XML (LO MÁS NUEVO PRIMERO, SC-81). EL
       ÚLTIMO ESCALÓN GARANTIZA QUE SIEMPRE SEAN 4, SALVO QUE NO HAYA MÁS
       LIBROS -->
  <xsl:function name="gbw:sugeridos" as="element()*">
    <xsl:param name="libro" as="element()"/>
    <xsl:variable name="otros" select="$libros except $libro"/>
    <xsl:variable name="personas" select="$libro/persona[@rol ne 'director_coleccion']/@id"/>
    <xsl:variable name="claves" select="gbw:claves($libro)"/>
    <xsl:variable name="e1" select="$otros[persona[@rol ne 'director_coleccion']/@id = $personas]"/>
    <xsl:variable name="e2" select="($otros except $e1)[gbw:claves(.) = $claves]"/>
    <xsl:variable name="e3" select="($otros except ($e1 | $e2))[$libro/coleccion/@id and coleccion/@id = $libro/coleccion/@id]"/>
    <xsl:variable name="e4" select="$otros except ($e1 | $e2 | $e3)"/>
    <xsl:sequence select="($e1, $e2, $e3, $e4)[position() le 4]"/>
  </xsl:function>

  <!-- UN ENLACE INTERNO, SIEMPRE AL ARCHIVO: «libro/902/index.html» Y NO
       «libro/902/». ABIERTO DESDE EL DISCO (EL VISOR DE gbWeb, file://) UNA
       CARPETA NO MUESTRA SU index.html; EN UN SERVIDOR, LAS DOS FORMAS VAN -->
  <xsl:function name="gbw:enlace" as="xs:string">
    <xsl:param name="ruta" as="xs:string"/>
    <xsl:sequence select="if ($ruta eq '' or ends-with($ruta, '/')) then concat($ruta, 'index.html') else $ruta"/>
  </xsl:function>

  <!-- ======================================================================
       ORQUESTACIÓN: TODAS LAS PÁGINAS, EN LOS TRES IDIOMAS
       ====================================================================== -->

  <xsl:template match="/sitio">
    <!-- EL INICIO EN ESPAÑOL ES LA SALIDA PRINCIPAL (-o: DEL SCRIPT) -->
    <xsl:call-template name="inicio">
      <xsl:with-param name="idioma" select="'es'"/>
    </xsl:call-template>

    <xsl:for-each select="$idiomas">
      <xsl:variable name="idioma" select="."/>
      <xsl:if test="$idioma ne 'es'">
        <xsl:result-document href="{gbw:prefijo($idioma)}index.html">
          <xsl:call-template name="inicio">
            <xsl:with-param name="idioma" select="$idioma"/>
          </xsl:call-template>
        </xsl:result-document>
      </xsl:if>
      <!-- EL CATÁLOGO, SOLO EN LOS PORTALES QUE LO TIENEN EN SU MATRIZ -->
      <xsl:if test="$matriz//item[@genera = 'catalogo']">
        <xsl:for-each select="1 to $total_paginas">
          <xsl:variable name="n" select="."/>
          <xsl:result-document href="{gbw:prefijo($idioma)}{gbw:pagina($n)}index.html">
            <xsl:call-template name="catalogo">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="n" select="$n"/>
            </xsl:call-template>
          </xsl:result-document>
        </xsl:for-each>
      </xsl:if>
      <xsl:for-each select="$escritas">
        <xsl:result-document href="{gbw:prefijo($idioma)}{@ruta}index.html">
          <xsl:call-template name="escrita">
            <xsl:with-param name="idioma" select="$idioma"/>
            <xsl:with-param name="item" select="."/>
          </xsl:call-template>
        </xsl:result-document>
      </xsl:for-each>
      <xsl:for-each select="$libros">
        <xsl:result-document href="{gbw:prefijo($idioma)}libro/{@id}/index.html">
          <xsl:apply-templates select="." mode="ficha">
            <xsl:with-param name="idioma" select="$idioma"/>
          </xsl:apply-templates>
        </xsl:result-document>
      </xsl:for-each>
    </xsl:for-each>
  </xsl:template>

  <!-- ======================================================================
       EL ESQUELETO DE TODA PÁGINA: CABECERA, CONTENIDO Y PIE
       ====================================================================== -->

  <!-- subruta: LA RUTA DE LA PÁGINA DENTRO DE SU IDIOMA («», «pagina/2/»,
       «libro/902/»). CON ELLA SE ARMAN LA RAÍZ Y LOS ENLACES A LA MISMA
       PÁGINA EN LOS OTROS IDIOMAS -->
  <!-- activa: LA CLAVE DE LA MATRIZ QUE SE MARCA EN EL MENÚ -->
  <xsl:template name="pagina">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="subruta" as="xs:string"/>
    <xsl:param name="activa" as="xs:string" select="''"/>
    <!-- LA IMAGEN DE LA VISTA PREVIA, RELATIVA A LA RAÍZ: LA TAPA EN LA
         FICHA, LA DESTACADA EN LAS DEMÁS -->
    <xsl:param name="imagen_og" as="xs:string" select="$destacada"/>
    <xsl:param name="titulo" as="xs:string"/>
    <xsl:param name="cuerpo"/>
    <xsl:variable name="raiz" select="gbw:raiz(concat(gbw:prefijo($idioma), $subruta))"/>
    <xsl:variable name="inicio" select="concat($raiz, gbw:prefijo($idioma))"/>
    <html lang="{$idioma}">
      <head>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title>
          <xsl:value-of select="$titulo"/>
          <xsl:if test="$titulo ne $nombre"> — <xsl:value-of select="$nombre"/></xsl:if>
        </title>
        <!-- LA DIRECCIÓN PÚBLICA DE LA PÁGINA: CANÓNICA Y VISTA PREVIA. SIN
             index.html: EN EL SERVIDOR, LA CARPETA LO SIRVE -->
        <xsl:if test="$url_base ne ''">
          <xsl:variable name="publica" select="concat($url_base, gbw:prefijo($idioma), $subruta)"/>
          <link rel="canonical" href="{$publica}"/>
          <meta property="og:site_name" content="{$nombre}"/>
          <meta property="og:title" content="{$titulo}"/>
          <meta property="og:url" content="{$publica}"/>
          <meta property="og:type" content="{if (starts-with($subruta, 'libro/')) then 'book' else 'website'}"/>
          <meta property="og:image" content="{$url_base}{$imagen_og}"/>
          <meta name="twitter:card" content="summary_large_image"/>
        </xsl:if>
        <!-- LAS VERSIONES EN LOS OTROS IDIOMAS: CON DIRECCIÓN COMPLETA SI SE
             CONOCE LA DEL SITIO (ES LO QUE LEEN LOS BUSCADORES); SI NO,
             RELATIVA -->
        <xsl:for-each select="$idiomas">
          <link rel="alternate" hreflang="{.}" href="{if ($url_base ne '') then concat($url_base, gbw:prefijo(.), $subruta) else gbw:enlace(concat($raiz, gbw:prefijo(.), $subruta))}"/>
        </xsl:for-each>
        <link rel="stylesheet" href="{$raiz}{$estilo}"/>
      </head>
      <body>
        <header class="cabecera">
          <div class="contenedor">
            <div class="franja">
              <a class="logo" href="{gbw:enlace($inicio)}">
                <xsl:choose>
                  <xsl:when test="$logo ne ''">
                    <img src="{$raiz}{$logo}" alt="{$nombre}"/>
                  </xsl:when>
                  <xsl:otherwise>
                    <span class="logo-texto"><xsl:value-of select="$nombre"/></span>
                  </xsl:otherwise>
                </xsl:choose>
              </a>
              <xsl:call-template name="menu">
                <xsl:with-param name="idioma" select="$idioma"/>
                <xsl:with-param name="raiz" select="$raiz"/>
                <xsl:with-param name="activa" select="$activa"/>
              </xsl:call-template>
            </div>
            <div class="herramientas">
              <div class="buscar-compartir">
                <form class="buscar" role="search" onsubmit="return false">
                  <input type="search" name="q" placeholder="{gbw:t('buscar', $idioma)}" aria-label="{gbw:t('buscar', $idioma)}"/>
                </form>
                <!-- COMPARTIR LA PÁGINA ABIERTA (DECISIÓN DE ALBERTO): CADA
                     PÁGINA LLEVA SUS ENLACES CON SU PROPIA DIRECCIÓN -->
                <xsl:if test="$url_base ne ''">
                  <xsl:variable name="publica" select="concat($url_base, gbw:prefijo($idioma), $subruta)"/>
                  <xsl:variable name="texto" select="if ($titulo ne $nombre) then concat($titulo, ' — ', $nombre) else $nombre"/>
                  <nav class="compartir" aria-label="{gbw:t('compartir', $idioma)}">
                    <xsl:for-each select="$compartir">
                      <a href="{gbw:compartir(@patron, $publica, $texto)}" target="_blank" rel="noopener"
                         aria-label="{if (@icono eq 'envelope') then gbw:t('enviar-correo', $idioma) else concat(gbw:t('compartir-en', $idioma), ' ', @nombre)}"
                         title="{if (@icono eq 'envelope') then gbw:t('enviar-correo', $idioma) else concat(gbw:t('compartir-en', $idioma), ' ', @nombre)}">
                        <xsl:call-template name="icono"><xsl:with-param name="nombre" select="string(@icono)"/></xsl:call-template>
                      </a>
                    </xsl:for-each>
                  </nav>
                </xsl:if>
              </div>
              <nav class="idiomas">
                <xsl:for-each select="$idiomas">
                  <a href="{gbw:enlace(concat($raiz, gbw:prefijo(.), $subruta))}" hreflang="{.}" lang="{.}" title="{gbw:t('idioma', .)}">
                    <xsl:if test=". eq $idioma"><xsl:attribute name="class">activo</xsl:attribute></xsl:if>
                    <img src="{$raiz}banderas/{.}.png" width="25" height="14" alt="{gbw:t('idioma', .)}"/>
                  </a>
                </xsl:for-each>
              </nav>
            </div>
          </div>
        </header>
        <main class="contenedor">
          <xsl:copy-of select="$cuerpo"/>
        </main>
        <footer class="pie">
          <div class="contenedor">
            <div class="pie-filas">
              <div class="pie-datos">
                <p class="pie-nombre"><xsl:value-of select="$nombre"/></p>
                <xsl:if test="$datos/direccion"><p><xsl:value-of select="$datos/direccion"/></p></xsl:if>
                <xsl:if test="$datos/correo"><p><a href="mailto:{$datos/correo}"><xsl:value-of select="$datos/correo"/></a></p></xsl:if>
                <!-- «DESDE 1995» Y NO «1995–2026»: EL AÑO EN CURSO CAMBIARÍA EL
                     SITIO CADA 1.º DE ENERO (SC-80, DETERMINISMO) -->
                <xsl:if test="$datos/ano-inicio"><p><xsl:value-of select="gbw:t('desde', $idioma)"/>&#160;<xsl:value-of select="$datos/ano-inicio"/></p></xsl:if>
                <xsl:if test="$datos/licencia"><p class="pie-licencia"><xsl:value-of select="$datos/licencia"/></p></xsl:if>
              </div>
              <xsl:if test="$datos/red">
                <nav class="pie-redes" aria-label="{gbw:t('redes', $idioma)}">
                  <xsl:for-each select="$datos/red">
                    <xsl:variable name="tipo" select="string(@tipo)"/>
                    <a href="{.}" aria-label="{$nombres_redes[@tipo = $tipo]/@nombre}" title="{$nombres_redes[@tipo = $tipo]/@nombre}">
                      <xsl:call-template name="icono"><xsl:with-param name="nombre" select="$tipo"/></xsl:call-template>
                    </a>
                  </xsl:for-each>
                </nav>
              </xsl:if>
            </div>
          </div>
        </footer>
      </body>
    </html>
  </xsl:template>

  <!-- ======================================================================
       EL MENÚ: LA MATRIZ, CON LAS PÁGINAS QUE EL PORTAL USA
       ====================================================================== -->

  <!-- EL DESPLEGABLE NO USA JAVASCRIPT: SE ABRE CON :hover Y :focus-within
       (estilo.css). UN GRUPO SIN PÁGINAS NO SALE -->
  <xsl:template name="menu">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:param name="activa" as="xs:string"/>
    <nav class="menu">
      <ul>
        <xsl:for-each select="$matriz/*">
          <xsl:choose>
            <xsl:when test="self::item[@genera][not(@pendiente)]">
              <li>
                <xsl:call-template name="enlace-menu">
                  <xsl:with-param name="item" select="."/>
                  <xsl:with-param name="idioma" select="$idioma"/>
                  <xsl:with-param name="raiz" select="$raiz"/>
                  <xsl:with-param name="activa" select="$activa"/>
                </xsl:call-template>
              </li>
            </xsl:when>
            <xsl:when test="self::grupo[item intersect $escritas]">
              <li class="grupo">
                <xsl:if test="item[@clave = $activa]"><xsl:attribute name="class">grupo activo</xsl:attribute></xsl:if>
                <span class="grupo-titulo" tabindex="0"><xsl:value-of select="gbw:nombre(., $idioma)"/></span>
                <ul class="submenu">
                  <xsl:for-each select="item intersect $escritas">
                    <li>
                      <xsl:call-template name="enlace-menu">
                        <xsl:with-param name="item" select="."/>
                        <xsl:with-param name="idioma" select="$idioma"/>
                        <xsl:with-param name="raiz" select="$raiz"/>
                        <xsl:with-param name="activa" select="$activa"/>
                      </xsl:call-template>
                    </li>
                  </xsl:for-each>
                </ul>
              </li>
            </xsl:when>
          </xsl:choose>
        </xsl:for-each>
      </ul>
    </nav>
  </xsl:template>

  <xsl:template name="enlace-menu">
    <xsl:param name="item" as="element()"/>
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:param name="activa" as="xs:string"/>
    <a href="{gbw:enlace(concat($raiz, gbw:prefijo($idioma), $item/@ruta))}">
      <xsl:if test="$item/@clave eq $activa"><xsl:attribute name="aria-current">page</xsl:attribute></xsl:if>
      <xsl:value-of select="gbw:nombre($item, $idioma)"/>
    </a>
  </xsl:template>

  <!-- ======================================================================
       INICIO: LA IMAGEN Y LOS 4 MÁS NUEVOS (EL «ACTUAL» DE OJS)
       ====================================================================== -->

  <xsl:template name="inicio">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:variable name="raiz" select="gbw:raiz(gbw:prefijo($idioma))"/>
    <xsl:call-template name="pagina">
      <xsl:with-param name="idioma" select="$idioma"/>
      <xsl:with-param name="subruta" select="''"/>
      <xsl:with-param name="activa" select="string($matriz/item[@genera = 'inicio']/@clave)"/>
      <xsl:with-param name="titulo" select="$nombre"/>
      <xsl:with-param name="cuerpo">
        <div class="destacada">
          <img src="{$raiz}{$destacada}" alt="">
            <xsl:if test="$destacada_ancho ne ''">
              <xsl:attribute name="width" select="$destacada_ancho"/>
              <xsl:attribute name="height" select="$destacada_alto"/>
            </xsl:if>
          </img>
        </div>
        <xsl:if test="$libros">
          <h2 class="seccion"><xsl:value-of select="gbw:t('ultimos', $idioma)"/></h2>
          <ol class="libros">
            <xsl:apply-templates select="$libros[position() le $en_inicio]" mode="fila">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="raiz" select="$raiz"/>
              <xsl:with-param name="nivel" select="'h3'"/>
            </xsl:apply-templates>
          </ol>
        </xsl:if>
        <!-- SIN FLECHAS: EL RESTO ESTÁ EN EL CATÁLOGO -->
        <xsl:if test="$matriz//item[@genera = 'catalogo']">
          <p class="ver-catalogo">
            <a href="{gbw:enlace(concat($raiz, gbw:prefijo($idioma), gbw:pagina(1)))}"><xsl:value-of select="gbw:t('ver-catalogo', $idioma)"/> →</a>
          </p>
        </xsl:if>
      </xsl:with-param>
    </xsl:call-template>
  </xsl:template>

  <!-- ======================================================================
       CATÁLOGO: TODOS LOS LIBROS, DE A 8 (EL «ARCHIVOS» DE OJS)
       ====================================================================== -->

  <xsl:template name="catalogo">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="n" as="xs:integer"/>
    <xsl:variable name="subruta" select="gbw:pagina($n)"/>
    <xsl:variable name="raiz" select="gbw:raiz(concat(gbw:prefijo($idioma), $subruta))"/>
    <xsl:variable name="desde" as="xs:integer" select="($n - 1) * $por_pagina + 1"/>
    <xsl:variable name="hasta" as="xs:integer" select="$n * $por_pagina"/>
    <xsl:call-template name="pagina">
      <xsl:with-param name="idioma" select="$idioma"/>
      <xsl:with-param name="subruta" select="$subruta"/>
      <xsl:with-param name="activa" select="'catalogo'"/>
      <xsl:with-param name="titulo" select="if ($n eq 1) then gbw:t('catalogo', $idioma) else concat(gbw:t('catalogo', $idioma), ' · ', $n)"/>
      <xsl:with-param name="cuerpo">
        <h1 class="titulo-pagina"><xsl:value-of select="gbw:t('catalogo', $idioma)"/></h1>
        <xsl:choose>
          <xsl:when test="$libros">
            <ol class="libros" start="{$desde}">
              <xsl:apply-templates select="$libros[position() ge $desde and position() le $hasta]" mode="fila">
                <xsl:with-param name="idioma" select="$idioma"/>
                <xsl:with-param name="raiz" select="$raiz"/>
              </xsl:apply-templates>
            </ol>
            <xsl:call-template name="flechas">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="n" select="$n"/>
              <xsl:with-param name="raiz" select="$raiz"/>
            </xsl:call-template>
          </xsl:when>
          <xsl:otherwise>
            <p><xsl:value-of select="gbw:t('sin-libros', $idioma)"/></p>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:with-param>
    </xsl:call-template>
  </xsl:template>

  <!-- ======================================================================
       PÁGINA ESCRITA: EL MARKDOWN DEL PORTAL, YA EN HTML
       ====================================================================== -->

  <!-- EL TÍTULO ES EL NOMBRE DE LA MATRIZ: EL MISMO DEL MENÚ. SIN LA
       TRADUCCIÓN, VA EL ESPAÑOL, MARCADO COMO TAL -->
  <xsl:template name="escrita">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="item" as="element()"/>
    <xsl:variable name="propia" select="concat($dir_paginas, $item/@clave, '.', $idioma, '.xml')"/>
    <xsl:variable name="traducida" select="doc-available($propia)"/>
    <xsl:variable name="fuente" select="if ($traducida) then doc($propia) else doc(concat($dir_paginas, $item/@clave, '.es.xml'))"/>
    <xsl:call-template name="pagina">
      <xsl:with-param name="idioma" select="$idioma"/>
      <xsl:with-param name="subruta" select="string($item/@ruta)"/>
      <xsl:with-param name="activa" select="string($item/@clave)"/>
      <xsl:with-param name="titulo" select="gbw:nombre($item, $idioma)"/>
      <xsl:with-param name="cuerpo">
        <article class="escrita">
          <h1 class="titulo-pagina"><xsl:value-of select="gbw:nombre($item, $idioma)"/></h1>
          <div class="contenido">
            <xsl:if test="not($traducida) and $idioma ne 'es'"><xsl:attribute name="lang">es</xsl:attribute></xsl:if>
            <xsl:copy-of select="$fuente/*/node()"/>
          </div>
        </article>
      </xsl:with-param>
    </xsl:call-template>
  </xsl:template>

  <!-- LAS DOS FLECHAS. LA QUE NO TIENE ADÓNDE IR QUEDA APAGADA, SIN ENLACE -->
  <xsl:template name="flechas">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="n" as="xs:integer"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:if test="$total_paginas gt 1">
      <nav class="paginas">
        <xsl:choose>
          <xsl:when test="$n gt 1">
            <xsl:variable name="destino" select="concat($raiz, gbw:prefijo($idioma), gbw:pagina($n - 1))"/>
            <a href="{gbw:enlace($destino)}" rel="prev" aria-label="{gbw:t('anterior', $idioma)}">←</a>
          </xsl:when>
          <xsl:otherwise><span class="apagada" aria-hidden="true">←</span></xsl:otherwise>
        </xsl:choose>
        <span class="numero"><xsl:value-of select="$n"/> / <xsl:value-of select="$total_paginas"/></span>
        <xsl:choose>
          <xsl:when test="$n lt $total_paginas">
            <a href="{gbw:enlace(concat($raiz, gbw:prefijo($idioma), gbw:pagina($n + 1)))}" rel="next" aria-label="{gbw:t('siguiente', $idioma)}">→</a>
          </xsl:when>
          <xsl:otherwise><span class="apagada" aria-hidden="true">→</span></xsl:otherwise>
        </xsl:choose>
      </nav>
    </xsl:if>
  </xsl:template>

  <!-- UNA FILA: LA TAPITA Y, A SU DERECHA, LOS DATOS. nivel: EL DEL TÍTULO,
       UNO DEBAJO DEL ENCABEZADO QUE TENGA ARRIBA LA LISTA (h2 EN EL
       CATÁLOGO, BAJO SU h1; h3 EN EL INICIO Y EN LOS SUGERIDOS) -->
  <xsl:template match="libro" mode="fila">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:param name="nivel" as="xs:string" select="'h2'"/>
    <xsl:variable name="ficha" select="gbw:enlace(concat($raiz, gbw:prefijo($idioma), 'libro/', @id, '/'))"/>
    <li class="fila">
      <a class="fila-tapa" href="{$ficha}" tabindex="-1" aria-hidden="true">
        <xsl:call-template name="tapa">
          <xsl:with-param name="idioma" select="$idioma"/>
          <xsl:with-param name="raiz" select="$raiz"/>
        </xsl:call-template>
      </a>
      <div class="fila-datos">
        <xsl:element name="{$nivel}">
          <xsl:attribute name="class">fila-titulo</xsl:attribute>
          <a href="{$ficha}"><xsl:call-template name="lang"><xsl:with-param name="idioma" select="$idioma"/></xsl:call-template><xsl:value-of select="titulo"/></a>
        </xsl:element>
        <xsl:if test="subtitulo">
          <p class="subtitulo"><xsl:call-template name="lang"><xsl:with-param name="idioma" select="$idioma"/></xsl:call-template><xsl:value-of select="subtitulo"/></p>
        </xsl:if>
        <xsl:call-template name="personas">
          <xsl:with-param name="idioma" select="$idioma"/>
          <xsl:with-param name="enlaces" select="false()"/>
        </xsl:call-template>
        <p class="datos">
          <xsl:if test="@ano"><span><xsl:value-of select="@ano"/></span></xsl:if>
          <xsl:if test="coleccion"><span><xsl:value-of select="coleccion"/></span></xsl:if>
          <xsl:if test="isbn-impreso"><span>ISBN <xsl:value-of select="isbn-impreso"/></span></xsl:if>
          <xsl:if test="not(isbn-impreso) and isbn-electronico"><span>ISBN <xsl:value-of select="isbn-electronico"/></span></xsl:if>
          <xsl:if test="paginas"><span><xsl:value-of select="paginas"/>&#160;<xsl:value-of select="gbw:t('pp', $idioma)"/></span></xsl:if>
        </p>
        <xsl:call-template name="marca">
          <xsl:with-param name="idioma" select="$idioma"/>
        </xsl:call-template>
      </div>
    </li>
  </xsl:template>

  <!-- ======================================================================
       FICHA: DOS COLUMNAS, LA TAPA Y LOS DATOS
       ====================================================================== -->

  <xsl:template match="libro" mode="ficha">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:variable name="subruta" select="concat('libro/', @id, '/')"/>
    <xsl:variable name="raiz" select="gbw:raiz(concat(gbw:prefijo($idioma), $subruta))"/>
    <xsl:variable name="libro" select="."/>
    <xsl:call-template name="pagina">
      <xsl:with-param name="idioma" select="$idioma"/>
      <xsl:with-param name="subruta" select="$subruta"/>
      <xsl:with-param name="activa" select="'catalogo'"/>
      <xsl:with-param name="titulo" select="string(titulo)"/>
      <xsl:with-param name="imagen_og" select="if (tapa) then concat('tapas/', tapa/@archivo) else $destacada"/>
      <xsl:with-param name="cuerpo">
        <article class="ficha">
          <div class="ficha-tapa">
            <xsl:call-template name="tapa">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="raiz" select="$raiz"/>
            </xsl:call-template>
          </div>
          <div class="ficha-datos">
            <h1><xsl:call-template name="lang"><xsl:with-param name="idioma" select="$idioma"/></xsl:call-template><xsl:value-of select="titulo"/></h1>
            <xsl:if test="subtitulo">
              <p class="subtitulo"><xsl:call-template name="lang"><xsl:with-param name="idioma" select="$idioma"/></xsl:call-template><xsl:value-of select="subtitulo"/></p>
            </xsl:if>
            <xsl:call-template name="personas">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="enlaces" select="true()"/>
              <xsl:with-param name="raiz" select="$raiz"/>
            </xsl:call-template>
            <xsl:call-template name="marca">
              <xsl:with-param name="idioma" select="$idioma"/>
            </xsl:call-template>
            <!-- EL RESUMEN, COMO EN EL HTML DE gbpublisher: LA ETIQUETA CON EL
                 TRIÁNGULO. A DIFERENCIA DE ALLÁ, CERRADO MUESTRA TRES LÍNEAS:
                 QUIEN VE EL CORTE DECIDE SI LO ABRE (DECISIÓN DE ALBERTO).
                 UNA CASILLA Y NO <details>: CERRADO, <details> NO MUESTRA
                 NADA DE SU CONTENIDO. SIN JAVASCRIPT -->
            <!-- EL RESUMEN EN EL IDIOMA DE LA PÁGINA, SI LO HAY; SI NO, EL DEL
                 IDIOMA PRINCIPAL, QUE m_Sitio ESCRIBE PRIMERO -->
            <xsl:variable name="resumen" select="(resumen[@idioma and gbw:base(@idioma) eq $idioma], resumen)[1]"/>
            <xsl:if test="$resumen">
              <section class="resumen">
                <input type="checkbox" id="resumen-abierto" class="resumen-casilla"/>
                <label for="resumen-abierto" class="resumen-etiqueta"><xsl:value-of select="gbw:t('resumen', $idioma)"/></label>
                <p class="resumen-texto">
                  <xsl:if test="$resumen/@idioma and gbw:base($resumen/@idioma) ne $idioma">
                    <xsl:attribute name="lang" select="$resumen/@idioma"/>
                  </xsl:if>
                  <xsl:value-of select="$resumen"/>
                </p>
              </section>
            </xsl:if>
            <xsl:call-template name="metricas">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="raiz" select="$raiz"/>
            </xsl:call-template>
            <dl class="metadatos">
              <xsl:if test="@ano">
                <dt><xsl:value-of select="gbw:t('publicacion', $idioma)"/></dt>
                <dd><xsl:value-of select="gbw:fecha($libro, $idioma)"/></dd>
              </xsl:if>
              <xsl:if test="coleccion">
                <dt><xsl:value-of select="gbw:t('coleccion', $idioma)"/></dt>
                <dd>
                  <xsl:value-of select="coleccion"/>
                  <xsl:if test="coleccion/@numero">, <xsl:value-of select="coleccion/@numero"/></xsl:if>
                </dd>
              </xsl:if>
              <xsl:if test="isbn-impreso">
                <dt><xsl:value-of select="gbw:t('isbn-impreso', $idioma)"/></dt>
                <dd><xsl:value-of select="isbn-impreso"/></dd>
              </xsl:if>
              <xsl:if test="isbn-electronico">
                <dt><xsl:value-of select="gbw:t('isbn-electronico', $idioma)"/></dt>
                <dd><xsl:value-of select="isbn-electronico"/></dd>
              </xsl:if>
              <xsl:if test="paginas">
                <dt><xsl:value-of select="gbw:t('paginas', $idioma)"/></dt>
                <dd><xsl:value-of select="paginas"/></dd>
              </xsl:if>
              <xsl:if test="@idioma">
                <dt><xsl:value-of select="gbw:t('idioma-libro', $idioma)"/></dt>
                <dd><xsl:value-of select="gbw:nombre-idioma($libro, $idioma)"/></dd>
              </xsl:if>
              <!-- LAS PALABRAS CLAVE NO SE MUESTRAN (DECISIÓN DE ALBERTO): SIGUEN
                   EN sitio.xml PARA LOS SUGERIDOS Y EL BUSCADOR -->
              <xsl:if test="licencia">
                <dt><xsl:value-of select="gbw:t('licencia', $idioma)"/></dt>
                <dd>
                  <xsl:choose>
                    <xsl:when test="licencia/@url"><a href="{licencia/@url}" rel="license"><xsl:value-of select="licencia"/></a></xsl:when>
                    <xsl:otherwise><xsl:value-of select="licencia"/></xsl:otherwise>
                  </xsl:choose>
                </dd>
              </xsl:if>
            </dl>
            <xsl:call-template name="botones">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="raiz" select="$raiz"/>
            </xsl:call-template>
          </div>
        </article>
        <!-- LOS SUGERIDOS: UN FILETE Y 4 LIBROS COMO EN EL INICIO, A TODO EL
             ANCHO (DECISIÓN DE ALBERTO) -->
        <xsl:variable name="sugeridos" select="gbw:sugeridos($libro)"/>
        <xsl:if test="$sugeridos">
          <section class="sugeridos">
            <h2 class="seccion"><xsl:value-of select="gbw:t('sugeridos', $idioma)"/></h2>
            <ol class="libros">
              <xsl:apply-templates select="$sugeridos" mode="fila">
                <xsl:with-param name="idioma" select="$idioma"/>
                <xsl:with-param name="raiz" select="$raiz"/>
                <xsl:with-param name="nivel" select="'h3'"/>
              </xsl:apply-templates>
            </ol>
          </section>
        </xsl:if>
      </xsl:with-param>
    </xsl:call-template>
  </xsl:template>


  <!-- ======================================================================
       LA VENTANA «MÉTRICAS» (DEBAJO DEL RESUMEN). LOS DATOS LOS TRAE gbWeb
       AL CONSTRUIR (m_Metricas, <metricas> EN sitio.xml) Y ACÁ SOLO SE
       DIBUJAN: EL LECTOR NO CONSULTA A NADIE (DECISIÓN DE ALBERTO, FORMA 2).
       SIN JAVASCRIPT, COMO EL RESUMEN: UNA CASILLA OCULTA ABRE LA VENTANA;
       EL FONDO Y LA X SON ETIQUETAS DE LA MISMA CASILLA Y LA CIERRAN. ASÍ
       FUNCIONA TAMBIÉN EN EL VISOR DE gbWeb.
       EL GRÁFICO ES UN SVG CALCULADO ACÁ: DETERMINISTA, CON LOS VALORES EN
       <title> PARA VERLOS AL PASAR EL MOUSE
       ====================================================================== -->
  <xsl:template name="metricas">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:variable name="m" select="metricas"/>
    <xsl:if test="$m/mes">
      <xsl:variable name="meses_m" select="$m/mes"/>
      <xsl:variable name="fichas" select="sum($meses_m/@visitas)"/>
      <xsl:variable name="pdf" select="sum($meses_m/@pdf)"/>
      <xsl:variable name="epub" select="sum($meses_m/@epub)"/>
      <xsl:variable name="descargas" select="$pdf + $epub gt 0"/>
      <div class="metricas-linea">
        <input type="checkbox" id="metricas-abierta" class="metricas-casilla"/>
        <label for="metricas-abierta" class="boton boton-metricas">
          <xsl:call-template name="icono"><xsl:with-param name="nombre" select="'chart-simple'"/></xsl:call-template>
          <span><xsl:value-of select="gbw:t('metricas', $idioma)"/></span>
        </label>
        <div class="metricas-fondo">
          <label for="metricas-abierta" class="metricas-afuera" aria-hidden="true"></label>
          <section class="metricas" role="dialog" aria-modal="true" aria-labelledby="metricas-titulo">
            <header class="metricas-cabeza">
              <h2 id="metricas-titulo"><xsl:value-of select="gbw:t('metricas', $idioma)"/></h2>
              <label for="metricas-abierta" class="metricas-cerrar" title="{gbw:t('m-cerrar', $idioma)}">
                <xsl:call-template name="icono"><xsl:with-param name="nombre" select="'xmark'"/></xsl:call-template>
              </label>
            </header>
            <xsl:if test="$m/@simulado = 'si'">
              <p class="metricas-simulado"><xsl:value-of select="gbw:t('m-simulado', $idioma)"/></p>
            </xsl:if>

            <!-- LOS TOTALES: UNA FILA POR LO QUE EL LIBRO OFRECE -->
            <table class="metricas-totales">
              <tr>
                <th rowspan="{1 + (if ($pdf gt 0) then 1 else 0) + (if ($epub gt 0) then 1 else 0)}">
                  <xsl:value-of select="gbw:t('m-total', $idioma)"/><br/>
                  <strong><xsl:value-of select="gbw:numero($fichas + $pdf + $epub, $idioma)"/></strong>
                </th>
                <td><strong><xsl:value-of select="gbw:numero($fichas, $idioma)"/></strong>&#160;<xsl:value-of select="gbw:t('m-fichas', $idioma)"/></td>
              </tr>
              <xsl:if test="$pdf gt 0">
                <tr><td><strong><xsl:value-of select="gbw:numero($pdf, $idioma)"/></strong>&#160;<xsl:value-of select="gbw:t('m-pdf', $idioma)"/></td></tr>
              </xsl:if>
              <xsl:if test="$epub gt 0">
                <tr><td><strong><xsl:value-of select="gbw:numero($epub, $idioma)"/></strong>&#160;<xsl:value-of select="gbw:t('m-epub', $idioma)"/></td></tr>
              </xsl:if>
            </table>
            <p class="metricas-desde">
              <xsl:value-of select="gbw:t('m-desde', $idioma)"/>
              <xsl:text> </xsl:text>
              <xsl:value-of select="$meses[xs:integer($meses_m[1]/@mes)]/@*[name() = $idioma]"/>
              <xsl:text> </xsl:text>
              <xsl:value-of select="if ($idioma eq 'en') then '' else concat(gbw:t('de', $idioma), ' ')"/>
              <xsl:value-of select="$meses_m[1]/@ano"/>
            </p>

            <xsl:call-template name="metricas-grafico">
              <xsl:with-param name="idioma" select="$idioma"/>
              <xsl:with-param name="meses_m" select="$meses_m"/>
              <xsl:with-param name="descargas" select="$descargas"/>
            </xsl:call-template>

            <div class="metricas-pie">
              <xsl:if test="$m/citas">
                <section class="metricas-citas">
                  <h3><xsl:value-of select="gbw:t('m-citas', $idioma)"/></h3>
                  <div class="metricas-citas-cuerpo">
                    <div class="metricas-insignia">
                      <strong><xsl:value-of select="gbw:numero($m/citas/@total, $idioma)"/></strong>
                      <span><xsl:value-of select="gbw:t('m-citas-unidad', $idioma)"/></span>
                    </div>
                    <table>
                      <tr><td><strong><xsl:value-of select="gbw:numero($m/citas/@total, $idioma)"/></strong></td><td><xsl:value-of select="gbw:t('m-citas-total', $idioma)"/></td></tr>
                      <tr><td><strong><xsl:value-of select="gbw:numero($m/citas/@recientes, $idioma)"/></strong></td><td><xsl:value-of select="gbw:t('m-citas-recientes', $idioma)"/></td></tr>
                    </table>
                  </div>
                </section>
              </xsl:if>
              <xsl:if test="$m/pais">
                <section class="metricas-paises">
                  <h3><xsl:value-of select="gbw:t('m-paises', $idioma)"/></h3>
                  <xsl:variable name="mayor" select="max($m/pais[@codigo ne 'otros']/xs:integer(@pc))"/>
                  <ol>
                    <!-- DE MAYOR A MENOR, CON DESEMPATE POR EL CÓDIGO; «otros», AL FINAL -->
                    <xsl:for-each select="$m/pais[@codigo ne 'otros']">
                      <xsl:sort select="xs:integer(@pc)" order="descending"/>
                      <xsl:sort select="@codigo"/>
                      <xsl:call-template name="metricas-pais">
                        <xsl:with-param name="idioma" select="$idioma"/>
                        <xsl:with-param name="mayor" select="$mayor"/>
                      </xsl:call-template>
                    </xsl:for-each>
                    <xsl:for-each select="$m/pais[@codigo eq 'otros']">
                      <xsl:call-template name="metricas-pais">
                        <xsl:with-param name="idioma" select="$idioma"/>
                        <xsl:with-param name="mayor" select="$mayor"/>
                      </xsl:call-template>
                    </xsl:for-each>
                  </ol>
                  <p class="metricas-nota"><xsl:value-of select="gbw:t('m-paises-nota', $idioma)"/></p>
                </section>
              </xsl:if>
            </div>
          </section>
        </div>
      </div>
    </xsl:if>
  </xsl:template>

  <!-- UNA FILA DE PAÍS: EL NOMBRE, LA BARRA (PROPORCIONAL AL MAYOR) Y EL % -->
  <xsl:template name="metricas-pais">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="mayor" as="xs:integer"/>
    <xsl:variable name="codigo" select="string(@codigo)"/>
    <li>
      <span><xsl:value-of select="($paises[@c = $codigo]/@*[name() = $idioma], $codigo)[1]"/></span>
      <span class="barra"><i style="width: {format-number(min((100, xs:integer(@pc) * 100 div $mayor)), '0.#')}%"></i></span>
      <span class="pc"><xsl:value-of select="@pc"/>&#160;%</span>
    </li>
  </xsl:template>

  <!-- EL GRÁFICO DE USO POR MES. LAS MEDIDAS SON LAS DEL viewBox: EL CSS LO
       ESTIRA AL ANCHO DE LA VENTANA -->
  <xsl:template name="metricas-grafico">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="meses_m" as="element()*"/>
    <xsl:param name="descargas" as="xs:boolean"/>
    <xsl:variable name="n" select="count($meses_m)"/>
    <xsl:variable name="ancho" select="650"/>
    <xsl:variable name="alto" select="216"/>
    <xsl:variable name="izq" select="40"/>
    <xsl:variable name="arr" select="10"/>
    <xsl:variable name="mayor" select="max(($meses_m/xs:integer(@visitas), for $e in $meses_m return xs:integer($e/@pdf) + xs:integer($e/@epub), 1))"/>
    <xsl:variable name="techo" select="xs:integer(ceiling($mayor div 25) * 25)"/>
    <!-- LAS COORDENADAS, CON UN DECIMAL: EL MISMO TEXTO EN CADA CONSTRUCCIÓN -->
    <xsl:variable name="xs_" select="for $i in 1 to $n return format-number($izq + $ancho * ($i - 1) div max(($n - 1, 1)), '0.0')"/>
    <xsl:variable name="vis" select="$meses_m/xs:integer(@visitas)"/>
    <xsl:variable name="des" select="for $e in $meses_m return xs:integer($e/@pdf) + xs:integer($e/@epub)"/>
    <xsl:variable name="y_vis" select="for $v in $vis return format-number($arr + $alto * (1 - $v div $techo), '0.0')"/>
    <xsl:variable name="y_des" select="for $v in $des return format-number($arr + $alto * (1 - $v div $techo), '0.0')"/>
    <xsl:variable name="base" select="format-number($arr + $alto, '0.0')"/>
    <div class="metricas-grafico">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 260" role="img" aria-label="{gbw:t('m-uso', $idioma)}">
        <!-- LA GRILLA Y LOS VALORES -->
        <xsl:for-each select="0 to 5">
          <xsl:variable name="v" select="$techo * . div 5"/>
          <xsl:variable name="y" select="format-number($arr + $alto * (1 - $v div $techo), '0.0')"/>
          <line x1="{$izq}" x2="690" y1="{$y}" y2="{$y}" class="{if (. eq 0) then 'eje' else 'grilla'}"/>
          <text x="{$izq - 6}" y="{format-number(number($y) + 4, '0.0')}" text-anchor="end"><xsl:value-of select="round($v)"/></text>
        </xsl:for-each>
        <!-- LOS MESES: LOS QUE ABREN UN TRIMESTRE Y EL PRIMERO; EL AÑO, EN
             ENERO Y EN EL PRIMERO -->
        <xsl:for-each select="$meses_m">
          <xsl:variable name="i" select="position()"/>
          <xsl:if test="@mes = ('1', '4', '7', '10') or $i eq 1">
            <text x="{$xs_[$i]}" y="242" text-anchor="middle"><xsl:value-of select="substring($meses[xs:integer(current()/@mes)]/@*[name() = $idioma], 1, 3)"/></text>
          </xsl:if>
          <xsl:if test="@mes = '1' or $i eq 1">
            <text x="{$xs_[$i]}" y="255" text-anchor="middle"><xsl:value-of select="@ano"/></text>
          </xsl:if>
        </xsl:for-each>
        <!-- LAS VISITAS, CON EL ÁREA DEBAJO -->
        <polygon class="area-visitas" points="{string-join((concat($xs_[1], ',', $base), for $i in 1 to $n return concat($xs_[$i], ',', $y_vis[$i]), concat($xs_[$n], ',', $base)), ' ')}"/>
        <polyline class="linea-visitas" points="{string-join(for $i in 1 to $n return concat($xs_[$i], ',', $y_vis[$i]), ' ')}"/>
        <xsl:if test="$descargas">
          <polyline class="linea-descargas" points="{string-join(for $i in 1 to $n return concat($xs_[$i], ',', $y_des[$i]), ' ')}"/>
        </xsl:if>
        <!-- LOS PUNTOS, CON EL VALOR EN <title> -->
        <xsl:for-each select="$meses_m">
          <xsl:variable name="i" select="position()"/>
          <xsl:variable name="mes" select="concat($meses[xs:integer(current()/@mes)]/@*[name() = $idioma], ' ', @ano)"/>
          <circle class="punto-visitas" cx="{$xs_[$i]}" cy="{$y_vis[$i]}" r="3.5"><title><xsl:value-of select="$mes"/>: <xsl:value-of select="$vis[$i]"/>&#160;<xsl:value-of select="gbw:t('m-visitas', $idioma)"/></title></circle>
          <xsl:if test="$descargas">
            <circle class="punto-descargas" cx="{$xs_[$i]}" cy="{$y_des[$i]}" r="3"><title><xsl:value-of select="$mes"/>: <xsl:value-of select="$des[$i]"/>&#160;<xsl:value-of select="gbw:t('m-descargas', $idioma)"/></title></circle>
          </xsl:if>
        </xsl:for-each>
      </svg>
    </div>
    <p class="metricas-leyenda">
      <span class="serie serie-visitas"></span><xsl:value-of select="gbw:t('m-visitas', $idioma)"/>
      <xsl:if test="$descargas">
        <span class="serie serie-descargas"></span><xsl:value-of select="gbw:t('m-descargas', $idioma)"/>
      </xsl:if>
    </p>
  </xsl:template>

  <!-- ======================================================================
       PIEZAS COMPARTIDAS
       ====================================================================== -->

  <!-- UN ÍCONO, DENTRO DE LA PÁGINA: CON EL COLOR DEL TEXTO (currentColor),
       DECORATIVO PARA LOS LECTORES DE PANTALLA (EL NOMBRE LO DA EL ENLACE).
       SE COPIA CON SU COMENTARIO, QUE LLEVA LA ATRIBUCIÓN -->
  <xsl:template name="icono">
    <xsl:param name="nombre" as="xs:string"/>
    <xsl:for-each select="doc(concat($dir_iconos, $nombre, '.svg'))/*">
      <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:attribute name="class">icono</xsl:attribute>
        <xsl:attribute name="aria-hidden">true</xsl:attribute>
        <xsl:attribute name="focusable">false</xsl:attribute>
        <xsl:copy-of select="node()"/>
      </xsl:copy>
    </xsl:for-each>
  </xsl:template>

  <!-- EL IDIOMA DE LA OBRA CUANDO NO ES EL DE LA PÁGINA (SC-80, IDIOMAS). EL
       CONTEXTO ES EL <libro> -->
  <xsl:template name="lang">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:if test="@idioma and @idioma ne $idioma">
      <xsl:attribute name="lang" select="@idioma"/>
    </xsl:if>
  </xsl:template>

  <!-- LA TAPA, O UNA CAJA VACÍA CON LA PROPORCIÓN DE UN LIBRO -->
  <xsl:template name="tapa">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:choose>
      <xsl:when test="tapa">
        <img src="{$raiz}tapas/{tapa/@archivo}" width="{tapa/@ancho}" height="{tapa/@alto}"
             alt="{gbw:t('tapa-de', $idioma)} {titulo}" loading="lazy"/>
      </xsl:when>
      <xsl:otherwise>
        <div class="tapa-vacia"></div>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- LAS PERSONAS, AGRUPADAS POR ROL EN EL ORDEN DE AUTORÍA. LA AUTORÍA VA
       SIN RÓTULO. LA DIRECCIÓN DE LA COLECCIÓN NO VA: ES DE LA COLECCIÓN.
       enlaces: EN LA FICHA, QUIEN TIENE ORCID LLEVA EL ÍCONO, QUE ES EL
       ENLACE; EL NOMBRE NO SE ENLAZA (DECISIÓN DE ALBERTO). EN LA FILA, SIN
       ÍCONO: EL ENLACE ES EL TÍTULO -->
  <xsl:template name="personas">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="enlaces" as="xs:boolean"/>
    <xsl:param name="raiz" as="xs:string" select="''"/>
    <xsl:for-each-group select="persona[@rol ne 'director_coleccion']" group-by="@rol">
      <p class="personas">
        <xsl:if test="current-grouping-key() ne 'autor'">
          <span class="rol"><xsl:value-of select="gbw:t(concat('rol-', current-grouping-key()), $idioma)"/>: </span>
        </xsl:if>
        <xsl:for-each select="current-group()">
          <xsl:if test="position() gt 1">, </xsl:if>
          <xsl:value-of select="."/>
          <xsl:if test="$enlaces and @orcid">
            <xsl:text>&#160;</xsl:text>
            <a class="orcid" href="https://orcid.org/{@orcid}" title="ORCID {@orcid}">
              <img src="{$raiz}iconos/orcid.png" width="16" height="16" alt="{gbw:t('orcid-de', $idioma)} {.}"/>
            </a>
          </xsl:if>
        </xsl:for-each>
      </p>
    </xsl:for-each-group>
  </xsl:template>

  <xsl:template name="marca">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:if test="@estado = ('agotado', 'descatalogado')">
      <span class="marca"><xsl:value-of select="gbw:t(@estado, $idioma)"/></span>
    </xsl:if>
  </xsl:template>

  <!-- LOS BOTONES SALEN DE LOS DATOS (SC-80, LO QUE MUESTRA):
         leer en línea     si hay url-libro
         descargas         acceso abierto o mixto, si hay la URL
         tiendas           una fila debajo, un botón por punto de venta
                           (libro_venta): acceso de venta o mixto, solo
                           publicado (agotado y descatalogado no se venden) -->
  <xsl:template name="botones">
    <xsl:param name="idioma" as="xs:string"/>
    <xsl:param name="raiz" as="xs:string"/>
    <xsl:variable name="libro" select="."/>
    <xsl:variable name="descarga" select="@acceso = ('abierto', 'mixto')"/>
    <xsl:variable name="compra" select="@acceso = ('venta', 'mixto') and @estado = 'publicado'"/>
    <xsl:if test="url-libro or ($descarga and (url-pdf or url-epub))">
      <p class="botones">
        <xsl:if test="$descarga and url-pdf">
          <a class="boton" href="{url-pdf}"><xsl:value-of select="gbw:t('pdf', $idioma)"/></a>
        </xsl:if>
        <xsl:if test="$descarga and url-epub">
          <a class="boton" href="{url-epub}"><xsl:value-of select="gbw:t('epub', $idioma)"/></a>
        </xsl:if>
        <xsl:if test="url-libro">
          <a class="boton" href="{url-libro}"><xsl:value-of select="gbw:t('leer', $idioma)"/></a>
        </xsl:if>
      </p>
    </xsl:if>
    <xsl:if test="$compra and venta">
      <p class="botones tiendas">
        <xsl:for-each select="$tiendas[@tienda = $libro/venta/@tienda]">
          <xsl:variable name="tienda" select="."/>
          <a class="boton boton-tienda" href="{$libro/venta[@tienda = $tienda/@tienda][1]}" title="{gbw:t('comprar', $idioma)}: {@nombre}">
            <xsl:choose>
              <xsl:when test="@svg">
                <xsl:call-template name="icono">
                  <xsl:with-param name="nombre" select="string(@svg)"/>
                </xsl:call-template>
              </xsl:when>
              <xsl:otherwise>
                <img class="icono" src="{$raiz}iconos/{@png}" width="18" height="18" alt=""/>
              </xsl:otherwise>
            </xsl:choose>
            <span><xsl:value-of select="@nombre"/></span>
          </a>
        </xsl:for-each>
      </p>
    </xsl:if>
  </xsl:template>

</xsl:stylesheet>
