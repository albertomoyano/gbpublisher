# Entrega 3b — separador del glosario

« – » entre el término y la definición: semirraya entre espacios, el primero duro, para que la raya no quede al comienzo de una línea.

Sin parches de Gambas. Reemplazar los archivos del zip:

- `.hidden/latex/preambulo-contrato.tex` — `\gbGlosarioSep` pasa de `\enskip` a `\nobreakspace–\space`. El carácter va literal (no `--`), así no depende de las ligaduras de la fuente. El contrato no cambia de versión: la macro ya existía, cambia solo su definición.
- `.hidden/xslt/docbook-to-html.xsl` y `docbook-to-epub.xsl` — `&#160;– ` después del término.
- `.hidden/xslt/docbook-to-latex.xsl` — solo el comentario.
- `.hidden/assets/css/gbpublisher.css` y `gbpublisher-epub-libro.css` — solo el comentario.

Las remisiones puras siguen como en los índices: «Traveling, véase Travelling».
