<?xml version="1.0" encoding="UTF-8"?>
<!--
  ============================================================
  HOJA DE ESTILO : docbook-to-latex.xsl
  VERSIÓN XSLT   : 3.0 (Saxon-HE)
  PROPÓSITO      : TRANSFORMA UN CANÓNICO DocBook 5.2 DE LIBRO
                   EN UN FRAGMENTO LATEX. LA SALIDA NO ES UN
                   DOCUMENTO COMPLETO: SIN PREÁMBULO, SIN
                   \begin{document}, SIN \input DE NADA.
                   ES LO QUE \include NECESITA.
  MOTOR          : LuaLaTeX
  ENTRADA        : {proyecto}/docbook/c-{sec}-{NN}-{nombre}.xml
                   RAÍZ: chapter | preface | acknowledgements |
                         appendix | colophon | dedication
                   TAMBIÉN ACEPTA <book> ENTERO, ÚTIL PARA
                   PROBAR EL VOCABULARIO DE UNA SOLA CORRIDA.
  SALIDA         : {proyecto}/latex/c-{sec}-{NN}-{nombre}.tex
  ENSAMBLADO     : EL main.tex LO ESCRIBE GAMBAS. ESTA HOJA NO
                   SABE NADA DEL ORDEN NI DE LOS \include.
  DEPENDENCIA    : tex-comun.xsl
  ============================================================
  PRINCIPIO DE DISEÑO — SEMÁNTICA, NO MAQUETACIÓN
    ESTA HOJA NO EMITE \newpage, \vspace, \clearpage, TAMAÑOS
    DE CUERPO NI COLORES. TODO ESO VIVE EN EL PREÁMBULO. ES LO
    QUE PERMITE QUE UNA EDITORIAL REEMPLACE EL PREÁMBULO ENTERO
    Y QUE ESTOS FRAGMENTOS SIGAN SIRVIENDO SIN TOCARLOS.
  ============================================================
  CONTRATO — MACROS Y ENTORNOS QUE ESTE FRAGMENTO PUEDE USAR
    TODO PREÁMBULO, PROPIO O DE EDITORIAL, DEBE DEFINIRLOS.
    ESTA LISTA ES LA VERSIÓN 1 DEL CONTRATO.

    CLASE
      \frontmatter \mainmatter \backmatter   (book, memoir, scrbook)

    ESTRUCTURA
      \chapter \chapter* \section \subsection \subsubsection
      \label \caption \footnote
      \gbCapitulo \gbCapituloSinNumero   {plano}{compuesto}{subtítulo}
      \gbCorteTitulo   corte del editor en el título (SC-28)
      \gbNotaTitulo    nota al pie en un título de sección (SC-29, CONTRATO 7)
      \gbTachado \gbSubrayado   tachado y subrayado (SC-30, CONTRATO 8)
      (ESTAS TRES SON DEL CONTRATO 6 DE preambulo-contrato.tex)

    PÁGINAS ESPECIALES (fm/bm CON ORDEN 00–09)
      gbpaginaespecial   entorno — recto, sin folio, vuelta en blanco
      gbpaginaimagen     entorno — ídem, rompiendo la caja
      gbdedicatoria      entorno — ídem, con el bloque del epígrafe
                         sin filete y bajado (CONTRATO 13)

    BLOQUES
      gbcita         entorno — cita en bloque
      \gbatribucion  macro   — atribución de la cita
      \gbepigrafe    macro   — {texto}{atribución}
      gbsidebar      entorno — un argumento: info | supplementary
      gbverso        entorno — blockquote role="verso" (SC-49, CONTRATO 14):
                     EL verse DEL PAQUETE verse, EN BASTARDILLA
      gbversoepigrafe entorno — el verso de un epigraph, dentro de
                     \gbepigrafe (SC-49, CONTRATO 14)
      \vin           macro   — una sangría de verso (paquete verse)
      gbconversacion entorno — qandaset role="conversacion" (SC-43, CONTRATO 12)
      \gbetiqueta    macro   — etiqueta del turno, en línea

    LLAMADAS DE ATENCIÓN
      gbnota gbconsejo gbadvertencia gbimportante gbprecaucion

    OTROS
      \enquote        (csquotes)   comillas según idioma
      \href \url      (hyperref)
      \includegraphics (graphicx)
      gbCodigo \gbPieCodigo (contrato 11) — programlisting y el
                      listado, coloreados por colorear_codigo.sh (SC-42)
      \index (imakeidx) \gbIndNota \gbIndPrincipal (contrato 18)
      \gbextranjero, \gbSiglasInicio, \gbSiglaMedir y gbsiglas (contrato 19)
      gbglosario, \gbGlosarioLetra, \gbGlosarioAncla, \gbGlosarioTermino,
      \gbGlosarioSep, \gbGlosarioVease y \gbGlosarioRemite (contrato 20) —
                      índices onomástico y de conceptos (SC-77)
      \parencite \parencite* \textcite \printbibliography (biblatex)
      refsection      entorno     (biblatex)
      \toprule \midrule \bottomrule (booktabs)
  ============================================================
  DATOS QUE LA HOJA LEE DEL PROPIO XML (RC-XJ-02)
    NO HAY PARÁMETROS DE SAXON PARA DATOS DE LA BASE (codigo_dir,
    DECLARADO EN tex-comun.xsl, ES LA CARPETA DEL COLOREADO, NO UN DATO). EL XML
    CANÓNICO DEBE SER AUTÓNOMO Y REPRODUCIBLE POR SÍ SOLO.
      bibliomisc[@role='estilo-cita']    estilo de cita
      bibliomisc[@role='seccion-libro']  fm | a | bm
      bibliomisc[@role='orden-seccion']  NN con dos dígitos
    LOS DOS ÚLTIMOS, Y bibliomisc[@role='tipo-capitulo'], LOS
    ESCRIBE m_XML.GenerarInfoCapituloXML (BLOQUE 2b) EN EL <info>
    DEL CANÓNICO DE CADA PIEZA, QUE ES EL QUE ESTA HOJA RECIBE.
    ensamblar-libro-canonico.xsl LOS REESCRIBE EN EL DEL LIBRO. VERIFICADO CONTRA EL RELAX NG DE DocBook 5.2:
    bibliomisc ES VÁLIDO EN chapter/info, preface/info,
    acknowledgements/info, appendix/info, colophon/info Y
    dedication/info.
    SI FALTAN, LA HOJA NO ABORTA: ASUME PIEZA NORMAL DE CUERPO.
  ============================================================
-->
<xsl:stylesheet version="3.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:xs="http://www.w3.org/2001/XMLSchema"
  xmlns:xlink="http://www.w3.org/1999/xlink"
  xmlns:f="urn:gbpublisher:functions"
  xmlns:gbv="urn:gbpublisher:conversacion"
  xmlns:gbvr="urn:gbpublisher:verso"
  xmlns:gbct="urn:gbpublisher:citas"
  xpath-default-namespace="http://docbook.org/ns/docbook"
  exclude-result-prefixes="xs xlink f gbv gbvr gbct">

  <xsl:import href="tex-comun.xsl"/>

  <!-- NIVELADO DE COMILLAS POR PROFUNDIDAD. VA DESPUÉS DEL import PORQUE
       TODO xsl:import TIENE QUE PRECEDER A CUALQUIER OTRA DECLARACIÓN.
       ES include Y NO import: CON import, EL CATCH-ALL match="*" DE ESTA
       HOJA TENDRÍA MAYOR PRECEDENCIA Y ABORTARÍA EN CADA <quote> -->
  <xsl:include href="quote.xsl"/>

  <!-- CONVERSACIÓN (SC-43): LA ETIQUETA DE CADA TURNO, COMÚN A LAS SEIS HOJAS -->
  <xsl:include href="conversacion-comun.xsl"/>

  <!-- VERSO (SC-49): ESTROFAS, VERSOS Y SANGRÍA, COMÚN A LAS SEIS HOJAS -->
  <xsl:include href="verso-comun.xsl"/>

  <!-- CITAS (SC-57): EL COMANDO DE CADA MODO, EL AGRUPAMIENTO Y EL id DE
       CADA GRUPO, COMUNES CON LA PASADA DE CITAS Y CON HTML Y EPUB -->
  <xsl:include href="cita-comun.xsl"/>

  <xsl:output method="text" encoding="UTF-8"/>

  <!-- ============================================================ -->
  <!-- ESPACIO EN BLANCO                                            -->
  <!-- SE APLASTA SOLO EN ELEMENTOS ESTRUCTURALES. EN CONTENIDO     -->
  <!-- MIXTO NO SE TOCA, PORQUE UN ESPACIO ENTRE DOS ELEMENTOS      -->
  <!-- EN LÍNEA ES CONTENIDO Y NO INDENTACIÓN.                      -->
  <!-- ============================================================ -->
  <xsl:strip-space elements="
    book chapter preface appendix acknowledgements colophon dedication
    section info figure mediaobject imageobject textobject
    informaltable table tgroup thead tbody tfoot row
    itemizedlist orderedlist listitem variablelist varlistentry
    bibliography biblioentry biblioset epigraph blockquote sidebar
    note tip warning important caution keywordset subjectset"/>

  <xsl:preserve-space elements="literallayout programlisting"/>

  <!-- ============================================================ -->
  <!-- VARIABLE GLOBAL: $estilo                                     -->
  <!-- EL IDENTIFICADOR DEL ESTILO DE CITA (apa, verona-modern…)   -->
  <!-- SE USA SOLO PARA DECIDIR EL COMANDO DE CITA (VER LA NOTA     -->
  <!-- SOBRE 'suppress' EN tex-comun.xsl). LA MAQUETACIÓN DE LA     -->
  <!-- BIBLIOGRAFÍA LA RESUELVE EL PREÁMBULO.                       -->
  <!-- ============================================================ -->
  <xsl:variable name="estilo" as="xs:string" select="
    let $v := normalize-space((//bibliomisc[@role='estilo-cita'])[1])
    return if ($v = '') then 'apa' else lower-case($v)"/>

  <!-- ============================================================ -->
  <!-- VARIABLE GLOBAL: $idioma                                     -->
  <!-- ============================================================ -->
  <xsl:variable name="idioma" as="xs:string" select="
    let $v := normalize-space((/*/@xml:lang, /*/*/@xml:lang)[1])
    return if ($v = '') then 'es' else $v"/>

  <!-- ============================================================ -->
  <!--                   RAÍZ                                       -->
  <!-- ============================================================ -->

  <!-- ============================================================ -->
  <!-- FUNCIÓN : f:recortar                                         -->
  <!-- PROPÓSITO: SACA EL ESPACIO DE INDENTACIÓN DEL PRINCIPIO Y    -->
  <!--            DEL FINAL DE UN BLOQUE YA SERIALIZADO.            -->
  <!-- PARÁMETROS: s As xs:string — texto emitido por el bloque     -->
  <!-- RETORNA  : xs:string — sin espacio en los bordes             -->
  <!-- RAZÓN    : PANDOC INDENTA EL CONTENIDO DE <para>. SIN ESTO   -->
  <!--            EL .tex SALE CON SANGRÍAS Y LÍNEAS EN BLANCO DE   -->
  <!--            MÁS. NO CAMBIA LA COMPOSICIÓN, PERO EL .tex ESTÁ  -->
  <!--            VERSIONADO Y SU DIFF TIENE QUE SER LEGIBLE.       -->
  <!-- ============================================================ -->
  <xsl:function name="f:recortar" as="xs:string">
    <xsl:param name="s" as="xs:string"/>
    <xsl:value-of select="replace(replace($s, '^[ \t\r\n]+', ''),
                                            '[ \t\r\n]+$', '')"/>
  </xsl:function>

  <!-- ============================================================ -->
  <!-- GUARDA DE MOTOR BIBLIOGRÁFICO                                -->
  <!-- LA HOJA IMPLEMENTA LA RAMA biblatex: apa, iso690 e ieee.     -->
  <!-- vancouver VA POR bibtex Y NECESITA OTRO JUEGO DE COMANDOS    -->
  <!-- (\cite EN LUGAR DE \parencite, PREFIJO COMO TEXTO LIBRE) Y  -->
  <!-- OTRO MECANISMO DE BIBLIOGRAFÍA POR CAPÍTULO, PORQUE          -->
  <!-- refsection ES DE biblatex. EL CANDIDATO ES chapterbib, QUE   -->
  <!-- SE APOYA EN EL .aux POR ARCHIVO QUE GENERA \include, PERO    -->
  <!-- NO ESTÁ VERIFICADO Y CAMBIA LA ORQUESTACIÓN DEL COMPILADOR:  -->
  <!-- OBLIGA A CORRER bibtex UNA VEZ POR CAPÍTULO.                 -->
  <!-- SE CORTA ACÁ EN VEZ DE EMITIR UN .tex QUE NO COMPILA, O QUE  -->
  <!-- COMPILA CON LAS REFERENCIAS MAL.                             -->
  <!-- ============================================================ -->
  <xsl:template match="/">
    <xsl:if test="f:motor-cita($estilo) != 'biblatex'">
      <xsl:message terminate="yes">
        <xsl:text>&#10;[docbook-to-latex] MOTOR BIBLIOGRÁFICO NO IMPLEMENTADO&#10;</xsl:text>
        <xsl:text>  Estilo del proyecto : </xsl:text>
        <xsl:value-of select="$estilo"/>
        <xsl:text>&#10;  Motor que requiere  : </xsl:text>
        <xsl:value-of select="f:motor-cita($estilo)"/>
        <xsl:text>&#10;&#10;  La salida PDF de libros está implementada para biblatex</xsl:text>
        <xsl:text>&#10;  (apa, iso690, ieee). Cambiar el estilo del proyecto, o</xsl:text>
        <xsl:text>&#10;  implementar y verificar la rama bibtex antes de seguir.&#10;</xsl:text>
      </xsl:message>
    </xsl:if>
    <xsl:apply-templates select="*"/>
  </xsl:template>

  <!-- LIBRO COMPLETO: SOLO PARA PRUEBA DEL VOCABULARIO.            -->
  <!-- EN PRODUCCIÓN LA ENTRADA ES UNA PIEZA POR ARCHIVO Y EL       -->
  <!-- ORDEN LO PONE EL main.tex QUE ESCRIBE GAMBAS.                -->
  <xsl:template match="book">
    <xsl:apply-templates select="* except info"/>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- PIEZAS DE NIVEL LIBRO                                        -->
  <!-- ============================================================ -->

  <xsl:template match="chapter | preface | acknowledgements |
                       appendix | colophon | dedication | glossary">

    <!-- 1. CLASIFICACIÓN DE LA PIEZA -->
    <xsl:variable name="seccion"
      select="normalize-space(info/bibliomisc[@role='seccion-libro'])"/>
    <!-- tipo_capitulo DE LA BASE. ES LA SEÑAL FUERTE: DICE LA        -->
    <!-- FUNCIÓN EDITORIAL DE LA PIEZA Y DE AHÍ SALE SI SE NUMERA.    -->
    <!-- LA CARPETA NO ALCANZA: UNAS CONCLUSIONES VIVEN EN bm/ PERO   -->
    <!-- VAN EN LA ZONA DE CUERPO, SIN NUMERAR, ANTES DE \appendix,   -->
    <!-- PARA QUE LOS APÉNDICES POSTERIORES NUMEREN CON LETRA.        -->
    <xsl:variable name="tipo"
      select="normalize-space(info/bibliomisc[@role='tipo-capitulo'])"/>
    <xsl:variable name="orden"
      select="normalize-space(info/bibliomisc[@role='orden-seccion'])"/>
    <!-- EN fm Y bm LOS NÚMEROS 00 A 09 ESTÁN RESERVADOS PARA PIEZAS -->
    <!-- SUELTAS: UNA FOTO A PÁGINA ENTERA, UN RECORDATORIO, UNA    -->
    <!-- DEDICATORIA. NO SON CAPÍTULOS Y NO ENTRAN AL ÍNDICE.       -->
    <xsl:variable name="especial" as="xs:boolean" select="
      $seccion = ('fm', 'bm')
      and $orden castable as xs:integer
      and xs:integer($orden) &lt; 10"/>

    <!-- ==========================================================
         2. BIBLIOGRAFÍA POR CAPÍTULO
         ==========================================================
         LA SEÑAL ES LA PRESENCIA DE <bibliography> EN LA PIEZA, Y NO
         LA DE CITAS.

         ensamblar-capitulo-canonico.xsl INSERTA ESE ELEMENTO SOLO SI
         GAMBAS LE PASA EL PARÁMETRO biblio, Y SE LO PASA SOLO CUANDO
         libros_md.lugar_bibliografia ES 'por_capitulo'. ASÍ QUE EL
         MODO YA ESTÁ EXPRESADO EN EL DOCUMENTO Y NO HACE FALTA
         PASARLO POR PARÁMETRO NI POR MARCADOR.

         CON 'consolidada' LA PIEZA TIENE CITAS PERO NO <bibliography>:
         NO ABRE refsection Y NO EMITE LISTA. LA ÚNICA LA PONE EL
         main.tex DESPUÉS DEL \backmatter, QUE ES EL ÚNICO LUGAR DESDE
         DONDE SE PUEDE EMITIR.

         CADA PIEZA ES AUTOCONTENIDA: ABRE SU PROPIA refsection Y EMITE
         SU \printbibliography SIN NÚMERO, ASÍ \includeonly NO DESPLAZA
         LA NUMERACIÓN DE LAS SECCIONES BIBLIOGRÁFICAS.
         ========================================================== -->
    <xsl:variable name="conCitas" as="xs:boolean"
      select="exists(.//bibliography)"/>

    <xsl:choose>

      <!-- PÁGINA ESPECIAL: SIN \chapter, SIN ÍNDICE, SIN FOLIO.    -->
      <!-- EL TÍTULO EXISTE PARA HTML Y PARA EL nav DEL EPUB; ACÁ   -->
      <!-- SE DESCARTA A PROPÓSITO.                                 -->
      <xsl:when test="$especial">
        <!-- LA DEDICATORIA TIENE DISEÑO PROPIO (CONTRATO 13). LA SEÑAL ES -->
        <!-- EL ELEMENTO: ensamblar-capitulo-canonico.xsl ESCRIBE          -->
        <!-- <dedication> PARA tipo_capitulo = dedicatoria. EL NÚMERO      -->
        <!-- DA LA PÁGINA ESPECIAL; EL ELEMENTO, CUÁL. UNA DEDICATORIA     -->
        <!-- FUERA DE fm-00 A fm-09 NO LLEGA ACÁ: LA FRENAN EL ABM Y EL    -->
        <!-- GENERADOR (m_PiezasLibro.ProblemaPosicion).                   -->
        <xsl:variable name="entorno" select="
          if (self::dedication) then 'gbdedicatoria'
          else if (exists(.//mediaobject) and not(.//para[normalize-space()]))
          then 'gbpaginaimagen' else 'gbpaginaespecial'"/>
        <xsl:text>&#10;\begin{</xsl:text>
        <xsl:value-of select="$entorno"/>
        <xsl:text>}&#10;</xsl:text>
        <!-- LA FICHA DE ESPACIO VERTICAL (SC-39) ES UNA INSTRUCCIÓN DE   -->
        <!-- PROCESAMIENTO, NO UN ELEMENTO: * NO LA ALCANZA. VA EN LA UNIÓN, -->
        <!-- QUE CONSERVA EL ORDEN DEL DOCUMENTO. LA TRADUCE tex-comun.xsl  -->
        <xsl:apply-templates select="(* except info) | processing-instruction('gb-espacio')"/>
        <xsl:text>\end{</xsl:text>
        <xsl:value-of select="$entorno"/>
        <xsl:text>}&#10;&#10;</xsl:text>
      </xsl:when>

      <!-- PIEZA NORMAL -->
      <xsl:otherwise>
        <xsl:if test="$conCitas">
          <xsl:text>&#10;\begin{refsection}&#10;</xsl:text>
        </xsl:if>

        <!-- LOS PRELIMINARES Y POSLIMINARES NO SE NUMERAN, PERO SÍ -->
        <!-- ENTRAN AL ÍNDICE GENERAL: POR ESO \chapter* MÁS        -->
        <!-- \addcontentsline Y NO \chapter A SECAS.                -->
        <!-- ==========================================================
             NUMERACIÓN
             ==========================================================
             SE DERIVA DEL ELEMENTO Y DEL role, QUE YA ESTÁN EN EL
             CANÓNICO: ensamblar-capitulo-canonico.xsl LOS ESCRIBE A
             PARTIR DE capitulos.tipo_capitulo. NO HACE FALTA UN
             MARCADOR ADICIONAL PARA UN DATO QUE EL DOCUMENTO YA
             EXPRESA EN VOCABULARIO DocBook.

               <chapter> sin role            → capítulo, NUMERADO
               <chapter role="introduccion">  → SIN NUMERAR
               <chapter role="conclusiones">  → SIN NUMERAR
               <chapter role="epilogo">       → SIN NUMERAR
               <appendix> sin role            → apéndice, NUMERADO, CON LETRA
               <appendix role="sobre-autores"> → SIN NUMERAR
               <appendix role="cronologia">    → SIN NUMERAR
               todo lo demás                  → SIN NUMERAR

             sobre_autores Y cronologia COMPARTEN EL ELEMENTO <appendix>
             PERO VAN EN POSLIMINARES, DONDE \chapter NO NUMERA: SIN EL
             role EN LA REGLA, LA PIEZA SE ABRÍA CON \gbCapitulo Y NO
             REINICIABA SUS CONTADORES. LA MISMA REGLA LA APLICAN EL EPUB
             Y EL HTML (numeracion-libro.xsl, SC-31).

             LO NO NUMERADO VA CON \chapter* MÁS \addcontentsline, QUE
             ENTRA AL SUMARIO SIN NÚMERO.

             bibliomisc[@role='tipo-capitulo'] SE RESPETA SI ESTÁ: LO
             TRAEN EL CANÓNICO DE CADA PIEZA Y EL DEL LIBRO. DA LO MISMO
             QUE EL ELEMENTO Y SU role, PORQUE ensamblar-capitulo-canonico
             DERIVA EL ELEMENTO DEL MISMO tipo_capitulo.
             ========================================================== -->
        <xsl:variable name="numerado" as="xs:boolean" select="
          if ($tipo != '')
          then $tipo = ('capitulo', 'apendice')
          else ((self::chapter or self::appendix)
                and normalize-space(@role) = '')"/>
        <!-- ==========================================================
             TÍTULO Y SUBTÍTULO (SC-28, CONTRATO 6)
             ==========================================================
             DOS VERSIONES DEL TÍTULO: LA COMPUESTA, CON EL CORTE QUE
             ESCRIBIÓ EL EDITOR, VA A LA APERTURA; LA PLANA VA AL
             SUMARIO, AL FOLIO Y A LOS MARCADORES. LAS ARMA EL CONTRATO
             CON \gbCapitulo Y \gbCapituloSinNumero, QUE TAMBIÉN
             COMPONEN EL SUBTÍTULO: ESTA HOJA NO DECIDE SU ASPECTO.
             EL SUBTÍTULO NO VA AL SUMARIO.
             ========================================================== -->
        <xsl:variable name="nodoTitulo" select="(info/title, title)[1]"/>
        <xsl:variable name="nodoSubtitulo" select="(info/subtitle, subtitle)[1]"/>

        <xsl:text>&#10;</xsl:text>
        <xsl:value-of select="if ($numerado) then '\gbCapitulo'
                              else '\gbCapituloSinNumero'"/>
        <xsl:text>{</xsl:text>
        <xsl:value-of select="f:titulo-plano($nodoTitulo)"/>
        <xsl:text>}{</xsl:text>
        <xsl:value-of select="f:titulo-compuesto($nodoTitulo)"/>
        <xsl:text>}{</xsl:text>
        <xsl:value-of select="f:titulo-compuesto($nodoSubtitulo)"/>
        <xsl:text>}&#10;</xsl:text>
        <xsl:if test="@xml:id">
          <xsl:text>\label{</xsl:text>
          <xsl:value-of select="@xml:id"/>
          <xsl:text>}&#10;</xsl:text>
        </xsl:if>
        <xsl:text>&#10;</xsl:text>

        <!-- LA FICHA DE ESPACIO VERTICAL (SC-39) ES UNA INSTRUCCIÓN DE   -->
        <!-- PROCESAMIENTO, NO UN ELEMENTO: * NO LA ALCANZA. VA EN LA UNIÓN, -->
        <!-- QUE CONSERVA EL ORDEN DEL DOCUMENTO. LA TRADUCE tex-comun.xsl  -->
        <xsl:apply-templates select="(* except info) | processing-instruction('gb-espacio')"/>

        <xsl:if test="$conCitas">
          <!-- EL heading DE biblatex HACE \markboth CON «REFERENCIAS», Y ESA
               MARCA REEMPLAZA LA DEL CAPÍTULO EN EL FOLIO CORRIDO. EL FOLIO
               TIENE QUE SEGUIR DICIENDO DE QUÉ PIEZA ES LA PÁGINA, NO QUE AHÍ
               EMPIEZA LA BIBLIOGRAFÍA.
               POR ESO EL TÍTULO VA COMO \section* ESCRITO APARTE Y biblatex SE
               LLAMA CON heading=none.
               \refname TOMA LA CADENA DE babel, ASÍ QUE UN CAPÍTULO EN INGLÉS
               DICE «References». -->
          <xsl:text>&#10;\section*{\refname}&#10;</xsl:text>
          <xsl:text>\printbibliography[heading=none]&#10;</xsl:text>
          <xsl:text>\end{refsection}&#10;&#10;</xsl:text>
        </xsl:if>
      </xsl:otherwise>

    </xsl:choose>
  </xsl:template>

  <!-- EL <info> DE UNA PIEZA SOLO APORTA EL TÍTULO, YA CONSUMIDO.  -->
  <xsl:template match="info"/>

  <!-- ============================================================ -->
  <!-- SECCIONES                                                    -->
  <!-- PROFUNDIDAD = CANTIDAD DE ANCESTROS section                  -->
  <!-- ============================================================ -->

  <!-- EL TÍTULO DE SECCIÓN SE ARMA DOS VECES, RECORRIENDO SUS NODOS  -->
  <!-- (SC-29). normalize-space() SOBRE EL TÍTULO PEGABA EL TEXTO DE  -->
  <!-- UNA NOTA AL TÍTULO Y BORRABA LA CURSIVA.                       -->
  <!--   apertura  LO QUE SE COMPONE: CADA NOTA COMO \gbNotaTitulo    -->
  <!--   sumario   EL ARGUMENTO OPCIONAL, QUE VA AL SUMARIO, AL FOLIO -->
  <!--             Y A LOS MARCADORES: SIN NOTAS, CON EL FORMATO      -->
  <!-- LO DECIDE EL PARÁMETRO DE TÚNEL notasTitulo, QUE LEE LA        -->
  <!-- PLANTILLA footnote. LAS DEMÁS PLANTILLAS EN LÍNEA LO PASAN SIN -->
  <!-- DECLARARLO.                                                    -->
  <xsl:template match="section">
    <xsl:variable name="prof" select="count(ancestor::section)"/>
    <xsl:variable name="nodoTitulo" select="(info/title, title)[1]"/>
    <xsl:variable name="apertura">
      <xsl:apply-templates select="$nodoTitulo/node()">
        <xsl:with-param name="notasTitulo" select="'apertura'" tunnel="yes"/>
      </xsl:apply-templates>
    </xsl:variable>
    <xsl:variable name="sumario">
      <xsl:apply-templates select="$nodoTitulo/node()">
        <xsl:with-param name="notasTitulo" select="'sumario'" tunnel="yes"/>
      </xsl:apply-templates>
    </xsl:variable>
    <xsl:text>&#10;</xsl:text>
    <xsl:choose>
      <xsl:when test="$prof = 0">\section[</xsl:when>
      <xsl:when test="$prof = 1">\subsection[</xsl:when>
      <xsl:when test="$prof = 2">\subsubsection[</xsl:when>
      <xsl:otherwise>\paragraph[</xsl:otherwise>
    </xsl:choose>
    <!-- normalize-space EN EL SUMARIO: NO TIENE NOTAS, Y UN SALTO DE -->
    <!-- LÍNEA EN EL ARGUMENTO NO APORTA NADA.                        -->
    <!-- UNA CITA EN EL TÍTULO NO TIENE FORMA DE CADENA PDF: hyperref -->
    <!-- BORRA EL COMANDO Y DEJA LA CLAVE EN EL MARCADOR («Con cita a -->
    <!-- en el título», VERIFICADO). EN ESE CASO EL MARCADOR RECIBE   -->
    <!-- POR \texorpdfstring EL TEXTO DEL TÍTULO SIN NOTAS NI CITAS.  -->
    <xsl:choose>
      <xsl:when test="$nodoTitulo//biblioref">
        <xsl:text>\texorpdfstring{</xsl:text>
        <xsl:value-of select="normalize-space(string($sumario))"/>
        <xsl:text>}{</xsl:text>
        <xsl:value-of select="f:latex(normalize-space(string-join(
          $nodoTitulo//text()[not(ancestor::footnote)], '')))"/>
        <xsl:text>}</xsl:text>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="normalize-space(string($sumario))"/>
      </xsl:otherwise>
    </xsl:choose>
    <xsl:text>]{</xsl:text>
    <xsl:value-of select="f:recortar(string($apertura))"/>
    <xsl:text>}&#10;</xsl:text>
    <xsl:if test="@xml:id">
      <xsl:text>\label{</xsl:text>
      <xsl:value-of select="@xml:id"/>
      <xsl:text>}&#10;</xsl:text>
    </xsl:if>
    <!-- LA FICHA DE ESPACIO VERTICAL (SC-39) ES UNA INSTRUCCIÓN DE   -->
    <!-- PROCESAMIENTO, NO UN ELEMENTO: * NO LA ALCANZA. VA EN LA UNIÓN, -->
    <!-- QUE CONSERVA EL ORDEN DEL DOCUMENTO. LA TRADUCE tex-comun.xsl  -->
    <xsl:apply-templates select="(* except (info | title)) | processing-instruction('gb-espacio')"/>
  </xsl:template>

  <!-- CORTE DE LÍNEA EN UN TÍTULO DE SECCIÓN (SC-28, SC-63): EL      -->
  <!-- <?gb-corte?> QUE ESCRIBE corte-titulo.lua DESDE EL \\ DEL .md. -->
  <!-- CORTA SOLO EN LA APERTURA; EN EL SUMARIO, EL FOLIO Y LOS       -->
  <!-- MARCADORES NO ESCRIBE NADA: EL ESPACIO YA ESTÁ ANTES. EL       -->
  <!-- ESPACIO DESPUÉS DE \gbCorteTitulo SEPARA LA ORDEN DE LA        -->
  <!-- PALABRA QUE SIGUE, Y TeX LO DESCARTA. LOS TÍTULOS QUE VIENEN    -->
  <!-- DE LA BASE NO PASAN POR ACÁ: LOS ARMAN f:titulo-compuesto Y     -->
  <!-- f:titulo-plano (tex-comun.xsl).                                 -->
  <xsl:template match="processing-instruction('gb-corte')">
    <xsl:param name="notasTitulo" tunnel="yes" select="''"/>
    <xsl:if test="$notasTitulo = 'apertura'">
      <xsl:text>\gbCorteTitulo </xsl:text>
    </xsl:if>
  </xsl:template>

  <!-- EL TÍTULO LO EMITE EL PADRE. ACÁ SE SUPRIME PARA QUE NO SE   -->
  <!-- CUELE COMO TEXTO SUELTO.                                     -->
  <xsl:template match="chapter/title | preface/title | section/title |
                       appendix/title | acknowledgements/title |
                       colophon/title | dedication/title"/>

  <!-- ============================================================ -->
  <!-- PÁRRAFOS Y TEXTO                                             -->
  <!-- ============================================================ -->

  <!-- LA FICHA DE ALINEACIÓN (SC-61) NO PASA A apply-templates: LA   -->
  <!-- TRADUCEN f:alinear-abre Y f:alinear-cierra (tex-comun.xsl)     -->
  <!-- ALREDEDOR DEL PÁRRAFO. SIN FICHA, LAS DOS DEVUELVEN VACÍO.     -->
  <xsl:template match="para">
    <xsl:variable name="ficha" select="f:alinear-ficha(.)"/>
    <xsl:variable name="c"><xsl:apply-templates select="node() except $ficha"/></xsl:variable>
    <xsl:value-of select="f:alinear-abre($ficha)"/>
    <xsl:value-of select="f:recortar(string($c))"/>
    <xsl:value-of select="f:alinear-cierra($ficha)"/>
    <xsl:text>&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- FROUFROU (SC-36): EL SEPARADOR DEL PAQUETE froufrou, CARGADO EN   -->
  <!-- preambulo-contrato.tex. EL TEXTO «* * *» DEL CANÓNICO NO SE USA.  -->
  <xsl:template match="para[@role='froufrou']" priority="5">
    <xsl:text>&#10;\froufrou&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- CONVERSACIÓN (SC-43, CONTRATO 12)                            -->
  <!-- ============================================================ -->
  <!-- EL qandaset ES EL ENTORNO gbconversacion (SANS, \small, SIN  -->
  <!-- SANGRÍA, \medskip AL ABRIR Y AL CERRAR). CADA TURNO ABRE SU  -->
  <!-- PRIMER PÁRRAFO CON \gbetiqueta{ETIQUETA}, EN MAYÚSCULAS DE   -->
  <!-- PESO NORMAL (gbv:etiqueta). DESPUÉS DE UNA PREGUNTA,          -->
  <!-- \nopagebreak[4] EN MODO VERTICAL: LA PREGUNTA NO QUEDA SOLA  -->
  <!-- AL PIE DE LA PÁGINA. LA ACOTACIÓN ES UN PÁRRAFO MÁS.          -->
  <!-- UN qandaset SIN role="conversacion" NO TIENE PLANTILLA: CAE  -->
  <!-- EN EL CATCH-ALL Y FRENA.                                     -->
  <!-- ============================================================ -->
  <xsl:template match="qandaset[@role = 'conversacion']" priority="5">
    <xsl:text>\begin{gbconversacion}&#10;</xsl:text>
    <xsl:apply-templates select="*"/>
    <xsl:text>\end{gbconversacion}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="qandaentry">
    <xsl:apply-templates select="question | answer"/>
  </xsl:template>

  <xsl:template match="question | answer">
    <xsl:variable name="bloques" select="gbv:bloques(.)"/>
    <xsl:variable name="etiqueta"
      select="concat('\gbetiqueta{', f:latex(gbv:etiqueta(.)), '}')"/>
    <xsl:choose>
      <!-- LO HABITUAL: LA ETIQUETA ABRE EL PRIMER PÁRRAFO, EN LÍNEA -->
      <xsl:when test="$bloques[1][self::para]">
        <xsl:variable name="c"><xsl:apply-templates select="$bloques[1]/node()"/></xsl:variable>
        <xsl:value-of select="$etiqueta"/>
        <xsl:value-of select="f:recortar(string($c))"/>
        <xsl:text>&#10;&#10;</xsl:text>
        <xsl:apply-templates select="$bloques[position() gt 1]"/>
      </xsl:when>
      <!-- UN TURNO QUE EMPIEZA CON UNA LISTA U OTRO BLOQUE: LA ETIQUETA
           VA SOLA EN SU PÁRRAFO -->
      <xsl:otherwise>
        <xsl:value-of select="$etiqueta"/>
        <xsl:text>&#10;&#10;</xsl:text>
        <xsl:apply-templates select="$bloques"/>
      </xsl:otherwise>
    </xsl:choose>
    <xsl:if test="gbv:es-pregunta(.)">
      <xsl:text>\nopagebreak[4]&#10;&#10;</xsl:text>
    </xsl:if>
  </xsl:template>

  <!-- PÁRRAFO DENTRO DE UN ÍTEM O DE UNA NOTA: SIN DOBLE SALTO     -->
  <!-- FINAL, QUE ABRIRÍA UN PÁRRAFO VACÍO.                         -->
  <xsl:template match="listitem/para | footnote/para | entry/para |
                       attribution/para | epigraph/para">
    <xsl:variable name="c"><xsl:apply-templates/></xsl:variable>
    <xsl:value-of select="f:recortar(string($c))"/>
    <xsl:if test="following-sibling::para">
      <xsl:text>&#10;&#10;</xsl:text>
    </xsl:if>
  </xsl:template>

  <xsl:template match="text()">
    <xsl:value-of select="f:latex(.)"/>
  </xsl:template>

  <!-- CONTENIDO LITERAL: PASA CRUDO, SIN ESCAPAR. EL VERSO NO ES      -->
  <!-- LITERAL: SU TEXTO SE ESCAPA COMO EL DE UN PÁRRAFO (SC-49).       -->
  <xsl:template match="programlisting//text()
                       | literallayout[not(@role = 'verse')]//text()">
    <xsl:value-of select="."/>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- MARCAS EN LÍNEA                                              -->
  <!-- ============================================================ -->

  <!-- \emph Y NO \textit: ALTERNA AL ANIDAR. -->
  <xsl:template match="emphasis">
    <xsl:text>\emph{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- SIGLAS (1.18.0, filters/siglas.lua). LA SIGLA VA COMO TEXTO:   -->
  <!-- xlink:title ES PARA EL <abbr> DEL HTML Y DEL EPUB. EL TEXTO LO  -->
  <!-- ESCAPA f:latex (A&C, $).                                        -->
  <xsl:template match="acronym">
    <xsl:apply-templates/>
  </xsl:template>

  <!-- EL DESARROLLO EN OTRO IDIOMA: CURSIVA Y LA PARTICIÓN DE SU      -->
  <!-- IDIOMA. \gbextranjero ESTÁ EN preambulo-contrato.tex Y TOMA EL  -->
  <!-- NOMBRE DE babel DE LAS DEFINICIONES QUE ESCRIBE GAMBAS           -->
  <!-- (m_GenerarPDFLibro.DefinicionesCita), QUE TAMBIÉN CARGA EL       -->
  <!-- IDIOMA EN babel. SIN xml:lang, O CON UNO QUE NO ES UN CÓDIGO,    -->
  <!-- CORTA: NO HAY DE DÓNDE SACAR LA PARTICIÓN.                       -->
  <xsl:template match="foreignphrase">
    <xsl:if test="not(matches(string(@xml:lang), '^[A-Za-z]{2,3}(-[A-Za-z0-9]+)*$'))">
      <xsl:call-template name="abortar-elemento">
        <xsl:with-param name="contexto" select="'docbook-to-latex (foreignphrase sin un xml:lang válido)'"/>
      </xsl:call-template>
    </xsl:if>
    <xsl:text>\gbextranjero{</xsl:text>
    <xsl:value-of select="@xml:lang"/>
    <xsl:text>}{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- LA LISTA DE SIGLAS DEL LIBRO (1.18.0, CONTRATO 19). LA ESCRIBE  -->
  <!-- generar_canonicos_capitulos.sh (procesar_lista_siglas) EN LA    -->
  <!-- PIEZA lista_abreviaturas: UN <glossentry> POR SIGLA, EN ORDEN.   -->
  <!-- DOS COLUMNAS ALINEADAS (DECISIÓN DE ALBERTO, 31/10): LA PRIMERA  -->
  <!-- MIDE LO QUE LA SIGLA MÁS ANCHA, QUE SE MIDE EN LaTeX CON          -->
  <!-- \gbSiglaMedir ANTES DE ABRIR EL ENTORNO: CONTAR LETRAS NO SIRVE  -->
  <!-- (MMM Y III NO MIDEN LO MISMO).                                   -->
  <xsl:template match="glosslist[@role = 'siglas']">
    <xsl:text>&#10;\gbSiglasInicio&#10;</xsl:text>
    <xsl:for-each select="glossentry">
      <xsl:text>\gbSiglaMedir{</xsl:text>
      <xsl:apply-templates select="glossterm/node()"/>
      <xsl:text>}&#10;</xsl:text>
    </xsl:for-each>
    <xsl:text>\begin{gbsiglas}&#10;</xsl:text>
    <xsl:for-each select="glossentry">
      <!-- LA SIGLA NO TIENE [ NI ] (m_Siglas.AvisoEntrada): EL ARGUMENTO -->
      <!-- OPCIONAL DE \item NO SE CORTA                                -->
      <xsl:text>\item[</xsl:text>
      <xsl:apply-templates select="glossterm/node()"/>
      <xsl:text>] </xsl:text>
      <xsl:apply-templates select="glossdef/para/node()"/>
      <xsl:text>&#10;</xsl:text>
    </xsl:for-each>
    <xsl:text>\end{gbsiglas}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- EL GLOSARIO DEL LIBRO (1.18.0, CONTRATO 20). LO ARMA            -->
  <!-- glosario.lua: UNA <glossdiv> POR LETRA, CON SUS <glossentry>     -->
  <!-- ORDENADAS. PÁRRAFO FRANCÉS (DECISIÓN DE ALBERTO, 31/10): EL      -->
  <!-- TÉRMINO, « – » (\gbGlosarioSep) Y LA DEFINICIÓN, LAS LÍNEAS      -->
  <!-- SIGUIENTES SANGRADAS (ENTORNO gbglosario). EL PRIMER PÁRRAFO DE  -->
  <!-- LA DEFINICIÓN SIGUE AL TÉRMINO; LOS DEMÁS, EN PÁRRAFOS PROPIOS.  -->
  <xsl:template match="glossdiv">
    <xsl:text>&#10;\gbGlosarioLetra{</xsl:text>
    <xsl:apply-templates select="title/node()"/>
    <xsl:text>}&#10;\begin{gbglosario}&#10;</xsl:text>
    <xsl:apply-templates select="glossentry"/>
    <xsl:text>\end{gbglosario}&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="glossdiv/glossentry">
    <xsl:text>\item[]\gbGlosarioAncla{</xsl:text>
    <xsl:value-of select="@xml:id"/>
    <xsl:text>}\gbGlosarioTermino{</xsl:text>
    <xsl:apply-templates select="glossterm/node()"/>
    <xsl:text>}</xsl:text>
    <xsl:choose>
      <!-- UNA REMISIÓN: «Traveling, véase Travelling» -->
      <xsl:when test="glosssee">
        <xsl:text>\gbGlosarioVease{</xsl:text>
        <xsl:value-of select="glosssee/@otherterm"/>
        <xsl:text>}{</xsl:text>
        <xsl:apply-templates select="glosssee/node()"/>
        <xsl:text>}&#10;&#10;</xsl:text>
      </xsl:when>
      <xsl:otherwise>
        <xsl:text>\gbGlosarioSep </xsl:text>
        <xsl:apply-templates select="glossdef/*"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- UNA REMISIÓN DENTRO DE UNA DEFINICIÓN: ENLACE A LA ENTRADA -->
  <xsl:template match="glossterm[@linkend]">
    <xsl:text>\gbGlosarioRemite{</xsl:text>
    <xsl:value-of select="@linkend"/>
    <xsl:text>}{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- LOS role DE emphasis QUE ESCRIBE PANDOC (SC-30): strong PARA   -->
  <!-- **x**, smallcaps PARA [x]{.smallcaps}, strikethrough PARA ~~x~~ -->
  <!-- Y underline PARA [x]{.underline}. SIN ESTAS PLANTILLAS LOS TRES -->
  <!-- ÚLTIMOS SALÍAN EN BASTARDILLA. bold SE ACEPTA COMO SINÓNIMO DE  -->
  <!-- strong, COMO EN LA HOJA HTML.                                   -->
  <xsl:template match="emphasis[@role='smallcaps']" priority="5">
    <xsl:text>\textsc{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="emphasis[@role='strikethrough']" priority="5">
    <xsl:text>\gbTachado{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="emphasis[@role='underline']" priority="5">
    <xsl:text>\gbSubrayado{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="emphasis[@role = ('strong', 'bold')]" priority="5">
    <xsl:text>\textbf{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="literal | code | command | filename">
    <xsl:text>\texttt{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- quote NO SE DEFINE ACÁ: LO RESUELVE quote.xsl, INCLUIDO ARRIBA,  -->
  <!-- CON CARACTERES Y NO CON \enquote, PARA QUE LAS TRES SALIDAS      -->
  <!-- NIVELEN CON LA MISMA REGLA. UNA SEGUNDA PLANTILLA ACÁ PRODUCE    -->
  <!-- UNA COINCIDENCIA AMBIGUA Y SAXON ELIGE UNA DE LAS DOS.           -->

  <xsl:template match="subscript">
    <xsl:text>\textsubscript{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="superscript">
    <xsl:text>\textsuperscript{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- LETRA VOLADA (SC-62): \sptext{o}, CON SUS CONTROLES EN        -->
  <!-- f:volada-latex (tex-comun.xsl). EL TEXTO QUE LA PRECEDE PIERDE -->
  <!-- SU PUNTO FINAL: LO PONE \sptext. LAS DOS PLANTILLAS VAN ACÁ Y  -->
  <!-- NO EN tex-comun.xsl: UNA IMPORTADA PIERDE CONTRA text() Y      -->
  <!-- superscript DE ESTA HOJA (GV-117).                            -->
  <!-- EN EL ARGUMENTO OPCIONAL DE UN TÍTULO (notasTitulo = sumario, -->
  <!-- EL QUE VA A LOS MARCADORES) SALE CON \texorpdfstring (GV-118). -->
  <xsl:template match="superscript[@role = 'volada']" priority="2">
    <xsl:param name="notasTitulo" tunnel="yes" select="''"/>
    <xsl:value-of select="f:volada-latex(., $notasTitulo = 'sumario')"/>
  </xsl:template>

  <xsl:template match="text()[following-sibling::node()[1][self::superscript[@role = 'volada']]]"
                priority="4">
    <xsl:value-of select="f:latex(f:sin-punto-final(.))"/>
  </xsl:template>

  <!-- phrase SIN role: TRANSPARENTE. LOS role DE CITA SE ABSORBEN  -->
  <!-- EN LA PLANTILLA DE biblioref Y SE SUPRIMEN ACÁ.              -->
  <xsl:template match="phrase">
    <xsl:apply-templates/>
  </xsl:template>

  <xsl:template match="phrase[@role = ('cite-prefix', 'cite-suffix')]"
                priority="5"/>

  <!-- CANTIDAD (SC-65): LA ORDEN DE siunitx DESDE LA FICHA DE @remap, -->
  <!-- CON f:cifra-latex (tex-comun.xsl). EL TEXTO DEL ELEMENTO ES EL  -->
  <!-- DEL HTML: ACÁ NO SE USA, SALVO EN UN MARCADOR (GV-118).         -->
  <xsl:template match="phrase[@role = 'cantidad']" priority="3">
    <xsl:param name="notasTitulo" tunnel="yes" select="''"/>
    <xsl:value-of select="f:cifra-latex(., string(@remap), $notasTitulo = 'sumario')"/>
  </xsl:template>

  <xsl:template match="link[@xlink:href]">
    <xsl:text>\href{</xsl:text>
    <xsl:value-of select="f:latex-url(@xlink:href)"/>
    <xsl:text>}{</xsl:text>
    <xsl:apply-templates/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="uri">
    <xsl:text>\url{</xsl:text>
    <xsl:value-of select="f:latex-url(string(.))"/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- NOTA AL PIE. EN UN TÍTULO DE SECCIÓN (SC-29) DEPENDE DEL      -->
  <!-- PARÁMETRO DE TÚNEL notasTitulo:                                -->
  <!--   apertura  \gbNotaTitulo, QUE NO AVANZA EL CONTADOR CUANDO    -->
  <!--             titlesec MIDE EL TÍTULO (CONTRATO 7, GV-70). EL    -->
  <!--             ARGUMENTO DEL TÍTULO NO ADMITE \par: LOS PÁRRAFOS   -->
  <!--             DE LA NOTA SE SEPARAN CON \endgraf                  -->
  <!--   sumario   NADA: LA NOTA NO VA AL SUMARIO NI A LOS MARCADORES -->
  <!-- FUERA DE UN TÍTULO, \footnote COMO SIEMPRE.                    -->
  <xsl:template match="footnote">
    <xsl:param name="notasTitulo" tunnel="yes" select="''"/>
    <xsl:variable name="c"><xsl:apply-templates/></xsl:variable>
    <xsl:choose>
      <xsl:when test="$notasTitulo = 'sumario'"/>
      <xsl:when test="$notasTitulo = 'apertura'">
        <xsl:text>\gbNotaTitulo{</xsl:text>
        <xsl:value-of select="replace(f:recortar(string($c)),
                                      '[ \t]*\n([ \t]*\n)+[ \t]*', '\\endgraf ')"/>
        <xsl:text>}</xsl:text>
      </xsl:when>
      <xsl:otherwise>
        <xsl:text>\footnote{</xsl:text>
        <xsl:value-of select="f:recortar(string($c))"/>
        <xsl:text>}</xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template match="xref[@linkend]">
    <xsl:text>\ref{</xsl:text>
    <xsl:value-of select="@linkend"/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- CITAS BIBLIOGRÁFICAS                                         -->
  <!-- ============================================================ -->
  <!-- LA CITA NO ES UN NODO: ES UNA SECUENCIA DE HERMANOS.         -->
  <!--   <phrase role="cite-prefix">ver</phrase>                    -->
  <!--   <biblioref linkend="cap-N-bib-CLAVE" role="..."/>          -->
  <!--   <phrase role="cite-suffix">pp. 55-60</phrase>              -->
  <!-- SE RECONSTRUYE ACÁ Y SE VUELCA EN LOS DOS ARGUMENTOS         -->
  <!-- OPCIONALES DE biblatex.                                      -->
  <!--                                                             -->
  <!-- CLAVE DE CITA: SE QUITA EL PREFIJO DEL linkend.             -->
  <!-- EL PREFIJO NO ES EL MISMO EN LOS DOS CANÓNICOS:              -->
  <!--   por capítulo   bib-3290-ACOSTA2012                         -->
  <!--   ensamblado     cap-7-bib-3290-ACOSTA2012                   -->
  <!-- EL 'cap-N-' LO AGREGA EL ENSAMBLADOR PARA QUE LOS ids NO     -->
  <!-- COLISIONEN ENTRE CAPÍTULOS. LA HOJA TIENE QUE ACEPTAR LAS    -->
  <!-- DOS FORMAS, PORQUE EN PRODUCCIÓN LA ENTRADA ES UNA PIEZA POR -->
  <!-- ARCHIVO Y EL ENSAMBLADO SOLO SE USA PARA PROBAR.             -->
  <!-- LO QUE QUEDA ES LA CLAVE DEL .bib QUE GENERA LA APP.         -->
  <!-- ============================================================ -->
  <xsl:template match="biblioref">
    <xsl:variable name="modo" select="gbct:modo-de(.)"/>

    <!-- ESTE biblioref YA FUE ABSORBIDO POR EL GRUPO DEL ANTERIOR: -->
    <!-- NO EMITE NADA. VER LA NOTA SOBRE AGRUPAMIENTO ABAJO.       -->
    <xsl:if test="not(gbct:es-continuacion(., $estilo))">

    <xsl:variable name="grupo"   select="gbct:grupo-desde(., $estilo)"/>
    <xsl:variable name="comando" select="gbct:comando-cita($modo, $estilo)"/>

    <!-- \protect ES OBLIGATORIO: LOS COMANDOS DE CITA DE biblatex
         NO SON ROBUSTOS Y LOS ARGUMENTOS DE \caption, \chapter Y
         \section SON MÓVILES — SE REESCRIBEN AL .toc Y AL .lof Y
         SE REEXPANDEN AHÍ. SIN \protect, UNA CITA EN UN PIE DE
         FIGURA PRODUCE UNA SEGUNDA CITA CON CLAVE VACÍA:
           LaTeX Warning: Citation '' on page 2 undefined
         QUE NO DICE NADA SOBRE LA CAUSA. VERIFICADO.
         FUERA DE UN ARGUMENTO MÓVIL \protect NO HACE NADA, ASÍ
         QUE SE EMITE SIEMPRE EN VEZ DE DETECTAR EL CONTEXTO. -->
    <xsl:text>\protect</xsl:text>

    <xsl:choose>

      <!-- NINGUNA CITA DEL GRUPO LLEVA AFIJOS: UN SOLO COMANDO CON  -->
      <!-- TODAS LAS CLAVES, \parencite{a,b}. ES LO QUE PERMITE AL   -->
      <!-- ESTILO ORDENARLAS Y COMPRIMIR RANGOS.                     -->
      <xsl:when test="every $b in $grupo satisfies gbct:sin-afijos($b)">
        <xsl:value-of select="$comando"/>
        <xsl:text>{</xsl:text>
        <xsl:value-of select="string-join(for $b in $grupo return gbct:clave($b/@linkend), ',')"/>
        <xsl:text>}</xsl:text>
      </xsl:when>

      <!-- UNA SOLA CITA CON AFIJOS -->
      <xsl:when test="count($grupo) = 1">
        <xsl:value-of select="$comando"/>
        <xsl:call-template name="afijos-y-clave">
          <xsl:with-param name="b" select="."/>
        </xsl:call-template>
      </xsl:when>

      <!-- VARIAS CITAS Y ALGUNA CON AFIJOS: EL COMANDO MÚLTIPLE,    -->
      <!-- CON LOS AFIJOS DE CADA UNA:                               -->
      <!--   \parencites[17]{hodges}[en][199]{macchiarola}           -->
      <!-- ANTES CADA CITA SALÍA COMO UN COMANDO APARTE, CON LA COMA -->
      <!-- DEL CANÓNICO ENTRE LOS DOS: «(…, p. 17), (en …)». EL      -->
      <!-- DELIMITADOR LO PONE AHORA EL ESTILO: EN biblatex-apa ES   -->
      <!-- PUNTO Y COMA, TAMBIÉN EN LAS FUENTES SECUNDARIAS (APA     -->
      <!-- 8.6 EN LA DOCUMENTACIÓN DEL PAQUETE).                     -->
      <xsl:otherwise>
        <xsl:value-of select="gbct:comando-multicita($comando)"/>
        <xsl:for-each select="$grupo">
          <xsl:call-template name="afijos-y-clave">
            <xsl:with-param name="b" select="."/>
          </xsl:call-template>
        </xsl:for-each>
      </xsl:otherwise>

    </xsl:choose>

    </xsl:if>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- PLANTILLA: afijos-y-clave                                    -->
  <!-- PROPÓSITO: LOS ARGUMENTOS OPCIONALES Y LA CLAVE DE UNA CITA. -->
  <!--            SIRVE IGUAL PARA UN COMANDO SIMPLE Y PARA CADA    -->
  <!--            CITA DE UNO MÚLTIPLE: LA REGLA ES LA MISMA.       -->
  <!-- PARÁMETROS: b As node() — el biblioref                       -->
  <!-- RETORNA  : [pre][post]{clave}, [pre][]{clave}, [post]{clave} -->
  <!--            o {clave}                                          -->
  <!-- ============================================================ -->
  <xsl:template name="afijos-y-clave">
    <xsl:param name="b" as="node()"/>
    <xsl:variable name="pre"  select="gbct:prefijo-de($b)"/>
    <xsl:variable name="post" select="gbct:sufijo-de($b)"/>

    <!-- biblatex CON UN SOLO [] LO INTERPRETA COMO POSTNOTA.       -->
    <!-- CON PREFIJO Y SIN SUFIJO HAY QUE EMITIR [pre][] PARA       -->
    <!-- FORZAR QUE EL PRIMERO SE LEA COMO PRENOTA.                 -->
    <xsl:choose>
      <xsl:when test="$pre and $post">
        <xsl:text>[</xsl:text>
        <xsl:apply-templates select="$pre/node()"/>
        <xsl:text>][</xsl:text>
        <xsl:apply-templates select="$post/node()"/>
        <xsl:text>]</xsl:text>
      </xsl:when>
      <xsl:when test="$pre">
        <xsl:text>[</xsl:text>
        <xsl:apply-templates select="$pre/node()"/>
        <xsl:text>][]</xsl:text>
      </xsl:when>
      <xsl:when test="$post">
        <xsl:text>[</xsl:text>
        <xsl:apply-templates select="$post/node()"/>
        <xsl:text>]</xsl:text>
      </xsl:when>
    </xsl:choose>

    <xsl:text>{</xsl:text>
    <xsl:value-of select="gbct:clave($b/@linkend)"/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- AGRUPAMIENTO DE CITAS CONSECUTIVAS                           -->
  <!-- LA REGLA ESTÁ EN cita-comun.xsl (gbct:grupo-desde Y SUS      -->
  <!-- AUXILIARES): LA MISMA PARA EL PDF, LA PASADA DE CITAS Y LAS  -->
  <!-- HOJAS DE HTML Y EPUB, QUE BUSCAN CADA GRUPO POR SU id.       -->
  <!-- ACÁ QUEDAN LAS DOS PLANTILLAS QUE LIMPIAN EL TEXTO ENTRE LAS -->
  <!-- PARTES DE UN GRUPO.                                          -->
  <!-- ============================================================ -->

  <!-- SEPARADOR ENTRE DOS CITAS QUE SE AGRUPARON: SE SUPRIME,      -->
  <!-- PORQUE EL DELIMITADOR LO PONE biblatex.                      -->
  <xsl:template match="text()[gbct:es-separador(.)]
      [exists(gbct:biblioref-tras-separador(.)[gbct:es-continuacion(., $estilo)])]" priority="6"/>

  <!-- ESPACIO DE INDENTACIÓN ENTRE LAS PARTES DE UNA CITA.         -->
  <!-- SE ABSORBE PARA QUE NO SALGA '(ver  García 2020)'. NO SE     -->
  <!-- USA strip-space GLOBAL PORQUE ESO BORRARÍA TAMBIÉN EL        -->
  <!-- ESPACIO LEGÍTIMO ENTRE DOS ELEMENTOS EN LÍNEA.               -->
  <xsl:template match="text()[not(normalize-space())]
      [preceding-sibling::node()[1][self::phrase[@role='cite-prefix']
                                    or self::biblioref]]
      [following-sibling::node()[1][self::biblioref
                                    or self::phrase[@role='cite-suffix']]]"
      priority="5"/>

  <!-- LA LISTA DE REFERENCIAS LA CONSTRUYE biblatex DESDE EL .bib. -->
  <!-- EL <bibliography> DEL CANÓNICO ES PARA HTML Y EPUB.          -->
  <!-- ATENCIÓN: biblatex IMPRIME LO CITADO, NO LO LISTADO. SI      -->
  <!-- ALGUNA VEZ UNA ENTRADA APARECE EN <bibliography> SIN ESTAR   -->
  <!-- CITADA, LAS DOS RAMAS DIVERGEN Y HACE FALTA UN \nocite.      -->
  <xsl:template match="bibliography"/>

  <!-- ============================================================ -->
  <!-- LISTAS                                                       -->
  <!-- ============================================================ -->

  <xsl:template match="itemizedlist">
    <xsl:text>&#10;\begin{itemize}&#10;</xsl:text>
    <xsl:apply-templates select="listitem"/>
    <xsl:text>\end{itemize}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="orderedlist">
    <xsl:text>&#10;\begin{enumerate}&#10;</xsl:text>
    <xsl:apply-templates select="listitem"/>
    <xsl:text>\end{enumerate}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="listitem">
    <xsl:variable name="c"><xsl:apply-templates/></xsl:variable>
    <xsl:text>  \item </xsl:text>
    <xsl:value-of select="f:recortar(string($c))"/>
    <xsl:text>&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="variablelist">
    <xsl:text>&#10;\begin{description}&#10;</xsl:text>
    <xsl:apply-templates select="varlistentry"/>
    <xsl:text>\end{description}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="varlistentry">
    <xsl:text>  \item[</xsl:text>
    <xsl:apply-templates select="term"/>
    <xsl:text>] </xsl:text>
    <xsl:apply-templates select="listitem/node()"/>
    <xsl:text>&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="term">
    <xsl:variable name="c"><xsl:apply-templates/></xsl:variable>
    <xsl:value-of select="f:recortar(string($c))"/>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- BLOQUES                                                      -->
  <!-- ============================================================ -->

  <!-- CITA EN BLOQUE. UNA CITA CON ATRIBUCIÓN NO ES UN EPÍGRAFE:   -->
  <!-- SON DOS COSAS DISTINTAS Y DOCBOOK LAS DISTINGUE.             -->
  <xsl:template match="blockquote">
    <xsl:text>&#10;\begin{gbcita}&#10;</xsl:text>
    <xsl:apply-templates select="* except (attribution | info | title)"/>
    <xsl:if test="attribution">
      <xsl:text>\gbatribucion{</xsl:text>
      <xsl:apply-templates select="attribution/node()"/>
      <xsl:text>}&#10;</xsl:text>
    </xsl:if>
    <xsl:text>\end{gbcita}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- EL TEXTO DEL EPÍGRAFE PUEDE SER UN VERSO (SC-49): SUS ESTROFAS   -->
  <!-- VAN EN gbversoepigrafe, DENTRO DEL PRIMER ARGUMENTO.             -->
  <xsl:template match="epigraph">
    <xsl:text>&#10;\gbepigrafe{</xsl:text>
    <xsl:choose>
      <xsl:when test="literallayout[@role = 'verse']">
        <xsl:call-template name="verso-latex">
          <xsl:with-param name="poema" select="."/>
          <xsl:with-param name="entorno" select="'gbversoepigrafe'"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:apply-templates select="* except attribution"/>
      </xsl:otherwise>
    </xsl:choose>
    <xsl:text>}{</xsl:text>
    <xsl:apply-templates select="attribution/node()"/>
    <xsl:text>}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="attribution">
    <xsl:apply-templates/>
  </xsl:template>

  <!-- RECUADROS (SC-41): LOS ARMA fenced-divs-to-elements-db.lua.     -->
  <!-- ENTORNOS gbRecuadro Y gbRecuadroBarra DE preambulo-contrato.tex  -->
  <!-- (v10). PRIORIDAD 5: POR ENCIMA DEL sidebar GENÉRICO              -->
  <xsl:template match="sidebar[@role = 'recuadro']" priority="5">
    <xsl:text>&#10;\begin{gbRecuadro}&#10;</xsl:text>
    <xsl:apply-templates select="* except (info | title)"/>
    <xsl:text>\end{gbRecuadro}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="sidebar[@role = 'recuadro-barra']" priority="5">
    <xsl:text>&#10;\begin{gbRecuadroBarra}{</xsl:text>
    <xsl:apply-templates select="(title)[1]/node()"/>
    <xsl:text>}&#10;</xsl:text>
    <xsl:apply-templates select="* except (info | title)"/>
    <xsl:text>\end{gbRecuadroBarra}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="sidebar">
    <xsl:text>&#10;\begin{gbsidebar}{</xsl:text>
    <xsl:value-of select="if (normalize-space(@role) != '')
                          then normalize-space(@role) else 'info'"/>
    <xsl:text>}&#10;</xsl:text>
    <xsl:apply-templates select="* except (info | title)"/>
    <xsl:text>\end{gbsidebar}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- VERSO (SC-49): EL ENTORNO verse DEL PAQUETE verse (CONTRATO 14). -->
  <!-- CADA VERSO TERMINA EN \\, Y EL ÚLTIMO DE CADA ESTROFA EN \\!,     -->
  <!-- QUE DEJA EL \stanzaskip; EL ÚLTIMO DEL POEMA, EN NADA. LA       -->
  <!-- SANGRÍA ES \vin UNA VEZ POR NIVEL, DELANTE DEL VERSO: NO SE USA  -->
  <!-- patverse, QUE IGNORA EL PRIMER DÍGITO DEL PATRÓN. CADA VERSO     -->
  <!-- EMPIEZA CON \relax: \\ MIRA EL CARÁCTER QUE SIGUE, Y UN VERSO    -->
  <!-- QUE EMPIEZA CON [, * O ! SE LEERÍA COMO ARGUMENTO DE \\ (GV-93). -->
  <!-- ============================================================ -->
  <xsl:template match="blockquote[@role = 'verso']" priority="5">
    <xsl:call-template name="verso-latex">
      <xsl:with-param name="poema" select="."/>
      <xsl:with-param name="entorno" select="'gbverso'"/>
    </xsl:call-template>
  </xsl:template>

  <!-- UN <literallayout role="verse"> SUELTO SOLO PUEDE SER DE UN      -->
  <!-- CANÓNICO VIEJO: SE FRENA (gbvr:frenar-si-viejo). SI NO LO FUERA, -->
  <!-- SALE COMO UN POEMA DE UNA ESTROFA.                               -->
  <xsl:template match="literallayout[@role = 'verse']" priority="5">
    <xsl:call-template name="verso-latex">
      <xsl:with-param name="poema" select="."/>
      <xsl:with-param name="entorno" select="'gbverso'"/>
    </xsl:call-template>
  </xsl:template>

  <!-- ============================================ -->
  <!-- PLANTILLA : verso-latex                      -->
  <!-- PROPÓSITO : ESCRIBE UN POEMA EN SU ENTORNO   -->
  <!-- PARÁMETROS: poema — blockquote, epigraph O   -->
  <!--             literallayout; entorno — nombre  -->
  <!--             del entorno LaTeX                -->
  <!-- ============================================ -->
  <xsl:template name="verso-latex">
    <xsl:param name="poema" as="element()"/>
    <xsl:param name="entorno" as="xs:string"/>
    <xsl:variable name="estrofas" select="if (local-name($poema) = 'literallayout')
                                          then $poema else gbvr:estrofas($poema)"/>
    <xsl:call-template name="gbvr:frenar-si-viejo">
      <xsl:with-param name="estrofas" select="$estrofas"/>
    </xsl:call-template>
    <xsl:text>&#10;\begin{</xsl:text>
    <xsl:value-of select="$entorno"/>
    <xsl:text>}&#10;</xsl:text>
    <xsl:for-each select="$estrofas">
      <xsl:variable name="ultima-estrofa" select="position() = last()"/>
      <xsl:variable name="versos" select="gbvr:versos(.)"/>
      <xsl:for-each select="$versos">
        <xsl:text>\relax</xsl:text>
        <xsl:for-each select="1 to gbvr:nivel(.)">
          <xsl:text>\vin</xsl:text>
        </xsl:for-each>
        <xsl:text> </xsl:text>
        <xsl:apply-templates/>
        <!-- FIN DE VERSO, DE ESTROFA O DEL POEMA -->
        <xsl:choose>
          <xsl:when test="position() != last()">
            <xsl:text>\\</xsl:text>
          </xsl:when>
          <xsl:when test="not($ultima-estrofa)">
            <xsl:text>\\!</xsl:text>
          </xsl:when>
        </xsl:choose>
        <xsl:text>&#10;</xsl:text>
      </xsl:for-each>
    </xsl:for-each>
    <xsl:text>\end{</xsl:text>
    <xsl:value-of select="$entorno"/>
    <xsl:text>}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="literallayout">
    <xsl:text>&#10;\begin{verbatim}&#10;</xsl:text>
    <xsl:value-of select="string(.)"/>
    <xsl:text>&#10;\end{verbatim}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- CÓDIGO (SC-42): EL BLOQUE COLOREADO LO ARMA f:codigo-latex, EN -->
  <!-- tex-comun.xsl, COMÚN CON LAS REVISTAS.                           -->
  <xsl:template match="programlisting">
    <xsl:value-of select="f:codigo-latex(.)"/>
  </xsl:template>

  <!-- LISTADO: EL BLOQUE Y, DEBAJO, EL PIE «Código N.» NUMERADO POR    -->
  <!-- PIEZA COMO LAS FIGURAS (CONTADOR gbcodigo, CONTRATO 11). EL      -->
  <!-- FILTRO GARANTIZA UN programlisting, UN title Y EL xml:id.        -->
  <xsl:template match="example[@role='listado']" priority="5">
    <xsl:value-of select="f:codigo-latex(programlisting)"/>
    <xsl:text>\gbPieCodigo{</xsl:text>
    <xsl:value-of select="@xml:id"/>
    <xsl:text>}{</xsl:text>
    <xsl:apply-templates select="(info/title, title)[1]/node()"/>
    <xsl:text>}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- LLAMADAS DE ATENCIÓN -->
  <xsl:template match="note | tip | warning | important | caution">
    <xsl:variable name="ent">
      <xsl:choose>
        <xsl:when test="self::note">gbnota</xsl:when>
        <xsl:when test="self::tip">gbconsejo</xsl:when>
        <xsl:when test="self::warning">gbadvertencia</xsl:when>
        <xsl:when test="self::important">gbimportante</xsl:when>
        <xsl:otherwise>gbprecaucion</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:text>&#10;\begin{</xsl:text>
    <xsl:value-of select="$ent"/>
    <xsl:text>}&#10;</xsl:text>
    <xsl:apply-templates select="* except (info | title)"/>
    <xsl:text>\end{</xsl:text>
    <xsl:value-of select="$ent"/>
    <xsl:text>}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- FIGURAS E IMÁGENES                                           -->
  <!-- ============================================================ -->

  <xsl:template match="figure">
    <xsl:text>&#10;\begin{figure}[!ht]&#10;\centering&#10;</xsl:text>
    <xsl:apply-templates select=".//imagedata"/>
    <xsl:if test="(info/title, title)[1]">
      <xsl:text>\caption{</xsl:text>
      <!-- EL ARGUMENTO DE \caption ES MÓVIL: SE REESCRIBE AL .lof.  -->
      <!-- LAS MACROS DE CITA DEL CONTRATO DEBEN SER ROBUSTAS, O    -->
      <!-- ESTO REVIENTA CUANDO EL TÍTULO LLEVA UN <biblioref>.     -->
      <xsl:apply-templates select="(info/title, title)[1]/node()"/>
      <xsl:text>}&#10;</xsl:text>
    </xsl:if>
    <xsl:if test="@xml:id">
      <xsl:text>\label{</xsl:text>
      <xsl:value-of select="@xml:id"/>
      <xsl:text>}&#10;</xsl:text>
    </xsl:if>
    <xsl:text>\end{figure}&#10;&#10;</xsl:text>
  </xsl:template>

  <!-- LA TAPA NO VA EN EL PDF DEL INTERIOR: SE PRODUCE APARTE, EN  -->
  <!-- OTRO PROGRAMA, CON SANGRADOS Y LOMO.                         -->
  <xsl:template match="mediaobject[@role='tapa']" priority="5"/>

  <xsl:template match="mediaobject">
    <xsl:apply-templates select=".//imagedata"/>
  </xsl:template>

  <!-- EL ANCHO: EL DE LA COLUMNA, O LA FRACCIÓN QUE PIDE @width   -->
  <!-- («60%» → 0.60\linewidth). SOLO SE TOMA LA FORMA QUE ESCRIBE   -->
  <!-- EL FILTRO, UN ENTERO DE 1 A 100 CON %: EL RNG ACEPTA          -->
  <!-- CUALQUIER TEXTO, Y OTRA FORMA LA SEÑALA EL VALIDADOR          -->
  <!-- (gbp-ancho). \linewidth Y NO \textwidth: ES IGUAL EN EL      -->
  <!-- CUERPO Y SE ADAPTA DENTRO DE UN RECUADRO                      -->
  <xsl:template match="imagedata">
    <xsl:text>\includegraphics[width=</xsl:text>
    <xsl:if test="matches(string(@width), '^([1-9][0-9]?|100)%$')">
      <xsl:value-of select="format-number(number(substring-before(@width, '%')) div 100, '0.00')"/>
    </xsl:if>
    <xsl:text>\linewidth]{</xsl:text>
    <xsl:value-of select="f:ruta-imagen(@fileref, '')"/>
    <xsl:text>}&#10;</xsl:text>
  </xsl:template>

  <!-- EL TEXTO ALTERNATIVO ES PARA HTML Y EPUB. EN PDF NO TIENE    -->
  <!-- DÓNDE IR. PRIMER CASO EN QUE UNA RAMA DESCARTA UN DATO QUE   -->
  <!-- LA OTRA USA: QUEDA ESCRITO A PROPÓSITO.                      -->
  <xsl:template match="textobject"/>

  <!-- ============================================================ -->
  <!-- TABLAS CALS                                                  -->
  <!-- ============================================================ -->
  <!-- LAS PROPORCIONES DE colwidth ('5*') SE TRADUCEN A COLUMNAS   -->
  <!-- p{} SOBRE \linewidth. SIN ESO, UNA TABLA DE NUEVE COLUMNAS   -->
  <!-- SE SALE DE LA CAJA EN CUALQUIER FORMATO DE LIBRO.            -->
  <!-- ============================================================ -->

  <!-- ============================================================ -->
  <!-- CUADRO (SC-66): EL QUE ESCRIBIÓ cuadro-armar.lua, CON SU      -->
  <!-- INSTRUCCIÓN gb-cuadro. LA COMPOSICIÓN ES LA DE gb-cuadro-latex-->
  <!-- (tex-comun.xsl), COMÚN CON LA REVISTA; ACÁ, LO QUE ES DE      -->
  <!-- DocBook: LAS FILAS, EL PIE (title Y caption), LA ROTACIÓN     -->
  <!-- (orient="land") Y LA ETIQUETA.                               -->
  <!-- ============================================================ -->
  <xsl:template match="table[processing-instruction('gb-cuadro')]" priority="2">
    <xsl:variable name="pi" select="processing-instruction('gb-cuadro')[1]"/>
    <!-- 1. LA INSTRUCCIÓN Y LA TABLA TIENEN QUE TENER LAS MISMAS COLUMNAS -->
    <xsl:if test="count(tokenize(f:pi-valor($pi, 'columnas'), ' ')) != count(tgroup/colspec)">
      <xsl:message terminate="yes">
        <xsl:text>[cuadro] LA INSTRUCCIÓN Y LA TABLA NO TIENEN LAS MISMAS COLUMNAS: </xsl:text>
        <xsl:value-of select="@xml:id"/>
      </xsl:message>
    </xsl:if>
    <!-- 2. EL PIE: TÍTULO Y NOTA -->
    <xsl:variable name="titulo"><xsl:apply-templates select="title/node()"/></xsl:variable>
    <xsl:variable name="nota">
      <xsl:for-each select="caption/para">
        <xsl:if test="position() &gt; 1"><xsl:text> </xsl:text></xsl:if>
        <xsl:apply-templates/>
      </xsl:for-each>
    </xsl:variable>
    <!-- 3. EL CUADRO -->
    <xsl:call-template name="gb-cuadro-latex">
      <xsl:with-param name="pi" select="$pi"/>
      <xsl:with-param name="encabezado" select="tgroup/thead/row"/>
      <xsl:with-param name="cuerpo" select="tgroup/tbody/row"/>
      <xsl:with-param name="rotar" select="@orient = 'land'"/>
      <xsl:with-param name="pie" select="f:cuadro-pie(string($titulo), string($nota))"/>
      <xsl:with-param name="id" select="string(@xml:id)"/>
    </xsl:call-template>
  </xsl:template>

  <xsl:template match="informaltable | table">
    <xsl:apply-templates select="tgroup"/>
  </xsl:template>

  <xsl:template match="tgroup">
    <xsl:variable name="props" as="xs:double*" select="
      for $c in colspec return
        let $w := normalize-space($c/@colwidth)
        return if (matches($w, '^[0-9.]+\*$'))
               then xs:double(replace($w, '\*$', ''))
               else 1.0"/>
    <xsl:variable name="total" select="if (sum($props) &gt; 0) then sum($props) else 1"/>
    <!-- SE DESCUENTA \tabcolsep POR COLUMNA PARA QUE LA SUMA DE     -->
    <!-- ANCHOS MÁS LOS FILETES NO EXCEDA \linewidth.               -->
    <xsl:text>&#10;\noindent\begin{tabular}{@{}</xsl:text>
    <xsl:for-each select="$props">
      <xsl:text>p{\dimexpr </xsl:text>
      <xsl:value-of select="format-number(. div $total, '0.0000')"/>
      <xsl:text>\linewidth - 2\tabcolsep\relax}</xsl:text>
    </xsl:for-each>
    <xsl:text>@{}}&#10;\toprule&#10;</xsl:text>
    <xsl:apply-templates select="thead/row"/>
    <xsl:if test="thead/row">
      <xsl:text>\midrule&#10;</xsl:text>
    </xsl:if>
    <xsl:apply-templates select="tbody/row"/>
    <xsl:text>\bottomrule&#10;\end{tabular}&#10;&#10;</xsl:text>
  </xsl:template>

  <xsl:template match="row">
    <xsl:for-each select="entry">
      <xsl:if test="position() &gt; 1">
        <xsl:text> &amp; </xsl:text>
      </xsl:if>
      <xsl:choose>
        <xsl:when test="parent::row/parent::thead">
          <xsl:text>\textbf{</xsl:text>
          <xsl:apply-templates/>
          <xsl:text>}</xsl:text>
        </xsl:when>
        <xsl:otherwise>
          <xsl:apply-templates/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:for-each>
    <xsl:text> \\&#10;</xsl:text>
  </xsl:template>

  <!-- LAS CELDAS COMBINADAS NO ESTÁN IMPLEMENTADAS. SE CORTA CON   -->
  <!-- MENSAJE EN VEZ DE EMITIR UNA TABLA CON LA CANTIDAD DE        -->
  <!-- COLUMNAS EQUIVOCADA, QUE DA UN 'Extra alignment tab' A       -->
  <!-- METROS DE LA CAUSA.                                          -->
  <xsl:template match="entry[@namest or @nameend or @morerows]" priority="5">
    <xsl:message terminate="yes">
      <xsl:text>&#10;[docbook-to-latex] CELDA COMBINADA NO IMPLEMENTADA&#10;</xsl:text>
      <xsl:text>  Se requiere \multicolumn / \multirow.&#10;</xsl:text>
    </xsl:message>
  </xsl:template>

  <xsl:template match="colspec"/>

  <!-- ============================================================ -->
  <!-- ÍNDICES ONOMÁSTICO Y DE CONCEPTOS (SC-77)                    -->
  <!-- EL indexterm QUE ESCRIBE indice.lua VUELVE A SER \index.     -->
  <!-- EL FORMATO VA SIEMPRE EXPLÍCITO, PORQUE hyperref VA CON       -->
  <!-- hyperindex=false (GV-159):                                   -->
  <!--   |hyperpage          LA PÁGINA, CON ENLACE                   -->
  <!--   |gbIndNota          DENTRO DE UNA NOTA: «23 n.»             -->
  <!--   |gbIndPrincipal     significance="preferred": EN NEGRITA     -->
  <!--   |(hyperpage |)hyperpage   EL RANGO, LOS DOS CON EL MISMO     -->
  <!--                       FORMATO: SI NO, xindy NO LO CIERRA       -->
  <!--   |see{…} |seealso{…} LAS REMISIONES, SIN PÁGINA               -->
  <!-- gbIndNota Y gbIndPrincipal LOS DECLARA gbindice.xdy: SIN ESO,  -->
  <!-- xindy DESCARTA LA PÁGINA CON UN WARNING Y NADA MÁS (GV-160).  -->
  <!-- ============================================================ -->
  <xsl:key name="indexterm-por-id" match="indexterm[@xml:id]" use="@xml:id"/>

  <!-- ============================================================ -->
  <!-- FUNCIÓN : f:indice-xindy                                     -->
  <!-- PROPÓSITO: ESCAPA PARA xindy LOS CARACTERES DE SU SINTAXIS:  -->
  <!--            ! NIVEL, @ CLAVE, | FORMATO Y " ESCAPE. CON LA    -->
  <!--            COMILLA DE xindy, QUE LLEGA LITERAL AL .idx CON   -->
  <!--            babel-spanish ACTIVO, TAMBIÉN DENTRO DE \emph Y DE -->
  <!--            \footnote (GV-160).                               -->
  <!-- PARÁMETROS: t As xs:string — texto YA ESCAPADO PARA LaTeX     -->
  <!-- RETORNA  : xs:string                                         -->
  <!-- ============================================================ -->
  <xsl:function name="f:indice-xindy" as="xs:string">
    <xsl:param name="t" as="xs:string"/>
    <xsl:sequence select="replace($t, '([&quot;!@|])', '&quot;$1')"/>
  </xsl:function>

  <!-- UN NIVEL: [CLAVE@]TEXTO. SI EL TEXTO LLEVA BASTARDILLA Y NO HAY -->
  <!-- CLAVE, LA CLAVE ES EL TEXTO PLANO: xindy ORDENA POR LO QUE VE, -->
  <!-- Y \emph{…} ORDENARÍA POR LA BARRA.                             -->
  <xsl:template match="primary | secondary | tertiary" mode="indice">
    <xsl:choose>
      <xsl:when test="@sortas">
        <xsl:value-of select="f:indice-xindy(f:latex(@sortas))"/>
        <xsl:text>@</xsl:text>
      </xsl:when>
      <xsl:when test="*">
        <xsl:value-of select="f:indice-xindy(f:latex(string(.)))"/>
        <xsl:text>@</xsl:text>
      </xsl:when>
    </xsl:choose>
    <xsl:apply-templates mode="indice"/>
  </xsl:template>

  <xsl:template match="text()" mode="indice">
    <xsl:value-of select="f:indice-xindy(f:latex(.))"/>
  </xsl:template>

  <!-- LA ÚNICA MARCA QUE ADMITE indice.lua ADENTRO DE UNA ENTRADA -->
  <xsl:template match="emphasis" mode="indice">
    <xsl:text>\emph{</xsl:text>
    <xsl:apply-templates mode="indice"/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <xsl:template match="*" mode="indice">
    <xsl:call-template name="abortar-elemento">
      <xsl:with-param name="contexto" select="'docbook-to-latex (índice)'"/>
    </xsl:call-template>
  </xsl:template>

  <!-- LA ENTRADA ENTERA: LOS NIVELES SEPARADOS POR ! -->
  <xsl:template name="indice-entrada">
    <xsl:param name="termino" as="element()"/>
    <xsl:for-each select="$termino/(primary | secondary | tertiary)">
      <xsl:if test="position() > 1">
        <xsl:text>!</xsl:text>
      </xsl:if>
      <xsl:apply-templates select="." mode="indice"/>
    </xsl:for-each>
  </xsl:template>

  <xsl:template match="indexterm">
    <!-- 1. EL FORMATO, SEGÚN LO QUE ES Y DÓNDE ESTÁ -->
    <xsl:variable name="formato" as="xs:string">
      <xsl:choose>
        <xsl:when test="see">
          <xsl:variable name="r"><xsl:apply-templates select="see/node()" mode="indice"/></xsl:variable>
          <xsl:sequence select="concat('see{', string($r), '}')"/>
        </xsl:when>
        <xsl:when test="seealso">
          <xsl:variable name="r"><xsl:apply-templates select="seealso/node()" mode="indice"/></xsl:variable>
          <xsl:sequence select="concat('seealso{', string($r), '}')"/>
        </xsl:when>
        <xsl:when test="@class = 'startofrange'">(hyperpage</xsl:when>
        <xsl:when test="@significance = 'preferred'">gbIndPrincipal</xsl:when>
        <xsl:when test="ancestor::footnote">gbIndNota</xsl:when>
        <xsl:otherwise>hyperpage</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <!-- 2. LA ORDEN -->
    <xsl:text>\index[</xsl:text>
    <xsl:value-of select="@type"/>
    <xsl:text>]{</xsl:text>
    <xsl:call-template name="indice-entrada">
      <xsl:with-param name="termino" select="."/>
    </xsl:call-template>
    <xsl:text>|</xsl:text>
    <xsl:value-of select="$formato"/>
    <xsl:text>}</xsl:text>
  </xsl:template>

  <!-- EL CIERRE DE UN RANGO NO TIENE CONTENIDO: LA ENTRADA ES LA DE SU -->
  <!-- COMIENZO, QUE ESTÁ EN LA MISMA PIEZA (indice.lua LO GARANTIZA).  -->
  <xsl:template match="indexterm[@class = 'endofrange']" priority="2">
    <xsl:variable name="inicio" select="key('indexterm-por-id', @startref)"/>
    <xsl:if test="count($inicio) != 1">
      <xsl:message terminate="yes">
        <xsl:text>&#10;[docbook-to-latex] RANGO DE ÍNDICE SIN COMIENZO: startref="</xsl:text>
        <xsl:value-of select="@startref"/>
        <xsl:text>"&#10;</xsl:text>
      </xsl:message>
    </xsl:if>
    <xsl:text>\index[</xsl:text>
    <xsl:value-of select="$inicio/@type"/>
    <xsl:text>]{</xsl:text>
    <xsl:call-template name="indice-entrada">
      <xsl:with-param name="termino" select="$inicio"/>
    </xsl:call-template>
    <xsl:text>|)hyperpage}</xsl:text>
  </xsl:template>

  <!-- ============================================================ -->
  <!-- CAPTURA DE VOCABULARIO NO PREVISTO                           -->
  <!-- ABORTA. VER LA RAZÓN EN tex-comun.xsl.                       -->
  <!-- ============================================================ -->
  <xsl:template match="*" priority="-1">
    <xsl:call-template name="abortar-elemento">
      <xsl:with-param name="contexto" select="'docbook-to-latex'"/>
    </xsl:call-template>
  </xsl:template>

</xsl:stylesheet>
