#!/usr/bin/env bash
#
# ============================================
# Script    : crear-cuenta-gbweb.sh
# Propósito : Crea o pone en regla la cuenta de MySQL con la que gbWeb lee
#             la base de gbpublisher (SC-81), y deja su credencial en
#             ~/.gbweb/conexion.conf (decisiones de Alberto, 02/11/2026):
#               1. Cuenta 'gbweb_lector'@'localhost', con SELECT solo
#                  sobre las cuatro VIEW del contrato. Cualquier otra cosa
#                  le da error 1142 (GV-167): el aislamiento lo garantiza
#                  el motor.
#               2. La clave la genera el script: nadie la tipea ni la
#                  recuerda, y no queda en ningún repositorio.
#               3. ~/.gbweb/conexion.conf, con permisos 600, en formato de
#                  archivo de opciones de MySQL ([client]): el propio
#                  cliente mysql lo lee con --defaults-extra-file, y gbWeb
#                  solo necesita sus cuatro líneas.
#             NO es un cambio de esquema: no toca la base gbpublisher, no
#             hace respaldo ni registra nada en esquema_version. Toca las
#             cuentas del servidor y un archivo de la carpeta del usuario.
# Uso       : bash crear-cuenta-gbweb.sh      (SIN sudo: lo pide solo)
#             Sin sudo porque el archivo de la credencial es del usuario
#             que va a correr gbWeb, en SU carpeta personal.
# Requisitos: MySQL 8; actualización 1.19.0 de gbpublisher aplicada.
# Reglas    : IDEMPOTENTE. Decide por el estado real (la cuenta, sus
#             permisos y si la clave del archivo abre la sesión). Sin
#             efecto si todo está en regla. Verificación posterior.
# ============================================

set -euo pipefail

# --- 0. CONFIGURACIÓN ---
DB="gbpublisher"
CUENTA="gbweb_lector"
HOST_CUENTA="localhost"
VISTAS=(v_web_libro v_web_libro_persona v_web_coleccion v_web_libro_tapa)
DIR_CONF="${HOME}/.gbweb"
CONF="${DIR_CONF}/conexion.conf"
PARCHE_REQUERIDO="actualizacion-1.19.0"

if [ -t 1 ]; then
  ROJO=$'\e[0;31m'; VERDE=$'\e[0;32m'; AMBAR=$'\e[0;33m'
  AZUL=$'\e[0;34m'; NEGRITA=$'\e[1m'; RESET=$'\e[0m'
else
  ROJO=""; VERDE=""; AMBAR=""; AZUL=""; NEGRITA=""; RESET=""
fi

info()  { echo "${AZUL}➜${RESET} $*"; }
ok()    { echo "${VERDE}✔${RESET} $*"; }
warn()  { echo "${AMBAR}⚠${RESET} $*"; }
error() { echo "${ROJO}✖${RESET} $*" >&2; }

# CUENTA ADMINISTRATIVA DEL SERVIDOR (BBDD_LEEME.md §2)
mysql_adm() {
  sudo mysql --default-character-set=utf8mb4 "$@"
}

# -r (raw): SIN ÉL, EL MODO -B DUPLICA LAS BARRAS DE UN VALOR CON APÓSTROFO
valor() {
  mysql_adm -N -B -r -e "$1"
}

# LA CUENTA DE gbWeb, CON LA CREDENCIAL DEL ARCHIVO. --defaults-extra-file
# DEBE SER LA PRIMERA OPCIÓN DE LA LÍNEA
como_lector() {
  mysql --defaults-extra-file="$CONF" -N -B -r "$@"
}

# PERMISOS DE LA CUENTA, EN LAS TRES TABLAS DE information_schema
GRANTEE="'${CUENTA}'@'${HOST_CUENTA}'"
permisos_de_tabla() {
  valor "SELECT COUNT(*) FROM information_schema.TABLE_PRIVILEGES WHERE GRANTEE=\"${GRANTEE}\";"
}
permisos_esperados() {
  local LISTA
  LISTA="$(printf "'%s'," "${VISTAS[@]}")"
  valor "SELECT COUNT(*) FROM information_schema.TABLE_PRIVILEGES WHERE GRANTEE=\"${GRANTEE}\" AND TABLE_SCHEMA='${DB}' AND PRIVILEGE_TYPE='SELECT' AND TABLE_NAME IN (${LISTA%,});"
}
permisos_de_base() {
  valor "SELECT COUNT(*) FROM information_schema.SCHEMA_PRIVILEGES WHERE GRANTEE=\"${GRANTEE}\";"
}
permisos_globales() {
  valor "SELECT COUNT(*) FROM information_schema.USER_PRIVILEGES WHERE GRANTEE=\"${GRANTEE}\" AND PRIVILEGE_TYPE <> 'USAGE';"
}

# --- 1. BIENVENIDA ---
echo
echo "${NEGRITA}Cuenta de lectura de gbWeb${RESET}"
echo "--------------------------"
echo "Crea o pone en regla la cuenta ${CUENTA}, que solo puede leer las"
echo "cuatro vistas del contrato con gbWeb, y guarda su clave en"
echo "${CONF}."
echo

# --- 2. VERIFICACIONES PREVIAS ---
# EL ARCHIVO DE LA CREDENCIAL ES DEL USUARIO DE gbWeb: CON sudo IRÍA A /root
if [ "$(id -u)" -eq 0 ]; then
  error "Corré el script sin sudo: la clave se guarda en tu carpeta personal. El script pide sudo cuando lo necesita."
  exit 1
fi

for P in mysql sudo tr head; do
  if ! command -v "$P" >/dev/null 2>&1; then
    error "Falta el programa ${P}."
    exit 1
  fi
done

if ! sudo -v; then
  error "No se pudieron obtener permisos de administrador (sudo)."
  exit 1
fi

if ! mysql_adm -e "SELECT 1;" >/dev/null 2>&1; then
  error "No se pudo conectar al servidor con la cuenta administrativa."
  exit 1
fi

# LAS VIEW LAS CREA LA 1.19.0 DE gbpublisher: SIN ELLA NO HAY QUÉ PERMITIR
if [ "$(valor "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA='${DB}' AND TABLE_NAME='esquema_version';")" != "1" ] \
   || [ "$(valor "SELECT COUNT(*) FROM \`${DB}\`.esquema_version WHERE parche='${PARCHE_REQUERIDO}';")" != "1" ]; then
  error "Falta la actualización 1.19.0 de gbpublisher (actualizar-esquema-1.19.0.sh). No se modificó nada."
  exit 1
fi

for V in "${VISTAS[@]}"; do
  if [ "$(valor "SELECT TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA='${DB}' AND TABLE_NAME='${V}';")" != "VIEW" ]; then
    error "No existe la vista ${V}. No se modificó nada."
    exit 1
  fi
done

info "Servidor: $(valor "SELECT VERSION();")"

# --- 3. ESTADO REAL ---
EXISTE_CUENTA="$(valor "SELECT COUNT(*) FROM mysql.user WHERE User='${CUENTA}' AND Host='${HOST_CUENTA}';")"

# LA CLAVE DEL ARCHIVO ABRE LA SESIÓN: ES LA PRUEBA, NO SU EXISTENCIA
CLAVE_VALIDA=0
if [ "$EXISTE_CUENTA" = "1" ] && [ -f "$CONF" ]; then
  if como_lector -e "SELECT 1;" >/dev/null 2>&1; then
    CLAVE_VALIDA=1
  fi
fi

# PERMISOS EN REGLA: LAS CUATRO VIEW Y NADA MÁS
PERMISOS_OK=0
if [ "$EXISTE_CUENTA" = "1" ] \
   && [ "$(permisos_esperados)" = "${#VISTAS[@]}" ] \
   && [ "$(permisos_de_tabla)" = "${#VISTAS[@]}" ] \
   && [ "$(permisos_de_base)" = "0" ] \
   && [ "$(permisos_globales)" = "0" ]; then
  PERMISOS_OK=1
fi

CREAR=0; RENOVAR=0; REPONER_PERMISOS=0
if [ "$EXISTE_CUENTA" = "0" ]; then
  CREAR=1
  REPONER_PERMISOS=1
  info "Se crea la cuenta ${CUENTA}@${HOST_CUENTA} con una clave nueva."
  [ -f "$CONF" ] && warn "Se reemplaza ${CONF}: su clave no corresponde a ninguna cuenta."
else
  if [ "$CLAVE_VALIDA" = "0" ]; then
    RENOVAR=1
    if [ -f "$CONF" ]; then
      warn "La clave de ${CONF} no abre la sesión: se renueva."
    else
      warn "La cuenta existe pero falta ${CONF}: se renueva la clave."
    fi
  fi
  if [ "$PERMISOS_OK" = "0" ]; then
    REPONER_PERMISOS=1
    warn "Los permisos de la cuenta no son exactamente las cuatro vistas: se reponen."
  fi
fi

if [ $(( CREAR + RENOVAR + REPONER_PERMISOS )) -eq 0 ]; then
  ok "La cuenta, sus permisos y la clave del archivo están en regla. No hay nada que hacer."
  SOLO_INFORME=1
else
  SOLO_INFORME=0
  echo
  read -r -p "Para continuar, escribí SI en mayúsculas: " RESPUESTA
  if [ "$RESPUESTA" != "SI" ]; then
    warn "Cancelado. No se modificó nada."
    exit 0
  fi
fi

if [ "$SOLO_INFORME" -eq 0 ]; then

  # --- 4. CLAVE NUEVA ---
  if [ "$CREAR" -eq 1 ] || [ "$RENOVAR" -eq 1 ]; then
    # 28 CARACTERES ALEATORIOS, SOLO LETRAS Y CIFRAS: NO NECESITAN COMILLAS
    # EN EL ARCHIVO DE OPCIONES. EL SUFIJO FIJO DA MAYÚSCULA, MINÚSCULA,
    # CIFRA Y UN SÍMBOLO, POR SI EL SERVIDOR TIENE validate_password
    # (NO VERIFICADO EN EL SERVIDOR DE ALBERTO)
    # SE LEE UN BLOQUE ACOTADO Y SE CORTA CON bash: CON tr … | head, head
    # CIERRA EL CAÑO, tr MUERE POR SIGPIPE Y pipefail ABORTA EL SCRIPT
    # (MEDIDO: SALIDA 141 ANTES DE CREAR LA CUENTA)
    ALEATORIO="$(head -c 4096 /dev/urandom | LC_ALL=C tr -dc 'A-Za-z0-9')"
    if [ "${#ALEATORIO}" -lt 28 ]; then
      error "No se pudo generar la clave. No se modificó nada."
      exit 1
    fi
    CLAVE="${ALEATORIO:0:28}Aa9_"
    unset ALEATORIO

    # LA CLAVE VIAJA POR LA ENTRADA ESTÁNDAR, NO POR LA LÍNEA DE COMANDOS:
    # ASÍ NO APARECE EN LA LISTA DE PROCESOS
    if [ "$CREAR" -eq 1 ]; then
      printf "CREATE USER '%s'@'%s' IDENTIFIED BY '%s';\n" "$CUENTA" "$HOST_CUENTA" "$CLAVE" | mysql_adm
      ok "Creada la cuenta ${CUENTA}@${HOST_CUENTA}."
    else
      printf "ALTER USER '%s'@'%s' IDENTIFIED BY '%s';\n" "$CUENTA" "$HOST_CUENTA" "$CLAVE" | mysql_adm
      ok "Renovada la clave de ${CUENTA}@${HOST_CUENTA}."
    fi

    # EL ARCHIVO SE ESCRIBE CON PERMISOS 600 DESDE EL PRIMER BYTE (umask)
    # Y SE MUEVE ENTERO: NUNCA QUEDA A MEDIO ESCRIBIR
    mkdir -p "$DIR_CONF"
    chmod 700 "$DIR_CONF"
    TMP="$(umask 077; mktemp "${DIR_CONF}/.conexion.XXXXXX")"
    {
      echo "# CREDENCIAL DE gbWeb PARA LEER gbpublisher (SC-81)"
      echo "# LA ESCRIBE crear-cuenta-gbweb.sh; NO SE EDITA A MANO"
      echo "[client]"
      echo "user=${CUENTA}"
      echo "password=${CLAVE}"
      echo "host=${HOST_CUENTA}"
      echo "database=${DB}"
    } > "$TMP"
    chmod 600 "$TMP"
    mv -f "$TMP" "$CONF"
    unset CLAVE
    ok "Guardada la clave en ${CONF} (permisos 600)."
  fi

  # --- 5. PERMISOS: LAS CUATRO VIEW Y NADA MÁS ---
  if [ "$REPONER_PERMISOS" -eq 1 ]; then
    # SE QUITA TODO Y SE DA LO JUSTO: EL RESULTADO NO DEPENDE DE LO QUE HABÍA
    mysql_adm -e "REVOKE ALL PRIVILEGES, GRANT OPTION FROM ${GRANTEE};"
    for V in "${VISTAS[@]}"; do
      mysql_adm -e "GRANT SELECT ON \`${DB}\`.\`${V}\` TO ${GRANTEE};"
    done
    ok "Permisos: SELECT sobre las ${#VISTAS[@]} vistas."
  fi

  # --- 6. VERIFICACIÓN POSTERIOR ---
  FALLA=0
  if ! como_lector -e "SELECT COUNT(*) FROM v_web_libro;" >/dev/null 2>&1; then
    error "La cuenta no puede leer v_web_libro con la clave del archivo."
    FALLA=1
  fi
  # TIENE QUE FALLAR: SI LEE UNA TABLA, EL AISLAMIENTO NO ESTÁ (GV-167)
  if como_lector -e "SELECT 1 FROM libros_md LIMIT 1;" >/dev/null 2>&1; then
    error "La cuenta puede leer libros_md: el aislamiento no funciona."
    FALLA=1
  fi
  VISIBLES="$(como_lector -e "SHOW TABLES;" 2>/dev/null | sort | tr '\n' ' ')"
  ESPERADAS="$(printf '%s\n' "${VISTAS[@]}" | sort | tr '\n' ' ')"
  if [ "$VISIBLES" != "$ESPERADAS" ]; then
    error "La cuenta ve otros objetos además de las vistas: ${VISIBLES}"
    FALLA=1
  fi
  if [ "$(stat -c '%a' "$CONF")" != "600" ]; then
    error "${CONF} no quedó con permisos 600."
    FALLA=1
  fi

  if [ "$FALLA" -ne 0 ]; then
    error "La cuenta no quedó en regla. Revisala antes de usar gbWeb."
    exit 1
  fi
  ok "Verificación correcta: lee las cuatro vistas y ninguna tabla."
fi

# --- 7. INFORME DE CONTROL (SOLO LECTURA) ---
echo
info "Informe de control"
echo "  Cuenta  : ${CUENTA}@${HOST_CUENTA}"
echo "  Archivo : ${CONF} ($(stat -c '%a' "$CONF"))"
echo "  Ve      : $(como_lector -e "SHOW TABLES;" 2>/dev/null | tr '\n' ' ')"
echo "  Libros  : $(como_lector -e "SELECT COUNT(*) FROM v_web_libro;" 2>/dev/null) visibles"
echo "El informe no modifica nada."
echo
ok "${NEGRITA}Cuenta de gbWeb lista.${RESET}"
