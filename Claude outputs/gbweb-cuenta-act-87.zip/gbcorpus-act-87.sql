-- ============================================================
-- gbCorpus — actualización 87: la cuenta de lectura de gbWeb
-- Esquema: 2
-- Origen: conversación del 02/11/2026. Decisiones de Alberto: la cuenta
--         gbweb_lector la crea un script del repositorio de gbWeb
--         (privado), y la clave la genera el script y la guarda en
--         ~/.gbweb/conexion.conf. crear-cuenta-gbweb.sh probado en el
--         contenedor (MySQL 8.0.46, usuario común con sudo) en siete
--         situaciones; falta correrlo en Linux Mint.
-- Fecha:  2026-11-02
-- Aplicar: después de act-86
--
-- ALTAS:
--   GV-170   bash: tr | head con pipefail termina con 141
--
-- MODIFICA:
--   SC-81    LA CUENTA: el script, la clave y el archivo; pendientes
--            (sale el script de la cuenta y la capa en BBDD_LEEME.md)
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA: act-86 APLICADA Y LOS CÓDIGOS LIBRES
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-86 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 86;
INSERT INTO verificacion SELECT 'GV-169 última GV', MAX(numero) = 169 FROM entradas WHERE prefijo = 'GV';
INSERT INTO verificacion SELECT 'GV-170 libre', COUNT(*) = 0 FROM entradas WHERE codigo = 'GV-170' OR (prefijo = 'GV' AND numero = 170);
INSERT INTO verificacion SELECT 'SC-81 con el párrafo de la cuenta', (length(cuerpo) - length(replace(cuerpo, 'La crea la cuenta administrativa en un script aparte, no en el de esquema: tener gbWeb es una decisión de cada instalación.', ''))) = length('La crea la cuenta administrativa en un script aparte, no en el de esquema: tener gbWeb es una decisión de cada instalación.') FROM entradas WHERE codigo = 'SC-81';
INSERT INTO verificacion SELECT 'SC-81 con el pendiente del script', instr(pendiente, 'Script de la cuenta `gbweb_lector` (pide la clave sin mostrarla; idempotente) y la cuarta capa de identidad en BBDD_LEEME.md §2. ') = 1 FROM entradas WHERE codigo = 'SC-81';

-- ------------------------------------------------------------
-- 2. GV-170
-- ------------------------------------------------------------
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('GV', 170, 'GV-170', 'bash: con pipefail, tr … </dev/urandom | head -c N termina con 141 (SIGPIPE) y set -e aborta el script',
   '`head` termina apenas tiene sus N bytes y cierra el caño; `tr`, que sigue leyendo de `/dev/urandom` (que no se acaba nunca), muere por SIGPIPE al escribir. Con `set -o pipefail`, el estado del caño es el de `tr`, 141; con `set -e`, el script termina ahí, sin mensaje propio.

MEDIDO (GNU bash 5.2.21, contenedor): `crear-cuenta-gbweb.sh` con

    CLAVE="$(LC_ALL=C tr -dc ''A-Za-z0-9'' </dev/urandom | head -c 28)Aa9_"

anunció «Se crea la cuenta…», recibió la confirmación y salió con 141 antes de crearla.

FORMA CORRECTA: leer un bloque acotado, que `tr` consume entero, y cortar con bash:

    ALEATORIO="$(head -c 4096 /dev/urandom | LC_ALL=C tr -dc ''A-Za-z0-9'')"
    CLAVE="${ALEATORIO:0:28}Aa9_"

Acá el que corta es `head` leyendo de un archivo, que no recibe SIGPIPE. Conviene controlar el largo (4096 bytes al azar dan unas 990 letras y cifras).

EN EL PROYECTO: `crear-cuenta-gbweb.sh` (SC-81). Vale para cualquier caño con `head` dentro de un script con `set -euo pipefail`, que es el encabezado de los scripts de esquema (SC-22).',
   'vigente', 'empirica', 'GNU bash 5.2.21 / contenedor Ubuntu 24.04',
   '2026-11', 'apoya:SC-81,vinculo:SC-22', NULL, 1700, datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO verificacion SELECT 'GV-170 alta', COUNT(*) = 1 FROM entradas WHERE codigo = 'GV-170';

-- ------------------------------------------------------------
-- 3. SC-81: LA CUENTA Y LOS PENDIENTES
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo,
'La crea la cuenta administrativa en un script aparte, no en el de esquema: tener gbWeb es una decisión de cada instalación.',
'La crea `crear-cuenta-gbweb.sh`, en el repositorio de gbWeb (privado), no el script de esquema: tener gbWeb es una decisión de cada instalación, y gbWeb es de uso casi exclusivo de la editorial.

- Se corre SIN sudo y lo pide cuando lo necesita: la credencial es del usuario que va a correr gbWeb y va a su carpeta personal. Con sudo se niega.
- La clave la genera el script (decisión de Alberto, 02/11/2026): 28 letras y cifras al azar más un sufijo fijo con mayúscula, minúscula, cifra y símbolo, por si el servidor tiene `validate_password`. Nadie la tipea ni la recuerda, y no queda en ningún repositorio. Viaja al servidor por la entrada estándar, no por la línea de comandos.
- La guarda en `~/.gbweb/conexion.conf` (carpeta 700, archivo 600), escrito entero y movido a su lugar. Es un archivo de opciones de MySQL: `[client]` con `user`, `password`, `host` y `database`. El propio cliente lo lee con `mysql --defaults-extra-file`, y gbWeb solo necesita esas cuatro líneas.
- Idempotente, por el estado real: la cuenta existe; sus permisos son exactamente SELECT sobre las cuatro VIEW (en `information_schema`: `TABLE_PRIVILEGES`, `SCHEMA_PRIVILEGES` y `USER_PRIVILEGES`); la clave del archivo abre la sesión. Lo que no está en regla se corrige: crea la cuenta, renueva la clave (`ALTER USER`) o repone los permisos (`REVOKE ALL PRIVILEGES, GRANT OPTION` y los cuatro `GRANT`). Si todo está en regla, no hace nada.
- Verifica con la clave del archivo: lee `v_web_libro`, NO lee `libros_md` y ve solo las cuatro VIEW (GV-167).
- No es un cambio de esquema: no toca la base gbpublisher, no hace respaldo ni escribe en `esquema_version`.

Probado en el contenedor con un usuario común y sudo, en siete situaciones: primera corrida, segunda, archivo borrado, un permiso de más, clave equivocada, cuenta borrada con archivo viejo y una corrida más con todo en regla.'),
       pendiente = replace(pendiente, 'Script de la cuenta `gbweb_lector` (pide la clave sin mostrarla; idempotente) y la cuarta capa de identidad en BBDD_LEEME.md §2. ', ''),
       relaciones = relaciones || ',apoya:GV-170',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-81';
INSERT INTO verificacion SELECT 'SC-81 con crear-cuenta-gbweb.sh', instr(cuerpo, 'La crea `crear-cuenta-gbweb.sh`') > 0 FROM entradas WHERE codigo = 'SC-81';
INSERT INTO verificacion SELECT 'SC-81 sin el pendiente del script', instr(pendiente, 'Script de la cuenta') = 0 FROM entradas WHERE codigo = 'SC-81';
INSERT INTO verificacion SELECT 'SC-81 pendiente empieza por el baseline', instr(pendiente, '`generar-baseline.sh`') = 1 FROM entradas WHERE codigo = 'SC-81';

COMMIT;

SELECT codigo, titulo, fecha_modificacion FROM entradas
 WHERE codigo IN ('SC-81','GV-170')
 ORDER BY codigo;
