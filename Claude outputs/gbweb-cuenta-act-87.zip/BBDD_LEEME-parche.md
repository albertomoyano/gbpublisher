# Parche de BBDD_LEEME.md (gbpublisher): la cuenta de lectura de gbWeb

Tres reemplazos en la sección 2. Cada bloque a reemplazar aparece una sola
vez en el archivo (verificado contra la copia de tu disco).

## 1. En el archivo BBDD_LEEME.md, en el título de la sección 2

Reemplazar:

```
## 2. Las tres capas de identidad
```

por:

```
## 2. Las capas de identidad
```

## 2. En el archivo BBDD_LEEME.md, sección 2, primer párrafo

Reemplazar:

```
dejarla clara de entrada. Hay tres cosas distintas que suelen mezclarse:
```

por:

```
dejarla clara de entrada. Hay tres cosas distintas que suelen mezclarse, y
una cuarta donde se usa gbWeb:
```

## 3. En el archivo BBDD_LEEME.md, sección 2, después del párrafo de la cuenta administrativa

Reemplazar:

```
`app_user` no puede reemplazarla: no tiene permisos para modificar
estructuras.
```

por:

```
`app_user` no puede reemplazarla: no tiene permisos para modificar
estructuras.

**La cuenta de lectura de gbWeb (`gbweb_lector`).** Es una cuenta de
MySQL, como `app_user`, pero de otra aplicación: gbWeb, el portal estático
de la editorial. Solo puede leer las cuatro vistas `v_web_*` que crea la
actualización 1.19.0; cualquier tabla le está vedada. No la crea este
instalador: existe solo donde se usa gbWeb, y la crea
`crear-cuenta-gbweb.sh`, del repositorio de gbWeb, que guarda su clave en
`~/.gbweb/conexion.conf`.
```
