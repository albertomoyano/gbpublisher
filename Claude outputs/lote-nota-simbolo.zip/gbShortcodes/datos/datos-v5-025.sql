-- ============================================================
-- datos-v5-025: nota con símbolo en un título de sección (SC-86)
-- ------------------------------------------------------------
-- Da de alta:
--   nota-simbolo, nota con símbolo en línea, grupo comun, orden 80,
--   modo plantilla: inserta \footnote{•}{} con el marcador
--   seleccionado. Solo libros por ahora (decisión de Alberto, 11/11:
--   las revistas, después de su refactorización). En borrador hasta
--   probarla en Mint.
-- Requiere gbpublisher con nota-simbolo.lua en la cadena del libro,
-- cite-to-biblioref-db.lua que escribe <footnote label>, las tres hojas
-- del libro con nota-simbolo-comun.xsl y el contrato 22.
-- Después: reexportar el catálogo (SC-34).
-- Esquema: 5
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE _verif (paso TEXT, ok INTEGER CHECK (ok = 1));

-- --- 1. PRECONDICIONES ---
-- EL NOMBRE Y LA CLASE ESTÁN LIBRES; EL ORDEN 80 DEL GRUPO, TAMBIÉN; EL
-- MODO plantilla EN LÍNEA EXISTE
INSERT INTO _verif SELECT 'nota-simbolo libre', COUNT(*) = 0 FROM shortcodes
  WHERE nombre = 'nota-simbolo' OR clase = 'nota-simbolo';
INSERT INTO _verif SELECT 'orden 80 libre', COUNT(*) = 0 FROM shortcodes
  WHERE grupo = 'comun' AND tipo = 'linea' AND orden = 80;
INSERT INTO _verif SELECT 'modo plantilla en línea', COUNT(*) = 1 FROM modos
  WHERE modo = 'plantilla' AND tipo = 'linea';

-- --- 2. NOTA-SIMBOLO ---
-- ORDEN 80: DESPUÉS DE LAS MARCAS DE ÍNDICE (60 Y 70)
INSERT INTO shortcodes (nombre, clase, etiqueta, tipo, grupo, perfil, orden, estado_libro, estado_revista, modo, apertura, cierre, que_es, ejemplo, como_sale, mapeo_docbook, mapeo_jats, notas, pendiente, fecha_alta, fecha_modificacion)
VALUES ('nota-simbolo', 'nota-simbolo', 'Nota con símbolo en un título (*, †)', 'linea', 'comun', NULL, 80, 'borrador', 'no_aplica', 'plantilla', '\footnote{', '}{}',
        'Una nota al pie de un título de sección que lleva un símbolo en lugar de número, como `\Footnote{}{}` en LaTeX (consejo de la AMS). No consume número: las demás notas siguen 1, 2, 3. Es de libros, por ahora.

Se escribe pegada al título: el símbolo en el primer par de llaves y el texto de la nota en el segundo, que admite bastardilla, citas y las demás marcas del texto. Se ubica el cursor al final del título y se inserta: queda `\footnote{•}{}` con el marcador seleccionado; encima se escribe el símbolo y, en el segundo par, el texto.

Los símbolos son `*`, `\dag` (†), `\ddag` (‡), `\S` (§), `\P` (¶), `**`, `\dag\dag` (††) y `\ddag\ddag` (‡‡). Quien edita elige cuál: el mismo puede volver en otra página, nunca dos veces en la misma. Va una sola nota por título, numerada o con símbolo.',
        '## La edición universitaria\footnote{*}{Versión revisada de la ponencia leída en las *Jornadas de Edición*, 2025.}',
        'En el PDF, el símbolo en la apertura del título, sin corchetes, y la nota al pie con el mismo símbolo. El sumario, el folio y los marcadores llevan el título sin la nota. La llamada de un título no tiene vínculo en el PDF.

En el HTML, el símbolo con su vínculo y la nota en el panel lateral, como «Nota *». En el EPUB, el símbolo con su vínculo y la nota en la lista del capítulo, encabezada por el mismo símbolo.

Un símbolo fuera de la lista, un solo par de llaves, un espacio entre los dos, la nota partida en dos líneas, el texto vacío, otra nota en el mismo título o la nota fuera de un título de sección detienen la conversión con un mensaje que dice qué falla.',
        '<footnote label="ast"> (y dag, ddag, S, P, ast2, dag2, ddag2): label es NMTOKEN, va el nombre del símbolo (GV-191, SC-86)',
        NULL,
        'Filtro nota-simbolo.lua en la cadena del libro, después de volada.lua y antes de corte-titulo.lua: reconstruye la nota desde lo que deja Pandoc (GV-189) y la marca con <?gb-nota-simbolo …?>; cite-to-biblioref-db.lua pasa la marca a <footnote label>. docbook-to-latex.xsl: \gbNotaTituloSimbolo{N}{…} (contrato 22, \footnote[1000+N], GV-190). HTML y EPUB: el signo de nota-simbolo-comun.xsl, ids s1, s2… Revistas: no_aplica hasta su refactorización (SC-86).',
        'Probar en Mint con un libro: la inserción desde el panel, la ayuda con el ejemplo coloreado, el PDF, el HTML y el EPUB del documento de prueba, y un caso que frene.',
        datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO _verif SELECT 'nota-simbolo escrita', COUNT(*) = 1 FROM shortcodes
  WHERE nombre = 'nota-simbolo' AND tipo = 'linea' AND grupo = 'comun' AND modo = 'plantilla'
    AND apertura = '\footnote{' AND cierre = '}{}'
    AND estado_libro = 'borrador' AND estado_revista = 'no_aplica';

DROP TABLE _verif;

COMMIT;

SELECT nombre, etiqueta, tipo, grupo, orden, modo, apertura, cierre, estado_libro, estado_revista
  FROM shortcodes WHERE nombre = 'nota-simbolo';
