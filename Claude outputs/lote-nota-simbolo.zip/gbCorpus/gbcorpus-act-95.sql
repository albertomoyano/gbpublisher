-- ============================================================
-- gbCorpus — actualización 95: nota con símbolo en un título de
--            sección (SC-86), una nota por título (SC-29)
-- Esquema: 2
-- Origen: conversación del 11/11/2026. Decisiones de Alberto: se reabre
--         la renuncia de SC-29; \footnote{símbolo}{texto} en el .md, con
--         el diccionario de la AMS sin ‖; el símbolo lo elige quien edita,
--         sin contador; una nota por título y, si hay más, frena; la
--         llamada de un título sin vínculo en el PDF; solo libros por
--         ahora (las revistas, después de su refactorización).
-- Fecha:  2026-11-11
-- Aplicar: después de act-94. Va con el lote de gbpublisher
--          (lote-nota-simbolo) y con gbShortcodes datos-v5-025.sql.
--
-- ALTAS:
--   SC-86   Nota con símbolo en un título de sección
--   GV-189  Pandoc: \footnote{x}{y} en Markdown
--   GV-190  titlesec 2.16: una sola nota por título, texto diferido
--   GV-191  DocBook 5.2: footnote/@label es NMTOKEN
--
-- MODIFICA:
--   SC-29   título; LA MARCA ES NUMÉRICA pasa a UNA NOTA POR TÍTULO y
--           LA MARCA; relaciones
--   SC-54   la tabla de controles: \footnote en latex_en_linea y
--           nota_doble_en_titulo; relaciones
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA: act-94 APLICADA, CÓDIGOS LIBRES, TEXTOS UNA VEZ
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-94 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 94;
INSERT INTO verificacion SELECT 'SC-85 última SC', MAX(numero) = 85 FROM entradas WHERE prefijo = 'SC';
INSERT INTO verificacion SELECT 'GV-188 última GV', MAX(numero) = 188 FROM entradas WHERE prefijo = 'GV';
INSERT INTO verificacion SELECT 'SC-86 libre', COUNT(*) = 0 FROM entradas WHERE prefijo = 'SC' AND numero = 86;
INSERT INTO verificacion SELECT 'GV-189 a 191 libres', COUNT(*) = 0 FROM entradas WHERE prefijo = 'GV' AND numero IN (189, 190, 191);
INSERT INTO verificacion SELECT 'SC-29 título', titulo = 'Notas al pie en títulos de sección: marca numérica y dos versiones del título' FROM entradas WHERE codigo = 'SC-29';
INSERT INTO verificacion SELECT 'SC-29 relaciones', relaciones = 'vinculo:SC-28,apoya:GV-70' FROM entradas WHERE codigo = 'SC-29';
INSERT INTO verificacion SELECT 'SC-29 marca numérica una vez', (length(cuerpo) - length(replace(cuerpo, 'LA MARCA ES NUMÉRICA

La nota del título se numera con las demás, en el orden del texto. Se renuncia a la marca con asterisco u otro signo que en LaTeX da `\Footnote{}{}` (consejo de la AMS: no poner números en títulos ni fórmulas). Markdown no tiene forma de expresarla, y la confusión que se buscaba evitar la compensan los corchetes del PDF y el hipervínculo de EPUB y HTML.', ''))) = length('LA MARCA ES NUMÉRICA

La nota del título se numera con las demás, en el orden del texto. Se renuncia a la marca con asterisco u otro signo que en LaTeX da `\Footnote{}{}` (consejo de la AMS: no poner números en títulos ni fórmulas). Markdown no tiene forma de expresarla, y la confusión que se buscaba evitar la compensan los corchetes del PDF y el hipervínculo de EPUB y HTML.') FROM entradas WHERE codigo = 'SC-29';
INSERT INTO verificacion SELECT 'SC-54 latex_en_linea una vez', (length(cuerpo) - length(replace(cuerpo, '                                      de las admitidas: \sptext, \num, \SI,
                                      \SIrange, \index (GV-116, SC-77);', ''))) = length('                                      de las admitidas: \sptext, \num, \SI,
                                      \SIrange, \index (GV-116, SC-77);') FROM entradas WHERE codigo = 'SC-54';
INSERT INTO verificacion SELECT 'SC-54 cifra_fuera_de_num una vez', (length(cuerpo) - length(replace(cuerpo, '    cifra_fuera_de_num        aviso   una cifra con punto o coma de miles fuera
                                      de \num (SC-64, SC-65)
', ''))) = length('    cifra_fuera_de_num        aviso   una cifra con punto o coma de miles fuera
                                      de \num (SC-64, SC-65)
') FROM entradas WHERE codigo = 'SC-54';
INSERT INTO verificacion SELECT 'SC-54 relaciones', relaciones = 'vinculo:SC-53,vinculo:SC-46,vinculo:SC-11,vinculo:SC-13,apoya:GV-99,vinculo:SC-30,vinculo:SC-32,vinculo:GV-116,vinculo:SC-62,vinculo:SC-39,vinculo:SC-63,vinculo:SC-65,apoya:GV-124,vinculo:SC-75,vinculo:SC-77' FROM entradas WHERE codigo = 'SC-54';

-- ------------------------------------------------------------
-- 2. ALTAS
-- ------------------------------------------------------------
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('GV', 189, 'GV-189', 'Pandoc 3.1.3: \footnote{x}{y} en Markdown — el primer par de llaves es LaTeX crudo y el segundo, Markdown con las llaves como texto',
   'Medido con Pandoc 3.1.3, lector markdown, sin filtros:

    en el .md                                      resultado
    ## A\footnote{*}{Texto *cursiva* [@c].}         RawInline tex "\footnote{*}", Str "{Texto", Emph, Cite, Str ".}"
    ## A\footnote{\dag\dag}{x}                   RawInline tex "\footnote{\dag\dag}", Str "{x}"
    ## A\footnote{*} {x}                            RawInline, Space, Str "{x}"
    ## A\footnote{*}{}                              un solo RawInline: "\footnote{*}{}"
    ## A\footnote{*}{ }                             RawInline "\footnote{*}"; el par con un espacio desaparece
    ## A\footnote{texto}                            RawInline "\footnote{texto}"
    ## A\footnote{*}{Nota (salto) sigue}             el título termina en Str "{Nota"; «sigue}» es otro párrafo

El segundo par se lee como Markdown: la bastardilla, las citas, \sptext y \num (como RawInline) y una nota ^[…] adentro salen como en cualquier texto. Las llaves quedan como caracteres de los Str, también las de adentro («{llaves}»): para encontrar el cierre hay que contarlas. Pandoc no interpreta \footnote: no crea una nota (Note), y el RawInline lo descartan los escritores de XML (GV-116).

El identificador automático del título incluye el texto del segundo par: «## A\footnote{**}{*Cursiva* inicial}» da `acursiva-inicial`.',
   'vigente', 'empirica', 'Pandoc 3.1.3 / SaxonJ-HE 12.5 / jing 20220510 / LuaLaTeX (TeX Live 2023) con titlesec 2.16, footmisc, scrextend y hyperref / fontTools / contenedor Ubuntu 24.04', '2026-11', 'apoya:SC-86,vinculo:GV-116,vinculo:GV-124', NULL, 1890,
   datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('GV', 190, 'GV-190', 'titlesec 2.16: dentro de un título, \footnote es \footnotemark más un \footnotetext que se compone después; guarda una sola nota',
   'Leído en titlesec.sty 2.16 (2023/10/27) y medido con LuaLaTeX (TeX Live 2023), footmisc (bottom, stable), scrextend y hyperref, con las capas del libro.

Al componer un título, titlesec redefine \footnote: emite la llamada con \footnotemark y guarda el texto con `\gdef\ttl@fn{\footnotetext{…}}`, que se compone después del título (`\ttl@savefn`, `\ttl@finmarks`).

- Una sola nota por título: cada \footnote pisa `\ttl@fn`. Con dos notas numeradas en un título, la primera pierde el texto sin aviso (medido: la llamada [2] queda sin nota al pie; la [3] sale).
- El texto se compone fuera del título y del grupo que lo rodeaba. Un \footnote agrupado, con \thefootnote local y el contador devuelto a mano, daba la llamada con el símbolo y, al pie, el número ([2] en lugar de *).
- Con el argumento opcional, `\footnote[N]{…}`, titlesec guarda `\footnotemark[N]` y `\footnotetext[N]{…}`: la llamada y el texto usan el mismo valor, y el contador no avanza. Es lo que usa la nota con símbolo (SC-86).
- hyperref no vincula esa llamada de un título; la de un `\footnote[N]` en un párrafo, sí. Medido: siete vínculos para siete notas numeradas, ninguno para tres notas con símbolo en títulos; sin avisos de destinos repetidos.

Vale también para la nota numerada de SC-29: una por título.',
   'vigente', 'empirica', 'Pandoc 3.1.3 / SaxonJ-HE 12.5 / jing 20220510 / LuaLaTeX (TeX Live 2023) con titlesec 2.16, footmisc, scrextend y hyperref / fontTools / contenedor Ubuntu 24.04', '2026-11', 'apoya:SC-86,apoya:SC-29,vinculo:GV-70', NULL, 1900,
   datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('GV', 191, 'GV-191', 'DocBook 5.2: footnote/@label es NMTOKEN — «*» y «†» no validan',
   'En el RNG de DocBook 5.2, `db.footnote.label.attribute` («Identifies the desired footnote mark») es de tipo NMTOKEN.

Medido con jing 20220510: `<footnote label="*">` y `label="†"` fallan («value of attribute "label" is invalid; must be an XML NMTOKEN»); `label="ast"` y `label="dag"` validan. Un NMTOKEN admite letras, dígitos, punto, guion, guion bajo y dos puntos: un signo tipográfico, no.

Por eso el canónico del libro guarda el nombre del símbolo y las hojas lo traducen (SC-86). En JATS 1.4, `fn/@symbol` es CDATA y `<fn>` admite `<label>` (`fn-model`: `(label?, (%just-para.class;)+)`): ahí el signo entra tal cual.',
   'vigente', 'empirica', 'Pandoc 3.1.3 / SaxonJ-HE 12.5 / jing 20220510 / LuaLaTeX (TeX Live 2023) con titlesec 2.16, footmisc, scrextend y hyperref / fontTools / contenedor Ubuntu 24.04', '2026-11', 'apoya:SC-86', NULL, 1910,
   datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO entradas
  (prefijo, numero, codigo, titulo, cuerpo, estado, evidencia, entorno,
   fecha_verificacion, relaciones, pendiente, orden, fecha_alta, fecha_modificacion)
VALUES
  ('SC', 86, 'SC-86', 'Nota con símbolo en un título de sección: \footnote{símbolo}{texto}, con el diccionario de la AMS (libros)',
   'DECISIÓN CERRADA (decisiones de Alberto, 11/11/2026). Deja sin efecto la renuncia de SC-29: un título de sección puede llevar una nota con símbolo en lugar de número, como `\Footnote{}{}` en LaTeX (consejo de la AMS). Por ahora solo en libros; las revistas, después de su refactorización.

CÓMO SE ESCRIBE

    ## La edición universitaria\footnote{*}{Versión revisada de la ponencia leída en las *Jornadas*.}

El primer par de llaves lleva el símbolo; el segundo, el texto, en Markdown (bastardilla, citas, volada, cifras). Pegado al título y entero en su línea. El sumario sale solo, como en SC-29: no hace falta escribir el argumento opcional.

EL DICCIONARIO

La secuencia de la AMS sin ‖, que IBM Plex Sans y Plex Sans Condensed no tienen (medido con fontTools):

    en el .md       *    \dag   \ddag   \S   \P   **     \dag\dag   \ddag\ddag
    signo           *    †      ‡       §    ¶    **     ††         ‡‡
    nombre (label)  ast  dag    ddag    S    P    ast2   dag2       ddag2
    índice (PDF)    1    2      3       4    5    6      7          8

Cerrado (decisión de Alberto): sin números, que chocarían con la numeración, ni otros signos. Tres gemelos, en el mismo orden: `nota-simbolo.lua`, `nota-simbolo-comun.xsl` y `\gbSimboloNota` del contrato.

EL SÍMBOLO LO ELIGE QUIEN EDITA

Sin contador: el símbolo es un dato del canónico y sale igual en todas las salidas. La regla de la página —el mismo símbolo puede volver cinco páginas después, nunca dos veces en la misma— la controla quien edita en la prueba del PDF, como en LaTeX (decisión de Alberto). Un contador por página (footmisc `perpage`) daría símbolos distintos en el PDF y en la web, y reiniciaría también las numeradas. Las numeradas no se enteran: 1, 2, *, 3, 4, **, 5.

LA REGLA

- Solo en un título de sección: `##` y siguientes. En el `#` del capítulo, que sale de la base (SC-28), o fuera de un título, frena.
- Una sola nota por título, numerada o con símbolo (decisión de Alberto: lo que sobre es un tema de corrección con el autor). titlesec guarda una sola (GV-190): lo informa el control `nota_doble_en_titulo` (SC-54) y lo frena el filtro.
- Frena también: un símbolo fuera del diccionario; un solo par de llaves; un espacio entre los dos pares; el texto sin la llave de cierre (una nota partida en dos líneas); el texto vacío; una nota dentro de la nota.

CANÓNICO

`nota-simbolo.lua`, en la cadena del libro después de `volada.lua` y antes de `corte-titulo.lua`, reconstruye la nota desde lo que deja Pandoc (GV-189): cuenta las llaves en los Str del primer nivel, arma un Note con la marca `<?gb-nota-simbolo ast?>` al comienzo y rearma el identificador automático del título, que traía el texto de la nota. `cite-to-biblioref-db.lua`, que serializa las notas, quita la marca y la pasa al atributo:

    DocBook   <title>La edición universitaria<footnote label="ast"><para>…</para></footnote></title>

`label` es NMTOKEN: va el nombre, no el signo (GV-191). `controles_md.lua` admite `\footnote{…}` en `latex_en_linea`.

PDF (CONTRATO 22)

- `docbook-to-latex.xsl`: en la apertura del título, `\gbNotaTituloSimbolo{N}{texto}`; fuera de un título, `\gbNotaSimbolo{N}{texto}`. El sumario, el folio y los marcadores van sin la nota, como en SC-29.
- `\gbNotaSimbolo{N}` es `\footnote[1000+N]`: con el argumento opcional no avanza el contador, y titlesec difiere la nota con el mismo valor (GV-190). `\gbNotaTituloSimbolo` no emite nada cuando titlesec mide el título (GV-70).
- La estética arma `\thefootnote` con `\gbMarcaNota{[\arabic{footnote}]}`: un valor mayor que `\gbBaseSimbolo` (1000) compone el símbolo, sin corchetes; si no, la marca numerada de la casa. Una estética de editorial que no use `\gbMarcaNota` mostraría «[1001]».
- La llamada con símbolo de un título no tiene vínculo en el PDF (GV-190; aceptado por Alberto): el lector ve el símbolo al pie de la misma página.

HTML

`docbook-to-html.xsl`: la marca es el signo y no se cuenta en la numeración del capítulo; su `data-fn-id` es `s1`, `s2`… El panel muestra «Nota *» y la navegación cruzada funciona igual: el JS no cambia.

EPUB

`docbook-to-epub.xsl`: la llamada lleva el signo (`epub:type="noteref"`) y la lista de notas del capítulo la encabeza con el mismo signo; los ids son `fn-s1` y `fnref-s1`. Las numeradas se cuentan sin las de símbolo.

MEDIDO EN EL CONTENEDOR

Pandoc 3.1.3 con volada, nota-simbolo, corte-titulo y cite-to-biblioref-db: el capítulo valida contra el RNG de DocBook 5.2 (jing), y los once casos que frenan, frenan con su mensaje. SaxonJ-HE 12.5: `docbook-to-latex` (la apertura con la nota, el sumario sin ella), `docbook-to-epub` (ids y marcas) y la plantilla de nota de `docbook-to-html`. LuaLaTeX (TeX Live 2023, titlesec 2.16) con las capas reales del libro —contrato, contrato común, estética y hyperref; la estética con las Plex .ttf del sistema en lugar de .otf—: «1, 2, *, 3, 4, †, ‡, 5, [6] en un título, 7», cada nota al pie con su marca, sin avisos de hyperref, siete vínculos para las siete numeradas.',
   'vigente', 'empirica', 'Pandoc 3.1.3 / SaxonJ-HE 12.5 / jing 20220510 / LuaLaTeX (TeX Live 2023) con titlesec 2.16, footmisc, scrextend y hyperref / fontTools / contenedor Ubuntu 24.04', '2026-11', 'vinculo:SC-29,vinculo:SC-28,vinculo:SC-54,vinculo:SC-63,vinculo:SC-62,vinculo:GV-70,vinculo:GV-189,vinculo:GV-190,vinculo:GV-191', 'Probar en Mint con un libro real: PDF (la llamada y la nota al pie, el sumario y los marcadores sin la nota), HTML (el panel), EPUB (epubcheck), la inserción desde el panel y un caso que frene. Revistas, después de su refactorización: el canónico JATS (fn/@symbol con <label>), las hojas JATS y los sabores SciELO y Redalyc. El ODT.', 860,
   datetime('now','localtime'), datetime('now','localtime'));
INSERT INTO verificacion SELECT 'altas', COUNT(*) = 4 FROM entradas WHERE codigo IN ('SC-86','GV-189','GV-190','GV-191');

-- ------------------------------------------------------------
-- 3. SC-29
-- ------------------------------------------------------------
UPDATE entradas
   SET titulo = 'Notas al pie en títulos de sección: una por título, marca numérica o con símbolo, y dos versiones del título',
       cuerpo = replace(cuerpo, 'LA MARCA ES NUMÉRICA

La nota del título se numera con las demás, en el orden del texto. Se renuncia a la marca con asterisco u otro signo que en LaTeX da `\Footnote{}{}` (consejo de la AMS: no poner números en títulos ni fórmulas). Markdown no tiene forma de expresarla, y la confusión que se buscaba evitar la compensan los corchetes del PDF y el hipervínculo de EPUB y HTML.', 'UNA NOTA POR TÍTULO

Un título de sección lleva una sola nota (decisión de Alberto, 11/11/2026): titlesec guarda una sola y las otras se pierden del PDF sin aviso (GV-190). Lo informa el control `nota_doble_en_titulo` (SC-54); lo que sobre es un tema de corrección con el autor.

LA MARCA

La nota del título se numera con las demás, en el orden del texto. Desde el 11/11/2026 puede llevar, en cambio, un símbolo de la secuencia de la AMS, `\footnote{*}{texto}` (SC-86). Acá se había renunciado a esa marca porque Markdown no tenía forma de expresarla; la tiene (GV-189).'),
       relaciones = relaciones || ',vinculo:SC-86,vinculo:GV-190',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-29';
INSERT INTO verificacion SELECT 'SC-29 con una nota por título', instr(cuerpo, 'UNA NOTA POR TÍTULO') > 0 AND instr(cuerpo, 'Se renuncia') = 0 FROM entradas WHERE codigo = 'SC-29';

-- ------------------------------------------------------------
-- 4. SC-54
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(replace(cuerpo, '                                      de las admitidas: \sptext, \num, \SI,
                                      \SIrange, \index (GV-116, SC-77);', '                                      de las admitidas: \sptext, \num, \SI,
                                      \SIrange, \index (GV-116, SC-77);
                                      \footnote{…} en un título (SC-86);'), '    cifra_fuera_de_num        aviso   una cifra con punto o coma de miles fuera
                                      de \num (SC-64, SC-65)
', '    cifra_fuera_de_num        aviso   una cifra con punto o coma de miles fuera
                                      de \num (SC-64, SC-65)
    nota_doble_en_titulo      error   más de una nota en un título de sección,
                                      numerada o con símbolo (SC-29, SC-86,
                                      GV-190)
'),
       relaciones = relaciones || ',vinculo:SC-86',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-54';
INSERT INTO verificacion SELECT 'SC-54 con nota_doble_en_titulo', instr(cuerpo, 'nota_doble_en_titulo') > 0 FROM entradas WHERE codigo = 'SC-54';

COMMIT;

SELECT codigo, estado, titulo FROM entradas
 WHERE codigo IN ('SC-29','SC-54','SC-86','GV-189','GV-190','GV-191')
 ORDER BY prefijo, numero;
