# Lote: nota con símbolo en un título de sección (SC-86), libros

## Orden

1. **gbpublisher**: copiar los archivos de `gbpublisher/` sobre el proyecto
   (dos nuevos y nueve reemplazados, ver abajo) y recompilar. Todos juntos:
   el filtro escribe lo que las hojas y el contrato esperan.
   - `comun.sh` lo comparte la cadena de revistas, que se está
     refactorizando en otra conversación. Si tu copia cambió desde hoy,
     no la reemplaces: aplicá solo su parte de `cambios.diff` (una línea
     en `FILTROS_LIBRO` y su comentario).
   - `cambios.diff` es el parche unificado de todo el lote; aplica limpio
     sobre la copia de tu disco del 11/11 (`git apply --check`).
2. **gbShortcodes**: importar `datos/datos-v5-025.sql` y reexportar el
   catálogo. Después del paso 1.
3. **gbCorpus**: importar `gbcorpus-act-95.sql` y reexportar `corpus.md`.
   Si la otra conversación ya usó act-95, SC-86 o GV-189 a 191, el script
   frena en sus precondiciones: avisame y lo renumero.

## Archivos

Nuevos:

- `.hidden/filters/nota-simbolo.lua`: lee `\footnote{símbolo}{texto}` de un
  título y lo convierte en una nota marcada.
- `.hidden/xslt/nota-simbolo-comun.xsl`: el diccionario (nombre → signo,
  nombre → índice) para las tres hojas del libro.

Cambios puntuales (coordenadas):

- `.hidden/engine/comun.sh`, apartado 3b (las cadenas de filtros):
  `nota-simbolo.lua` en `FILTROS_LIBRO`, después de `volada.lua`, y su
  renglón 2b° en el comentario del orden.
- `.hidden/engine/controles_md.lua`:
  - apartado 1 (`CONTROLES`): el control `nota_doble_en_titulo`, error;
  - `PATRONES_LATEX`: `^\\footnote%b{}$`;
  - en `revisar_crudo_inlines`, el mensaje de `latex_en_linea` nombra
    `\footnote`;
  - función nueva `revisar_notas_titulo`, llamada en `Pandoc()`.
- `.hidden/filters/cite-to-biblioref-db.lua`, función `Note`: si el primer
  párrafo empieza con `<?gb-nota-simbolo NOMBRE?>`, la quita y escribe
  `<footnote label="NOMBRE">`.
- `.hidden/xslt/docbook-to-latex.xsl`:
  - cabecera: el prefijo `gbns`;
  - el include de `nota-simbolo-comun.xsl`;
  - plantilla `footnote`: dos ramas nuevas para la nota con `label`.
- `.hidden/xslt/docbook-to-html.xsl`:
  - cabecera y el include;
  - plantilla `db:footnote | footnote`: la numeración no cuenta las notas
    con símbolo, que llevan `data-fn-id` `s1`, `s2`… y su signo como marca.
- `.hidden/xslt/docbook-to-epub.xsl`:
  - cabecera y el include;
  - la lista de notas del capítulo y la plantilla de la llamada usan
    `gbns:id-nota` y `gbns:marca-nota`, dos funciones nuevas debajo de la
    plantilla de la llamada.
- `.hidden/latex/preambulo-contrato.tex`:
  - contrato 22 (historial y `\gbContratoVersion`);
  - bloque nuevo después de `\input{preambulo-contrato-comun}`:
    `\gbBaseSimbolo`, `\gbSimboloNota`, `\gbMarcaNota`, `\gbNotaSimbolo`,
    `\gbNotaTituloSimbolo`.
- `.hidden/latex/preambulo-estetica.tex`, apartado NOTAS AL PIE:
  `\thefootnote` pasa por `\gbMarcaNota`.
- `.src/m_GenerarPDFLibro.module`, cabecera: `CONTRATO_VERSION = 22`.

## Prueba en Mint

En un libro, con la fila en borrador (desde el IDE):

1. Panel: Marcas en línea > Comunes > «Nota con símbolo en un título
   (\*, †)». Queda `\footnote{•}{}` con el marcador seleccionado.
2. Un capítulo con
   - notas numeradas en el texto;
   - `## Título\footnote{*}{Texto con *cursiva* y una cita.}`;
   - otra sección con `\dag`;
   - una sección con nota numerada en el título.
3. PDF: las numeradas siguen 1, 2, 3 sin saltos; la llamada y la nota al
   pie con el símbolo, sin corchetes; el sumario y los marcadores sin la
   nota.
4. HTML: el símbolo en el título; el panel, «Nota \*».
5. EPUB: el símbolo con su vínculo y en la lista de notas; epubcheck.
6. Un caso que frene, por ejemplo dos notas en un título o
   `\footnote{+}{x}`.
