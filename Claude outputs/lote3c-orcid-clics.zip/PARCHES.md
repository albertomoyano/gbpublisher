# Lote 3, corrección 2: ORCID con ícono y enlaces al panel (5/11/2026)

Tres archivos completos, los tres en `.hidden/`. No hay que compilar: son recursos.

| Archivo | |
|---|---|
| `xslt/docbook-to-html-portal.xsl` | ORCID: el nombre sin enlace y el ícono como enlace |
| `assets/css/gbpublisher-integrado.css` | El ícono de ORCID |
| `assets/js/gbpublisher.js` | Los clics en citas y notas |

Al arrancar gbpublisher, aceptá «Reemplazar» para los tres archivos y regenerá el HTML.

## 1. ORCID: el ícono es el enlace

La hoja integrada reemplaza `emitir-nombre-autor`, la plantilla de la hoja autónoma que enlaza el nombre. Ahora va como en la ficha del portal:

- el nombre, sin enlace;
- un espacio duro;
- el ícono de ORCID, que es el enlace.

```html
Magdalena Lemus&nbsp;<a class="orcid" href="https://orcid.org/0000-…"
   title="ORCID 0000-…" aria-label="ORCID de Magdalena Lemus"></a>
```

- **El ícono** es el mismo PNG de 28 px del portal (`gbWeb/.hidden/sitio/iconos/orcid.png`), mostrado a 16 px. Va embebido en base64 dentro de `gbpublisher-integrado.css`: así no hay un archivo más que sincronizar en `~/.gbpublisher` ni que copiar a `docs/`. El comentario de la regla dice cómo rehacerlo.
- **El enlace no tiene texto.** Su nombre accesible es el `aria-label`, y el `title` muestra el identificador. vnu lo acepta.
- **La autoría sigue en azul.** Es el estilo de `gbpublisher.css` («despega la autoría del título»). Solo se le quita al ícono la raya de puntos que esa hoja pone a los enlaces de la autoría.

La salida **autónoma no cambia**: sigue enlazando el nombre. Si querés el ícono también ahí, es un cambio para el lote 4.

## 2. Los clics en citas y notas

Había dos errores en `gbpublisher.js`:

- **El primer clic no hacía nada.** `highlightPanel` abre el panel con `togglePanel`, y esa función busca el botón «Mostrar panel», que la página integrada no tiene. Fallaba ahí. Ahora `togglePanel` no hace nada si no hay botón: el panel integrado siempre está.
- **Los clics siguientes movían la página.** El ítem se llevaba a la vista con `scrollIntoView`, que desplaza todos los contenedores, la ventana incluida. Con el panel fijo, la página saltaba y el texto que se estaba leyendo se iba. Ahora lo hace la función nueva `desplazarEnPanel`:
  - **con el panel fijo** (fijo al desplazar o cajón), desplaza solo el panel. Si el ítem ya está a la vista, no mueve nada;
  - **con el panel en el flujo** (en el teléfono va debajo del texto), desplaza la página hasta el ítem, como antes.

Además, **debajo de 1232 px**, un clic en una cita o una nota abre el cajón del panel. Antes no mostraba nada hasta que se lo abría con el botón.

Estos cambios valen también para la salida autónoma, que usa el mismo `gbpublisher.js`: su HTML no cambia (las páginas siguen idénticas byte a byte), pero los clics funcionan mejor. En la autónoma de escritorio, el primer clic todavía corre un poco la página: el panel aparece y la columna del texto se angosta, y el texto se reacomoda.

## Verificado en el contenedor

Clics en dos citas y una nota del capítulo 2 de Duek, a tres anchos.

| Ancho | Integrado | Autónomo |
|---|---|---|
| 1440 | Va a la pestaña, resalta el ítem y lo trae a la vista en el panel. La página no se mueve | Igual |
| 1000 | Se abre el cajón, con el ítem resaltado y a la vista | Igual |
| 390 | La página baja hasta el ítem | Igual |

- **Sin errores de JS** en ninguno de los casos.
- **El ORCID**, con un ORCID de prueba: el ícono va al lado del nombre, sin raya de puntos.
- **HTML5 sin errores** y **0 enlaces rotos**.
- **Las páginas autónomas siguen idénticas.**
