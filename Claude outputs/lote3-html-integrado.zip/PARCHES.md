# Lote 3 del HTML integrado: la salida de gbpublisher dentro del portal (5/11/2026)

Un libro con destino «Integrado al portal» ahora genera su HTML dentro del marco del portal:

- la cabecera y el pie del portal, sin banderas;
- la barra del libro, con «☰ Índice», dónde se está y Anterior/Siguiente;
- dos columnas fijas: el texto (600) y el panel (544);
- una página de entrada con la portada y los créditos.

Un libro con destino «Autónomo» sale **idéntico byte a byte** al de hoy.

No toca la base. Todo va en el repositorio de gbpublisher, con el IDE cerrado. Compilá recién con los siete archivos en su lugar.

## Qué trae el zip

| Archivo | |
|---|---|
| `.hidden/xslt/docbook-to-html-portal.xsl` | **nuevo.** La hoja integrada |
| `.hidden/assets/css/gbpublisher-integrado.css` | **nuevo.** Acomoda la hoja del portal y la del libro |
| `.hidden/xslt/docbook-to-html.xsl` | **completo.** Es la tuya, con cuatro plantillas extraídas. Su salida no cambia |
| `.hidden/engine/generar_html_libro.sh` | **completo.** Baja el marco y elige la hoja |
| `.hidden/assets/js/gbpublisher.js` | **completo.** Guardas contra elementos que faltan |
| `.src/m_GenerarSalidasLibro.module` | **completo.** `GenerarLibroHTML` lee el destino |
| `.src/m_GenerarEpubLibro.module` | **completo.** Función nueva `EscribirPrimerasHtml` |

**Al arrancar gbpublisher** te va a avisar que `xslt/docbook-to-html.xsl` y `assets/js/gbpublisher.js` difieren de los instalados. Elegí «Reemplazar». Los dos archivos nuevos se copian solos a `~/.gbpublisher`.

## Cómo está armado

### La hoja integrada importa la autónoma

`docbook-to-html-portal.xsl` hace `xsl:import` de `docbook-to-html.xsl` y reemplaza solo dos cosas:

- la plantilla raíz;
- las plantillas que arman cada página.

El vocabulario DocBook es el de la hoja autónoma, sin copia: secciones, figuras, notas, citas, cuadros, panel y metadatos. Una corrección allá vale acá.

Al revés, nada de la hoja integrada puede cambiar la salida autónoma, porque la autónoma no la lee.

Para no duplicar código, saqué de la hoja autónoma cuatro plantillas con nombre:

- `emitir-dedicatoria`;
- `emitir-cabeza-capitulo`: parte, título, subtítulo y autoría;
- `emitir-cuerpo-capitulo`: resúmenes y contenido;
- `emitir-boton-pdf-capitulo`.

La salida autónoma sigue idéntica. Lo comprobé con Duek, con y sin una dedicatoria de prueba.

### La página de un capítulo

1. **La cabecera del portal**, copiada del marco:
   - el logo apunta a `assets/marco/media/`;
   - compartir lleva la dirección y el título de **esa página**: `url-libro` + `h-….html`.
2. **La barra del libro**, fija al desplazar:
   - «☰ Índice» abre el menú de 600 px sobre el texto: tapa chica, título, subtítulo, autoría y las piezas, con la actual en negrita. Se cierra con un clic afuera o con Esc, y funciona sin JS;
   - en el medio: libro · «2. Título del capítulo»;
   - a la derecha: Anterior / Siguiente.
3. **El texto**:
   - la cabeza de siempre;
   - debajo, «Cómo citar» y el PDF del capítulo (si tiene URL);
   - el cuerpo;
   - Anterior / Siguiente con el título de cada vecina;
   - el colofón.
4. **El panel**, el mismo de la salida autónoma, fijo debajo de la barra.
5. **El pie del portal.**

En la primera pieza, «Anterior» lleva a la página de entrada. En la última, «Siguiente» queda inactivo.

### La página de entrada (`index.html`)

Es adonde lleva «Leer en línea» desde el portal. Lleva la portada, los créditos y la dedicatoria (si la hay); a la derecha va «Cómo citar» del libro.

- **La portada y los créditos son las mismas páginas del EPUB.** Gambas las arma con las mismas funciones (`ArmarPortada`, `ArmarCreditos`) y las escribe en `tmp/html-portal/`. La hoja toma de cada una su `<section>` y cambia dos cosas:
  - `../images/X` pasa a `assets/media/X`;
  - el `h1` de los créditos genéricos pasa a párrafo, porque la página ya tiene el de la portada.
- **La portada va solo si el libro la declara**, como en el EPUB (SC-25). Si no la declara, la hoja pone una portada mínima con título, subtítulo y autoría: en el EPUB la tapa cumple ese papel, pero una página web sin título no se puede leer.
- **La dedicatoria va en la entrada**, no en el menú ni en Anterior/Siguiente, igual que en la salida autónoma (SC-31).

### El idioma del marco

El marco usa el idioma del libro si el portal lo tiene. Se compara la primera parte del código, así que `pt-BR` toma `pt`. Si el portal no tiene ese idioma, va el castellano. Lo probé con un libro en `pt-BR`.

### La tipografía

Solo Noto, servida desde `assets/marco/fuentes/`, sin Google Fonts:

- Noto Serif para todo;
- Noto Sans Mono para el código.

Las variables de IBM Plex de `gbpublisher.css` se redirigen a Noto.

### Pantallas angostas

- **Debajo de 1232 px**, el panel pasa a un cajón. Se abre con el botón «→», abajo a la derecha.
- **En el teléfono**, el panel va debajo del texto, como hoy.

## El script (`generar_html_libro.sh`)

### Los argumentos

Suma dos argumentos opcionales, después de la tapa:

```
… <estilo_cita> <modo_citas> [imagen_tapa|-] [destino_html] [url_portal]
```

- **Sin el octavo**, el destino es autónomo. Por eso un libro autónomo recibe exactamente los mismos argumentos que hoy.
- **Con destino portal**, la tapa ocupa su lugar aunque no haya: en ese caso va `-`.

### El marco (apartado 5c)

1. Baja `<url_portal>marco/marco.xml` y cada archivo que lista. Usa `curl -L` para seguir la redirección cuando migres de dominio.
2. Antes de escribir nada, controla cada ruta:
   - relativa;
   - sin `..`;
   - sin segmentos que empiecen con punto.
3. Verifica:
   - el sha256 de cada archivo;
   - que el `url-base` del manifiesto sea la dirección del portal del libro;
   - que la cabecera y el pie en castellano sean XML bien formado.
4. Recién entonces reemplaza `docs/assets/marco/`. Una descarga a medias no pisa un marco sano.
5. **Sin red**, usa el marco de la generación anterior si sigue íntegro y avisa (código 3). Si tampoco sirve, frena y dice por qué.

### El resto del script

- **Con destino autónomo**, borra `docs/assets/marco/` y `gbpublisher-integrado.css`: un libro que deja el portal no conserva restos.
- **Los logos de la portada y los créditos** se copian con las demás imágenes, por `copiar_imagen_pantalla`.

## Gambas

- **`GenerarLibroHTML` lee `destino_html` y `url_portal`** junto con la tapa. Antes la lectura de la tapa fallaba en silencio. Ahora un error frena, porque el destino decide la salida.
- **Con destino portal**, antes de lanzar el script llama a `m_GenerarEpubLibro.EscribirPrimerasHtml(sRutaProyecto, iIdLibro)`. Esa función:
  - vacía `tmp/html-portal/`;
  - verifica los logos;
  - escribe `portada.xhtml` (si el libro la declara) y `creditos.xhtml`.
- **La constante pública `CARPETA_PRIMERAS_HTML`** vale `"html-portal"`. Coincide con `DIR_PRIMERAS` del script.

## `gbpublisher.js`

Tres guardas:

- **Inicio:** si la página no tiene panel, no lo arma. Esto arregla también el «Cómo citar» vacío del `index.html` **autónomo**, que estaba anotado para el lote 4: `buildNotesPanel` fallaba antes de llegar a la cita.
- **`closeDrawers`:** no falla si no hay columna izquierda (la integrada no la tiene).
- **`openDrawerMeta`:** la misma guarda.

## Lo que hay que mirar en Mint

1. Aplicá el zip con el IDE cerrado. Arrancá y aceptá «Reemplazar».
2. En el formulario del libro de Duek:
   - `url-libro` tiene que ser `https://albertomoyano.github.io/l-DUEK/`. Es la dirección que se comparte desde cada página; hoy tiene la del portal;
   - destino «Integrado al portal», con portal `https://albertomoyano.github.io/L-IMAGO/`.
3. Generá el HTML. En la consola tiene que aparecer «25 archivo(s) del marco, verificados por su sha256».
4. Abrí `docs/index.html` y un capítulo. Probá el menú, Anterior/Siguiente y el panel. Achicá la ventana por debajo de 1232 px.
5. Desplegá l-DUEK y entrá desde «Leer en línea» del portal.

## Verificado en el contenedor (con los datos reales de Duek y el marco publicado)

- **Salida autónoma:**
  - con la hoja refactorizada, las 10 páginas salen idénticas byte a byte a las de la hoja actual;
  - lo mismo con una dedicatoria de prueba;
  - y después de pasar de portal a autónomo con el script.
- **Salida integrada:**
  - 10 páginas;
  - 211 enlaces locales, ninguno roto;
  - **0 errores de HTML5 (vnu)**;
  - sin errores de JS;
  - «Cómo citar» con texto en la entrada y en los capítulos.
- **Determinismo:** dos corridas del script dan la misma huella de todo `docs/`, marco incluido.
- **El marco:**
  - sin red usa el anterior y avisa;
  - un marco alterado sin red frena;
  - otro portal frena;
  - una dirección mal formada frena;
  - las rutas con `..`, con punto inicial o con `//` se rechazan.
- **Casos borde:**
  - un libro sin portada declarada lleva la portada mínima;
  - con `pt-BR` toma el marco `pt`;
  - sin `url-libro`, la cabecera sale sin compartir;
  - la dedicatoria va en la entrada y no en el menú.
- **Pantallas:** capturas a 1440, 1000 y 390 px. El menú se cierra con Esc y con un clic afuera, y el cajón del panel abre y cierra.
- **Gambas:**
  - el proyecto compila con los dos módulos (gbc3 3.19);
  - la consulta nueva de `GenerarLibroHTML` corre sobre la 1.22.0.
  - `GenerarLibroHTML` y `EscribirPrimerasHtml` no se pueden ejecutar en el contenedor: probalos en Mint.

## Lo que sigue pendiente

- **Lote 4:**
  - Noto en lugar de IBM Plex en el HTML **autónomo**;
  - el espacio de más en las citas (`.xref-bibr`, se ve en «(Chaves 2005 )»).
- **Corpus:** el acta de SC-80, SC-25, SC-81 y SC-22 con el marco. Necesito un `corpus.md` recién exportado antes de escribirla.
