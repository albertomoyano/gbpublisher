-- ============================================================
-- datos-v5-023: corte de línea en un título, en el panel (SC-63)
-- ------------------------------------------------------------
-- Da de alta:
--   el modo marca, en línea: inserta apertura y cierre juntos, sin
--   contenido ni selección, en lugar de los espacios que rodean al
--   cursor. Agregar un modo es un dato, no una migración (RF-11).
--   corte-titulo, grupo composicion, orden 10, modo marca: apertura
--   \\ y cierre un espacio, como se escribe en LaTeX («Hola\\ mundo»,
--   decisión de Alberto, 11/11). En borrador para libros y revistas
--   hasta probar la inserción desde el panel en Mint.
-- Requiere gbpublisher con MODO_MARCA en m_CatalogoShortcodes y
-- m_Shortcodes.InsertarMarca: una versión anterior rechaza el catálogo
-- entero por «modo desconocido».
-- Después: reexportar el catálogo (SC-34).
-- Esquema: 5
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE _verif (paso TEXT, ok INTEGER CHECK (ok = 1));

-- --- 1. PRECONDICIONES ---
-- EL MODO, EL NOMBRE Y LA CLASE ESTÁN LIBRES; EL ORDEN 10 DE LAS MARCAS
-- EN LÍNEA DE COMPOSICIÓN TAMBIÉN (HASTA ACÁ EL GRUPO SOLO TIENE BLOQUES)
INSERT INTO _verif SELECT 'modo marca libre', COUNT(*) = 0 FROM modos WHERE modo = 'marca';
INSERT INTO _verif SELECT 'corte-titulo libre', COUNT(*) = 0 FROM shortcodes
  WHERE nombre = 'corte-titulo' OR clase = 'corte-titulo';
INSERT INTO _verif SELECT 'orden 10 libre', COUNT(*) = 0 FROM shortcodes
  WHERE grupo = 'composicion' AND tipo = 'linea' AND orden = 10;

-- --- 2. EL MODO marca, SOLO EN LÍNEA ---
INSERT INTO modos (modo, tipo, descripcion) VALUES ('marca', 'linea', 'Inserta la apertura y el cierre juntos, sin contenido ni selección, en lugar de los espacios que rodean al cursor (SC-63).');

-- --- 3. CORTE-TITULO ---
-- EL CIERRE ES UN ESPACIO Y NO UNA CADENA VACÍA: ES EL ESPACIO QUE SIGUE AL
-- CORTE, Y EL ESQUEMA 5 NO ADMITE UN CIERRE VACÍO (CHECK (cierre <> ''))
INSERT INTO shortcodes (nombre, clase, etiqueta, tipo, grupo, perfil, orden, estado_libro, estado_revista, modo, apertura, cierre, que_es, ejemplo, como_sale, mapeo_docbook, mapeo_jats, notas, pendiente, fecha_alta, fecha_modificacion)
VALUES ('corte-titulo', 'corte-titulo', 'Corte de línea en un título (PDF)', 'linea', 'composicion', NULL, 10, 'borrador', 'borrador', 'marca', '\\', ' ',
        'Corta un título de sección en dos o más líneas, solo en la apertura del PDF. Es el `\\` de LaTeX y se escribe igual: pegado a la palabra anterior y con un espacio antes de la siguiente, `Hola\\ mundo`.

Se ubica el cursor entre las dos palabras donde va el corte, en la línea del título, y se inserta: el espacio entre las dos palabras queda como `\\` y un espacio. Vale en los títulos de sección: `##` y siguientes en un libro (el `#` del capítulo sale de la base), cualquier nivel en una revista.

Un título puede tener varios cortes. El corte no va al principio ni al final del título, ni pegado a otro, ni dentro de una bastardilla, una negrita u otra marca. Fuera de un título no corta: para un salto fuera de un título está «Espacio vertical (PDF)».',
        '## La edición científica\\ en América Latina',
        'En el PDF, el título se abre en dos líneas, cortado donde va `\\`. En el sumario, el folio y los marcadores del PDF sale en una sola línea.

En el HTML, el EPUB y el ODT, el corte es un espacio: «La edición científica en América Latina». Tampoco llega a los XML de los indexadores: SciELO y Redalyc lo quitan.

Un corte al principio o al final del título, dos seguidos o uno dentro de una marca detienen la conversión con un mensaje que dice qué falla. En un libro, una `\\` fuera de un título también la detiene.',
        '<title>La edición científica <?gb-corte?>en América Latina</title>: la marca de SC-28, con un espacio antes (SC-63)',
        '<sec><title>La edición científica <break/>en América Latina</title> (SC-28, SC-63); jats-to-scielo y jats-to-redalyc quitan sec/title/break',
        'Sin clase de Pandoc: corte-titulo es el nombre del filtro y no aparece en el .md. Modo marca (este script): inserta la apertura y el cierre juntos, \\ y un espacio, en lugar de los espacios que rodean al cursor. El cierre es ese espacio: el que sigue al corte en la escritura de LaTeX (decisión de Alberto, 11/11); m_CatalogoShortcodes.FilaDeLinea rechaza un modo marca sin cierre. Antes de insertar, m_Shortcodes.InsertarMarca controla que el cursor esté en una línea de título (## y siguientes en un libro), entre dos palabras, no al principio ni al final del título y no pegado a otra barra; dentro de una marca lo controla corte-titulo.lua al generar. Filtro corte-titulo.lua en las tres cadenas, después de volada.lua (SC-63, GV-121). Control corte_fuera_de_titulo en controles_md.lua, solo libros (SC-54).',
        'Probar en Mint con un libro y una revista: la inserción desde el panel (cursor antes y después del espacio), los avisos del panel (fuera de un título, # de capítulo en un libro, al principio, al final, dentro de una palabra, pegado a otro corte), la ayuda con el ejemplo coloreado y el PDF del documento de prueba.',
        datetime('now','localtime'), datetime('now','localtime'));

INSERT INTO _verif SELECT 'modo escrito', COUNT(*) = 1 FROM modos WHERE modo = 'marca' AND tipo = 'linea';
INSERT INTO _verif SELECT 'corte-titulo escrito', COUNT(*) = 1 FROM shortcodes
  WHERE nombre = 'corte-titulo' AND tipo = 'linea' AND grupo = 'composicion' AND modo = 'marca'
    AND apertura = '\\' AND length(apertura) = 2 AND cierre = ' '
    AND estado_libro = 'borrador' AND estado_revista = 'borrador';
INSERT INTO _verif SELECT 'claves foráneas', COUNT(*) = 0 FROM pragma_foreign_key_check('shortcodes');

DROP TABLE _verif;

COMMIT;

SELECT nombre, etiqueta, tipo, grupo, orden, modo, apertura, '[' || cierre || ']' AS cierre, estado_libro, estado_revista
  FROM shortcodes WHERE nombre = 'corte-titulo';
