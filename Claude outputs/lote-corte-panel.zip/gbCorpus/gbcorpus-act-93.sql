-- ============================================================
-- gbCorpus — actualización 93: el corte de un título, en el panel
--            de shortcodes (SC-63) y el modo marca (RF-11)
-- Esquema: 2
-- Origen: conversación del 11/11/2026. Decisiones de Alberto: el
--         corte del título se escribe con \\ (no con un shortcode
--         nuevo), pegado a la palabra anterior y con un espacio antes de
--         la siguiente, como en LaTeX; se agrega al panel para que el
--         editor lo ofrezca.
-- Fecha:  2026-11-11
-- Aplicar: después de act-92. Va con gbShortcodes datos-v5-023.sql y
--          con m_Shortcodes y m_CatalogoShortcodes de gbpublisher.
--
-- ALTAS: ninguna.
--
-- MODIFICA:
--   SC-63   EN EL PANEL (sección nueva antes de PROBADO EN MINT);
--           pendiente; relaciones con RF-11 y SC-34; verificado 2026-11
--   RF-11   MODOS: el modo marca
-- ============================================================

BEGIN TRANSACTION;

CREATE TEMP TABLE verificacion (paso TEXT, ok INTEGER CHECK (ok = 1));

-- ------------------------------------------------------------
-- 1. ESTADO DE PARTIDA: act-92 APLICADA, TEXTOS UNA VEZ
-- ------------------------------------------------------------
INSERT INTO verificacion SELECT 'act-92 importada', COUNT(*) = 1 FROM importaciones WHERE numero = 92;
INSERT INTO verificacion SELECT 'SC-63 vigente', COUNT(*) = 1 FROM entradas WHERE codigo = 'SC-63' AND estado = 'vigente';
INSERT INTO verificacion SELECT 'SC-63 sin panel todavía', instr(cuerpo, 'EN EL PANEL') = 0 FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 ancla una vez', (length(cuerpo) - length(replace(cuerpo, 'PROBADO EN MINT

Alberto, 21/10', ''))) = length('PROBADO EN MINT

Alberto, 21/10') FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 pendiente', pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10).' FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 relaciones', relaciones = 'vinculo:SC-28,vinculo:SC-29,vinculo:SC-39,vinculo:SC-54,vinculo:SC-62,vinculo:GV-121' FROM entradas WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'RF-11 sin marca todavía', instr(cuerpo, '- marca:') = 0 FROM entradas WHERE codigo = 'RF-11';
INSERT INTO verificacion SELECT 'RF-11 ancla una vez', (length(cuerpo) - length(replace(cuerpo, 'Se agrega con `datos-v5-005`, para bloque y para línea.', ''))) = length('Se agrega con `datos-v5-005`, para bloque y para línea.') FROM entradas WHERE codigo = 'RF-11';

-- ------------------------------------------------------------
-- 2. SC-63
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'PROBADO EN MINT

Alberto, 21/10', 'EN EL PANEL

Desde el 11/11 (decisión de Alberto) el corte está en el panel de shortcodes, en las marcas en línea del grupo composición: `corte-titulo`, modo `marca` (gbShortcodes `datos-v5-023.sql`, en borrador). Se escribe como en LaTeX: pegado a la palabra anterior y con un espacio antes de la siguiente, `Hola\\ mundo`. Por eso la fila tiene apertura `\\` y cierre un espacio, y el panel los inserta juntos en lugar de los espacios que rodean al cursor: «Hola |mundo» y «Hola| mundo» dan «Hola\\ mundo», con el cursor antes de «mundo». El modo `marca` es un dato de la tabla `modos` (RF-11): no hubo migración del esquema.

Antes de insertar, `m_Shortcodes.InsertarMarca` mira la línea del cursor y, si no corresponde, avisa y no inserta: con una selección; fuera de un título ATX (uno a seis `#` y un espacio al comienzo de la línea); en un libro, en el `#` del capítulo; al principio o al final del título (después del corte tiene que seguir texto, no los atributos `{#id}` ni los `#` de cierre); dentro de una palabra; pegado a otra barra. Un corte dentro de una bastardilla o una negrita lo sigue frenando `corte-titulo.lua` al generar.

MEDIDO en el contenedor (gbc3 y gbx3 3.19): `InsertarShortcode` real, con un doble del editor, en veinte casos de libro y de revista: las inserciones dan `Hola\\ |mundo` (también con varios espacios, con un corte previo en el título, en la segunda línea del texto y con letras acentuadas); los demás avisan con su motivo. Lo que inserta el panel pasa por `corte-titulo.lua` (Pandoc 3.1.3) a `<break/>` y `<?gb-corte?>`. `datos-v5-023.sql`, aplicado con `importar_shortcodes.sh` sobre una copia de la base.

PROBADO EN MINT

Alberto, 21/10'),
       pendiente = 'Falta en Mint: un caso que frene (corte al final, dos seguidos o dentro de una bastardilla) y el control corte_fuera_de_titulo. El ODT, cuando se encare (decisión de Alberto, 21/10). En el panel (corte-titulo, en borrador): la inserción, los avisos, la ayuda y el PDF del documento de prueba.',
       relaciones = relaciones || ',vinculo:RF-11,vinculo:SC-34',
       fecha_verificacion = '2026-11',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'SC-63';
INSERT INTO verificacion SELECT 'SC-63 con el panel', instr(cuerpo, 'EN EL PANEL') > 0 AND instr(cuerpo, 'PROBADO EN MINT') > 0 FROM entradas WHERE codigo = 'SC-63';

-- ------------------------------------------------------------
-- 3. RF-11
-- ------------------------------------------------------------
UPDATE entradas
   SET cuerpo = replace(cuerpo, 'Se agrega con `datos-v5-005`, para bloque y para línea.', 'Se agrega con `datos-v5-005`, para bloque y para línea.
- marca: solo en línea. Inserta la apertura y el cierre juntos, sin contenido ni selección, en lugar de los espacios que rodean al cursor, después de los controles propios del shortcode (SC-63: el corte de un título, apertura `\\` y cierre un espacio). Se agrega con `datos-v5-023`. El cierre de una marca queda al final de su línea de `_catalogo.tsv`: un editor que recorta los blancos finales lo borraría, y gbpublisher rechaza una fila de modo marca sin cierre.'),
       relaciones = relaciones || ',vinculo:SC-63',
       fecha_modificacion = datetime('now','localtime')
 WHERE codigo = 'RF-11';
INSERT INTO verificacion SELECT 'RF-11 con marca', instr(cuerpo, '- marca: solo en línea.') > 0 FROM entradas WHERE codigo = 'RF-11';

COMMIT;

SELECT codigo, estado, titulo, fecha_verificacion FROM entradas
 WHERE codigo IN ('SC-63','RF-11')
 ORDER BY prefijo, numero;
