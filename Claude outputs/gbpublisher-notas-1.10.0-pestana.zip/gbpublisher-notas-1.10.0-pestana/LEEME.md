# Notas internas — lote 1.10.0, versión pestaña

Reemplaza a la entrega anterior (la de `FNotas`, `FNotasMiembros` y `FNotasAdmin`): **no hay formularios nuevos**. Todo vive en la pestaña «Notas» de FMain (`TabStrip1`, índice 8), que ya armaste en el diseñador, y en el indicador `pbNotas` + `lblNotas` de `HBox3`. `m_Notas` es el módulo dueño de esa pestaña, como `m_Validaciones` de la suya.

## Contenido

| Archivo | Qué es |
|---|---|
| `actualizar-esquema-1.10.0.sh` | El mismo de la entrega anterior, sin cambios. Va en la raíz del repo. |
| `.src/m_Notas.module` | Nuevo, completo. |
| `PARCHES.md` | 17 cambios puntuales en FMain, FLogin, FProyectosParcial, m_InicioCierre, m_ConexionBD, FEstadisticas y FSysAdmin. |

## Orden de aplicación

1. **Archivo nuevo.** Copiá `m_Notas.module` a `.src/`, con el IDE cerrado.
2. **Parches.** Aplicá los 17 de `PARCHES.md`, todos antes de compilar: los handlers nuevos de FMain llaman a `m_Notas` (GV-56).
3. **En el diseñador** (FMain):
   - borrá `btnNotitas` de `HBox3`;
   - borrá `TimerNotitas`.
   Después de los parches el código ya no los usa.
4. **Borrá** `FNotaNueva` y `FNotasRecibidas` (form y class). Nada los usa.
5. **Recargar → Limpiar → Compilar** (RC-GM-05).
6. **Base:** `sudo bash actualizar-esquema-1.10.0.sh`, junto con la aplicación nueva. La vieja sigue escribiendo en `postits`, y la nueva no arranca sin las cinco tablas (validación de esquema).

## Cómo se comporta

- **Sin sesión o sin proyecto abierto**, el indicador no se ve, la pestaña queda vacía y no hay sondeo.
- **Con proyecto abierto**, la pestaña y el indicador muestran lo mismo: tus notas 1 a 1 más las del grupo del proyecto abierto. Las de grupos de otros proyectos aparecen al abrir ese proyecto.
- **El indicador:**
  - `notita-grey.png` sin pendientes;
  - `notitas-verde.png` con novedades;
  - `notitas-red.png` con alguna nota de 7 días o más sin actividad. Rojo gana sobre verde.
  - La leyenda dice, por ejemplo, «2 sin ver · 1 con 7+ días». Si un sondeo falla agrega «sin sondeo», y el tooltip muestra el error. El ícono también va en la pestaña «Notas» de `TabStrip1`.
- **El sondeo** usa el latido de `TimerRed` (30 s) y su conexión propia con plazo de lectura de 5 s. Con el semáforo de red en rojo no consulta.
  - Recarga la pestaña solo si cambió algo: notas, respuestas, cierres, el grupo, sus miembros o su creador.
  - Al abrir un proyecto o loguearse con uno abierto, sondea en el acto.
- **Pestaña «Grupo»:**
  - Sin grupo, se ve «Crear grupo del proyecto».
  - Con grupo, todos ven los miembros y el registro de altas y bajas.
  - La lista de disponibles y los botones Sumar y Bajar solo funcionan para el creador. La base lo vuelve a controlar en cada operación.

## Lo que verifiqué

En el contenedor (MySQL 8.0.46, Gambas 3.19):

- **Compilación.** Con los 17 parches aplicados y lo del paso 3 y 4 hecho, el proyecto completo compila con `gbc3 -f public-control -f public-module`, que son las opciones de tu `.project` (GV-57).
- **Ejecución.** Usé un arnés con el bloque `tsNotas` copiado tal cual de tu `FMain.form` (tus ajustes incluidos), con los handlers de los parches y `m_Notas` real. Recorrió esto:
  - **Grupo:** crear el grupo, que se confirma con Enter, y sumar dos miembros.
  - **Notas:** una de grupo y una 1 a 1. José ve «2 sin ver», sin contar la nota del grupo de otro proyecto; después ve una nota, responde y vuelve a responder en la de grupo.
  - **Indicador:** María ve «1 sin ver · 1 con 7+ días». Al cerrar la nota de grupo, la nota pasa a archivadas. Sin proyecto, el indicador se oculta. En el proyecto 2 solo aparece su grupo más las 1 a 1.
  - **Permisos:** José, que no es creador, tiene la pestaña Grupo de solo lectura.
  - **Sondeo:** una nota insertada desde afuera aparece al sondear.
- **Dos errores que encontró el arnés, ya corregidos:**
  - el hilo de la nota anterior quedaba a la vista al cambiar de usuario o de proyecto;
  - la leyenda conservaba el texto viejo estando oculta.

## Para mirar

- **`btnNotasCerrar` con fondo rojo:** en las capturas del arnés, deshabilitado se ve rojo pleno, casi igual que un botón activo. No llegué a comparar los dos estados lado a lado. Fijate en Mint si se nota cuándo se puede cerrar; si no, `ActualizarBotones` puede cambiarle el fondo según el estado.
- **Sin proyecto abierto no hay forma de ver las notas 1 a 1.** Es lo que acordamos: el panel derecho no existe sin proyecto. Si en el uso real alguien necesita leer una nota sin abrir un proyecto, lo charlamos.

## Próxima vuelta: administración en FSysAdmin

Lo que hacía `FNotasAdmin` va a una pestaña nueva de `TabStrip1` en FSysAdmin: la 6, «Notas», con `Count` de 6 a 7. Estos controles van en el diseñador:

| Control | Tipo | Uso |
|---|---|---|
| `lblNotasGrupos` | Label | «Grupos de notas por proyecto» |
| `gvNotasGrupos` | GridView | Expand, Mode Single, Header Horizontal. Proyecto, creador, si el creador está activo, miembros activos, notas abiertas |
| `hbxNotasTransferir` | HBox | contiene los tres siguientes |
| `lblNotasCreador` | Label | «Nuevo creador:» |
| `cmbNotasCreador` | ComboBox | ReadOnly, Expand. Miembros activos del grupo elegido |
| `btnNotasTransferir` | Button | «Transferir» |
| `lblNotasAutores` | Label | «Usuarios inactivos con notas abiertas» |
| `gvNotasAutores` | GridView | Expand, Mode Single, Header Horizontal. Usuario y cantidad de notas abiertas |
| `hbxNotasAcciones` | HBox | contiene los tres siguientes |
| `btnNotasActualizar` | Button | «Actualizar» |
| (Spring) | Spring | separador |
| `btnNotasCerrarAutor` | Button | «Cerrar sus notas» |

Cuando los subas, mando los handlers de FSysAdmin. El parche 17 de este lote ya trae el cierre de las notas al archivar un proyecto, que no necesita controles nuevos.

## Pendientes

1. Tu prueba con dos usuarios. El checklist es el de la entrega anterior, salvo el punto 3: ya no hay ventana propia.
2. Pestaña de administración en FSysAdmin (arriba).
3. Retiro de `postits` en una versión posterior.
4. Regenerar el baseline cuando esté probado.
5. Altas al corpus, con el corpus reexportado.
