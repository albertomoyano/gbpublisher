# Parches del lote 1.10.0 — notas en la pestaña «Notas»

17 cambios puntuales en archivos existentes. Aplicalos **todos** antes de recompilar: varios llaman a `m_Notas`, que va en el mismo lote (GV-56).

Cada parche dice dónde está y trae el bloque exacto a reemplazar y su reemplazo. Un reemplazo vacío significa borrar el bloque.

## 1. FMain.class — Form_Open, apartado 1 (Configuración de relojes)

En el archivo `FMain.class`, en **Form_Open, apartado 1 (Configuración de relojes)**.

Reemplazar:

```gambas
  TimerTemp.Enabled = True
  TimerNotitas.Delay = 5000
  TimerNotitas.Start
  TimerHOY.Delay = 1000
```

Por:

```gambas
  TimerTemp.Enabled = True
  ' LAS NOTAS YA NO TIENEN RELOJ PROPIO: LAS SONDEA TimerRed (m_Notas)
  TimerHOY.Delay = 1000
```

## 2. FMain.class — Form_Open, apartado 2 (Estado inicial de la interfaz)

En el archivo `FMain.class`, en **Form_Open, apartado 2 (Estado inicial de la interfaz)**.

Reemplazar:

```gambas
  ' EVALÚA LA CONEXIÓN REAL; SIN CONEXIÓN AÚN, QUEDA OCULTO.
  ActualizarEstadoBotonNotitas()
```

Por:

```gambas
  ' PESTAÑA «Notas»: GRILLA, VISTAS Y LEYENDA. SIN SESIÓN NI PROYECTO QUEDA
  ' VACÍA Y EL INDICADOR DE HBox3 OCULTO (m_Notas)
  m_Notas.InicializarTab()
```

## 3. FMain.class — TimerNotitas_Timer (la función entera se elimina)

En el archivo `FMain.class`, en **TimerNotitas_Timer (la función entera se elimina)**.

Reemplazar:

```gambas
Public Sub TimerNotitas_Timer()

  Dim sUsuario As String = m_InicioCierre.UsuarioEnCurso
  Dim hRs As Result
  Dim sSQL As String

  ' Verificar conexión
  If Not m_ConexionBD.mConn Then Return
  If Not m_ConexionBD.mConn.Opened Then Return

  ' BUSCAR NOTAS DESTINADAS AL USUARIO ACTUAL
  sSQL = "SELECT * FROM postits WHERE para = '" & sUsuario & "' AND oculto = 0 AND leido = 0 ORDER BY fecha DESC"
  hRs = m_ConexionBD.mConn.Exec(sSQL)

  ' SI HAY NOTAS DISPONIBLES, MOSTRAR FORMULARIO DE NOTAS
  If hRs.Available Then
    FNotasRecibidas.CargarNota(hRs)
    m_Sonido.sonar("Info")
    FNotasRecibidas.Show
  Endif

End
```

Por: **nada** (el bloque se borra).

## 4. FMain.class — btnNotitas_Click y ActualizarEstadoBotonNotitas (las dos funciones se reemplazan por los handlers de la pestaña «Notas»)

En el archivo `FMain.class`, en **btnNotitas_Click y ActualizarEstadoBotonNotitas (las dos funciones se reemplazan por los handlers de la pestaña «Notas»)**.

Reemplazar:

```gambas
Public Sub btnNotitas_Click()

  ' VOLVER A HABILITAR EL TIMER SI ESTÁ DETENIDO
  If Not TimerNotitas.Enabled Then
    TimerNotitas.Start()
  Endif

  m_Sonido.sonar("Info")
  FNotaNueva.Show

End

' ============================================
' Función   : ActualizarEstadoBotonNotitas
' Propósito : Habilita btnNotitas solo si existe una conexión de
'             usuario efectivamente abierta. Fuente de verdad:
'             m_ConexionBD.mConn.Opened, MISMO PREDICADO QUE USA
'             EL LOGIN. NO los TextBox de la UI (son estado de
'             pantalla, no de conexión).
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub ActualizarEstadoBotonNotitas()

  ' --- 1. VALIDACIÓN: ¿EXISTE EL MÓDULO Y EL OBJETO CONEXIÓN? ---
  ' RC-GM-17: VALIDACIÓN Y ACCESO A PROPIEDAD EN If ANIDADOS,
  ' NUNCA EN UN SOLO And (GAMBAS NO ES SHORT-CIRCUIT).
  ' MISMO ORDEN QUE EL GUARD DEL LOGIN EN FLogin.
  If Not Object.IsValid(m_ConexionBD) Then
    btnNotitas.Visible = False
    Return
  Endif

  If Not Object.IsValid(m_ConexionBD.mConn) Then
    btnNotitas.Visible = False
    Return
  Endif

  ' --- 2. FUENTE DE VERDAD: ESTADO REAL DE LA CONEXIÓN DE USUARIO ---
  btnNotitas.Visible = m_ConexionBD.mConn.Opened

End
```

Por:

```gambas
' ============================================
' Función   : gvNotas_Click
' Propósito : Solapa «Notas»: muestra el hilo de la nota elegida y registra
'             que el usuario la vio (m_Notas)
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub gvNotas_Click()

  m_Notas.ElegirNota()

End

' ============================================
' Función   : cmbNotasVista_Click
' Propósito : Solapa «Notas»: cambia entre activas y archivadas
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub cmbNotasVista_Click()

  m_Notas.CambiarVista()

End

' ============================================
' Función   : chkNotasProgramar_Click
' Propósito : Solapa «Notas»: habilita la hora de despacho
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub chkNotasProgramar_Click()

  m_Notas.CambiarProgramacion()

End

' ============================================
' Función   : btnNotasEnviar_Click
' Propósito : Solapa «Notas»: envía el texto como nota nueva
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnNotasEnviar_Click()

  m_Notas.Enviar()

End

' ============================================
' Función   : btnNotasResponder_Click
' Propósito : Solapa «Notas»: agrega el texto como respuesta a la nota elegida
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnNotasResponder_Click()

  m_Notas.ResponderElegida()

End

' ============================================
' Función   : btnNotasCerrar_Click
' Propósito : Solapa «Notas»: cierra y archiva la nota elegida (solo el autor)
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnNotasCerrar_Click()

  m_Notas.CerrarElegida()

End

' ============================================
' Función   : btnGrupoCrear_Click
' Propósito : Solapa «Notas», pestaña «Grupo»: crea el grupo de notas del
'             proyecto abierto
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnGrupoCrear_Click()

  m_Notas.CrearGrupoAbierto()

End

' ============================================
' Función   : btnGrupoSumar_Click
' Propósito : Solapa «Notas», pestaña «Grupo»: suma al grupo el usuario
'             elegido (solo el creador)
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnGrupoSumar_Click()

  m_Notas.SumarElegido()

End

' ============================================
' Función   : btnGrupoBaja_Click
' Propósito : Solapa «Notas», pestaña «Grupo»: da de baja el miembro elegido
'             (solo el creador)
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnGrupoBaja_Click()

  m_Notas.BajaElegido()

End
```

## 5. FMain.class — TimerRed_Timer, apartado 2

En el archivo `FMain.class`, en **TimerRed_Timer, apartado 2**.

Reemplazar:

```gambas
  If m_ConexionBD.SondearEstadoConexion() Then
    ' --- 3a. CONEXIÓN VIVA: VERDE ---
    PintarSemaforoConexion(2)
  Else
    ' --- 3b. CONEXIÓN CAÍDA: ROJO ---
    PintarSemaforoConexion(0)
  Endif
```

Por:

```gambas
  If m_ConexionBD.SondearEstadoConexion() Then
    ' --- 3a. CONEXIÓN VIVA: VERDE, Y SONDEO DE LAS NOTAS ---
    PintarSemaforoConexion(2)
    m_Notas.bRedViva = True
    m_Notas.Sondear()
  Else
    ' --- 3b. CONEXIÓN CAÍDA: ROJO. LAS NOTAS NO CONSULTAN HASTA QUE VUELVA ---
    PintarSemaforoConexion(0)
    m_Notas.bRedViva = False
  Endif
```

## 6. FMain.class — AbrirProyectoMD, apartado 9

En el archivo `FMain.class`, en **AbrirProyectoMD, apartado 9**.

Reemplazar:

```gambas
  PanelXML.Visible = True
  SplitterPrincipal.Visible = True
```

Por:

```gambas
  PanelXML.Visible = True
  SplitterPrincipal.Visible = True
  ' NOTAS: PESTAÑA E INDICADOR DEL PROYECTO RECIÉN ABIERTO (IdProyectoEnCurso
  ' YA FIJADO ARRIBA)
  m_Notas.CambioDeProyecto()
```

## 7. FLogin.class — btnConectarServer_Click, después de cachear IdUsuarioEnCurso (Case 1)

En el archivo `FLogin.class`, en **btnConectarServer_Click, después de cachear IdUsuarioEnCurso (Case 1)**.

Reemplazar:

```gambas
      FMain.MenuInicio.Enabled = True
      FMain.ActualizarEstadoBotonNotitas()
```

Por:

```gambas
      FMain.MenuInicio.Enabled = True
      ' NOTAS: SIN PROYECTO ABIERTO EL INDICADOR SIGUE OCULTO; SI LO HAY, CARGA
      ' Y SONDEA SIN ESPERAR AL PRIMER LATIDO
      m_Notas.IniciarSesion()
```

## 8. FLogin.class — btnDesconectarServer_Click, apartado 6

En el archivo `FLogin.class`, en **btnDesconectarServer_Click, apartado 6**.

Reemplazar:

```gambas
  ' --- 6. LIMPIAR ESTADO DE SESIÓN ---
  m_InicioCierre.UsuarioEnCurso = ""
  m_InicioCierre.IdUsuarioEnCurso = 0
```

Por:

```gambas
  ' --- 6. LIMPIAR ESTADO DE SESIÓN ---
  m_InicioCierre.UsuarioEnCurso = ""
  m_InicioCierre.IdUsuarioEnCurso = 0
  ' NOTAS: CIERRA LA CONEXIÓN DE SONDEO, VACÍA LA PESTAÑA Y OCULTA EL INDICADOR
  m_Notas.TerminarSesion()
```

## 9. FLogin.class — btnDesconectarServer_Click, apartado 9 (la última línea se elimina: el indicador ya lo ocultó TerminarSesion)

En el archivo `FLogin.class`, en **btnDesconectarServer_Click, apartado 9 (la última línea se elimina: el indicador ya lo ocultó TerminarSesion)**.

Reemplazar:

```gambas
  FMain.menuAcercaAyuda.Enabled = False
  FMain.ActualizarEstadoBotonNotitas()

End
```

Por:

```gambas
  FMain.menuAcercaAyuda.Enabled = False

End
```

## 10. FProyectosParcial.class — ButtonAbrirParcial_Click, apartado 9

En el archivo `FProyectosParcial.class`, en **ButtonAbrirParcial_Click, apartado 9**.

Reemplazar:

```gambas
  FMain.ValueBoxParcial.Value = 1
  FMain.SplitterPrincipal.Visible = True
```

Por:

```gambas
  FMain.ValueBoxParcial.Value = 1
  FMain.SplitterPrincipal.Visible = True
  ' NOTAS: PESTAÑA E INDICADOR DEL PROYECTO RECIÉN ABIERTO (IdProyectoEnCurso
  ' YA FIJADO EN EL APARTADO DE BLOQUEO)
  m_Notas.CambioDeProyecto()
```

## 11. m_InicioCierre.module — CerrarProyecto, apartado 7

En el archivo `m_InicioCierre.module`, en **CerrarProyecto, apartado 7**.

Reemplazar:

```gambas
  ResetearEstadoDeProyecto()
  NombreProyectoEnCurso = ""
  RutaProyectoEnCurso = ""
  IdProyectoEnCurso = 0

End
```

Por:

```gambas
  ResetearEstadoDeProyecto()
  NombreProyectoEnCurso = ""
  RutaProyectoEnCurso = ""
  IdProyectoEnCurso = 0

  ' --- 8. NOTAS: SIN PROYECTO, PESTAÑA VACÍA E INDICADOR OCULTO ---
  ' VA DESPUÉS DE IdProyectoEnCurso = 0: m_Notas DECIDE POR ESE VALOR
  m_Notas.CambioDeProyecto()

End
```

## 12. m_ConexionBD.module — ObtenerEsquemaEsperado, apartado 1

En el archivo `m_ConexionBD.module`, en **ObtenerEsquemaEsperado, apartado 1**.

Reemplazar:

```gambas
  hEsquema["manual_ayudas"] = 9
  hEsquema["orden_taller"] = 19
```

Por:

```gambas
  hEsquema["manual_ayudas"] = 9
  ' NOTAS INTERNAS: 1.10.0. postits SIGUE HASTA SU RETIRO EN UNA VERSIÓN POSTERIOR
  hEsquema["notas"] = 11
  hEsquema["notas_grupos"] = 4
  hEsquema["notas_miembros"] = 8
  hEsquema["notas_respuestas"] = 5
  hEsquema["notas_vistas"] = 3
  hEsquema["orden_taller"] = 19
```

## 13. m_ConexionBD.module — declaraciones del módulo

En el archivo `m_ConexionBD.module`, en **declaraciones del módulo**.

Reemplazar:

```gambas
Public ipServidorActual As String   ' IP CON LA QUE SE ABRIÓ mConn — PARA SONDEO DEL SEMÁFORO
```

Por:

```gambas
Public ipServidorActual As String   ' IP CON LA QUE SE ABRIÓ mConn — PARA SONDEO DEL SEMÁFORO
Public ErrorConexionSondeo As String   ' ÚLTIMO FALLO DE AbrirConexionSondeo (LO MUESTRA m_Notas)
```

## 14. m_ConexionBD.module — SondearEstadoConexion, al final (función nueva a continuación)

En el archivo `m_ConexionBD.module`, en **SondearEstadoConexion, al final (función nueva a continuación)**.

Reemplazar:

```gambas
  ' --- 5. RETORNO ---
  Return bViva

End
```

Por:

```gambas
  ' --- 5. RETORNO ---
  Return bViva

End

' ============================================
' Función   : AbrirConexionSondeo
' Propósito : ABRIR UNA CONEXIÓN APARTE PARA UN SONDEO PERIÓDICO (m_Notas),
'             CON PLAZO DE APERTURA Y DE LECTURA. Connection.Timeout SOLO
'             ACOTA Open(); EL PLAZO DE CADA CONSULTA VA POR
'             Options["READ_TIMEOUT"], QUE EL DRIVER DE gb.db2.mysql PASA A
'             MYSQL_OPT_READ_TIMEOUT (options.h). LEÍDO EN EL FUENTE; MEDIDO
'             EN 3.19 CON gb.db: SELECT SLEEP(5) FALLA A LOS 2,00 s CON
'             «Lost connection», Y LA CONEXIÓN QUEDA MUERTA. UNA CLAVE MAL
'             ESCRITA EN Options SE IGNORA SIN AVISO.
'             PENDIENTE: CUANDO app_user/PASSWORD PASEN AL ARCHIVO CONF,
'             ACTUALIZAR ESTE BLOQUE JUNTO CON ConexionAbierta Y
'             SondearEstadoConexion (HOY TRIPLICADOS).
' Parámetros: iPlazoLectura As Integer — SEGUNDOS DE ESPERA POR CONSULTA
' Retorna   : Connection — ABIERTA; NULL SI NO SE PUDO (EL MOTIVO QUEDA EN
'             ErrorConexionSondeo)
' ============================================
Public Function AbrirConexionSondeo(iPlazoLectura As Integer) As Connection

  ' --- 0. INICIALIZACIÓN ---
  Dim hConn As Connection

  ErrorConexionSondeo = ""

  ' --- 1. VALIDACIÓN: DEBE HABER IP CACHEADA ---
  If ipServidorActual = "" Then
    ErrorConexionSondeo = "sin servidor"
    Return Null
  Endif

  ' --- 2. CONFIGURAR (MISMAS CREDENCIALES QUE mConn) ---
  hConn = New Connection
  hConn.Type = "mysql"
  hConn.Host = ipServidorActual
  hConn.Port = 3306
  hConn.Name = "gbpublisher"
  hConn.User = "app_user"
  hConn.Password = "AppUser2024!"
  hConn.Timeout = 3
  ' LAS OPCIONES SE LEEN AL ABRIR: VAN ANTES DE Open
  hConn.Options["READ_TIMEOUT"] = iPlazoLectura

  ' --- 3. ABRIR (RC-GM-02) ---
  Try hConn.Open
  If Error Then
    ErrorConexionSondeo = Error.Text
    Return Null
  Endif
  If Not hConn.Opened Then
    ErrorConexionSondeo = "la conexión no quedó abierta"
    Return Null
  Endif

  Return hConn

End
```

## 15. FEstadisticas.class — LlenaTablas, consulta de tablas (y su comentario de cabecera)

En el archivo `FEstadisticas.class`, en **LlenaTablas, consulta de tablas (y su comentario de cabecera)**.

Reemplazar:

```gambas
    "AND TABLE_NAME NOT IN ('contador_tiempo', 'postits', 'usuarios', 'usuarios_sistema', 'consultas') " &
```

Por:

```gambas
    "AND TABLE_NAME NOT IN ('contador_tiempo', 'postits', 'usuarios', 'usuarios_sistema', 'consultas', " &
    "'notas', 'notas_grupos', 'notas_miembros', 'notas_respuestas', 'notas_vistas') " &
```

## 16. FEstadisticas.class — cabecera de LlenaTablas

En el archivo `FEstadisticas.class`, en **cabecera de LlenaTablas**.

Reemplazar:

```gambas
'   - EXCLUYE tablas del sistema: contador_tiempo, postits, usuarios,
'     usuarios_sistema, consultas
```

Por:

```gambas
'   - EXCLUYE tablas del sistema: contador_tiempo, postits, usuarios,
'     usuarios_sistema, consultas y las cinco de notas internas
```

## 17. FSysAdmin.class — btnGuardarCambiosProyecto_Click (la función entera se reemplaza)

En el archivo `FSysAdmin.class`, en **btnGuardarCambiosProyecto_Click (la función entera se reemplaza)**.

Reemplazar:

```gambas
' ============================================
' Función   : btnGuardarCambiosProyecto_Click
' Propósito : Actualiza el estado de un proyecto, incluyendo
'             el campo ocupado para liberar proyectos bloqueados
'             por cortes de energía o cuelgues de la app
' ============================================
Public Sub btnGuardarCambiosProyecto_Click()

  ' --- 1. Verificar selección y conexión ---
  Dim iRow As Integer = TableViewProyectos.Row

  If iRow < 0 Then
    m_Sonido.sonar("Warning")
    Message.Warning("Debe seleccionar un proyecto de la tabla para modificar.")
    Return
  Endif

  If Not hConnServidor Or Not hConnServidor.Opened Then
    m_Sonido.sonar("Warning")
    Message.Warning("No hay conexión al servidor.")
    Return
  Endif

  ' --- 2. Obtener datos del proyecto ---
  Dim iProyectoID As Integer = Val(TableViewProyectos[iRow, 0].Text)
  Dim sNombreProyecto As String = TableViewProyectos[iRow, 1].Text
  Dim bNuevoEstado As Boolean = RadioButtonEnCurso.Value

  ' --- 3. Actualizar activo y ocupado en la BD ---
  ' OCUPADO SE INCLUYE SIEMPRE PARA PERMITIR LIBERAR PROYECTOS BLOQUEADOS
  hConnServidor.Exec("UPDATE proyectos SET activo = " &
    If(bNuevoEstado, "TRUE", "FALSE") &
      ", ocupado = " & If(chkOcupado.Value, "1", "0") &
      ", fecha_modificacion = NOW() " &
      "WHERE id = " & iProyectoID & ";")

    m_Sonido.sonar("Info")
    Message.Info("Estado del proyecto <b>'" & sNombreProyecto & "'</b> actualizado correctamente.")

    CargarProyectosDelServidor()

  Catch
    m_Sonido.sonar("Error")
    Message.Error("Error guardando cambios: " & Error.Text)

End
```

Por:

```gambas
' ============================================
' Función   : btnGuardarCambiosProyecto_Click
' Propósito : ACTUALIZAR EL ESTADO DE UN PROYECTO, INCLUIDO ocupado PARA
'             LIBERAR PROYECTOS BLOQUEADOS POR CORTES O CUELGUES. ARCHIVAR UN
'             PROYECTO CIERRA LAS NOTAS ABIERTAS DE SU GRUPO EN LA MISMA
'             TRANSACCIÓN, FIRMADAS CON EL NOMBRE DEL ADMINISTRADOR. REACTIVARLO
'             NO LAS REABRE.
' Parámetros: ninguno
' Retorna   : nada
' ============================================
Public Sub btnGuardarCambiosProyecto_Click()

  ' --- 0. INICIALIZACIÓN ---
  Dim iRow As Integer
  Dim iProyectoID As Integer
  Dim sNombreProyecto As String
  Dim bNuevoEstado As Boolean
  Dim sError As String

  ' --- 1. VERIFICAR SELECCIÓN Y CONEXIÓN ---
  iRow = TableViewProyectos.Row
  If iRow < 0 Then
    m_Sonido.sonar("Warning")
    Message.Warning("Debe seleccionar un proyecto de la tabla para modificar.")
    Return
  Endif

  ' NULL Y Opened EN If SEPARADOS: Or NO ES SHORT-CIRCUIT (RC-GM-17)
  If Not hConnServidor Then
    m_Sonido.sonar("Warning")
    Message.Warning("No hay conexión al servidor.")
    Return
  Endif
  If Not hConnServidor.Opened Then
    m_Sonido.sonar("Warning")
    Message.Warning("No hay conexión al servidor.")
    Return
  Endif

  ' --- 2. DATOS DEL PROYECTO ---
  iProyectoID = Val(TableViewProyectos[iRow, 0].Text)
  sNombreProyecto = TableViewProyectos[iRow, 1].Text
  bNuevoEstado = RadioButtonEnCurso.Value

  ' --- 3. ESTADO DEL PROYECTO Y, SI SE ARCHIVA, CIERRE DE SUS NOTAS ---
  ' UNA SOLA TRANSACCIÓN (SC-07): SI EL CIERRE FALLA, EL PROYECTO NO QUEDA
  ' ARCHIVADO CON NOTAS ABIERTAS. OCUPADO SE INCLUYE SIEMPRE PARA PERMITIR
  ' LIBERAR PROYECTOS BLOQUEADOS
  Try hConnServidor.Begin()
  If Error Then Goto FALLA_SQL

  Try hConnServidor.Exec("UPDATE proyectos SET activo = &2, ocupado = &3, fecha_modificacion = NOW() WHERE id = &1",
    iProyectoID, If(bNuevoEstado, 1, 0), If(chkOcupado.Value, 1, 0))
  If Error Then Goto FALLA_SQL

  If Not bNuevoEstado Then
    ' EL CIERRE ES ACTIVIDAD: LOS MIEMBROS LO VEN COMO NOVEDAD
    Try hConnServidor.Exec("UPDATE notas n JOIN notas_grupos g ON g.id = n.id_grupo " &
      "SET n.fecha_cierre = NOW(), n.cierre_sistema = &2, n.ultima_actividad = NOW(6) " &
      "WHERE g.id_proyecto = &1 AND n.fecha_cierre IS NULL", iProyectoID, sUsuarioActual)
    If Error Then Goto FALLA_SQL
  Endif

  Try hConnServidor.Commit()
  If Error Then Goto FALLA_SQL

  ' --- 4. RESULTADO ---
  m_Sonido.sonar("Info")
  Message.Info("Estado del proyecto <b>'" & sNombreProyecto & "'</b> actualizado correctamente.")
  CargarProyectosDelServidor()
  Return

FALLA_SQL:
  ' EL TEXTO SE GUARDA ANTES DEL Rollback, QUE PODRÍA PISARLO
  sError = Error.Text
  Try hConnServidor.Rollback()
  m_Sonido.sonar("Error")
  Message.Error("Error guardando cambios: " & sError)

End
```
