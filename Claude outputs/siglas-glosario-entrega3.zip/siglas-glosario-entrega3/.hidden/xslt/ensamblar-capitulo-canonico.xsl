<?xml version="1.0" encoding="UTF-8"?>
<!--
  =====================================================
  ensamblar-capitulo-canonico.xsl
  =====================================================
  DESCRIPCIÓN:
    ENSAMBLA EL CAPÍTULO DOCBOOK 5.2 CANÓNICO COMPLETO
    A PARTIR DE TRES FRAGMENTOS GENERADOS POR GBPUBLISHER:

    - FUENTE PRINCIPAL (-s):  info-cap-NN.xml
    - PARÁMETRO body:         body-cap-NN.xml
    - PARÁMETRO biblio:       biblio-cap-NN.xml (OPCIONAL,
                              SOLO SI lugar_bibliografia='por_capitulo')

    PARÁMETROS ADICIONALES:
    - tipo_capitulo:    VALOR DEL ENUM capitulos.tipo_capitulo
                        ('capitulo' POR DEFECTO).
    - xml_id_capitulo:  VALOR ASCII PARA EL xml:id DEL WRAPPER RAÍZ
                        (TÍPICAMENTE 'cap-{id_capitulo}').
    - idioma:           xml:lang DEL CAPÍTULO ('es' POR DEFECTO).

  USO:
    java -jar /opt/Saxon-HE/saxon-he-12.9.jar \
      -s:tmp/info-cap-01.xml \
      -xsl:~/.gbpublisher/xslt/ensamblar-capitulo-canonico.xsl \
      -o:c-cap-01.xml \
      body=tmp/body-cap-01.xml \
      biblio=tmp/biblio-cap-01.xml \
      tipo_capitulo=capitulo \
      xml_id_capitulo=cap-37 \
      idioma=es

  ESTRUCTURA DE SALIDA (EJEMPLO CAPÍTULO REGULAR):
    <chapter xmlns="http://docbook.org/ns/docbook"
             xmlns:xlink="http://www.w3.org/1999/xlink"
             xmlns:mml="http://www.w3.org/1998/Math/MathML"
             version="5.2"
             xml:lang="es"
             xml:id="cap-37">
      <info>...</info>          ← DESDE info-cap-NN.xml
      <section>...</section>    ← DESDE body-cap-NN.xml (HIJOS DEL section RAÍZ)
      <bibliography>...</bibliography>  ← DESDE biblio-cap-NN.xml (OPCIONAL)
    </chapter>

  MAPEO tipo_capitulo → ELEMENTO RAÍZ + role:
    SIMPLES (SIN role):
      capitulo        → <chapter>
      dedicatoria     → <dedication>
      agradecimientos → <acknowledgements>
      apendice        → <appendix>
      glosario        → <glossary>
      bibliografia    → <bibliography>
      colofon         → <colophon>
    CON role:
      prologo, prefacio, presentacion, palabras_preliminares,
      nota_traductor, nota_editor, posfacio, post_scriptum → <preface role="...">
      introduccion, conclusiones, epilogo                  → <chapter role="...">
      sobre_autores, cronologia                            → <appendix role="...">
    ESPECIALES:
      lista_figuras         → <toc role="lof">
      lista_tablas          → <toc role="lot">
      lista_abreviaturas    → <glossary role="abreviaturas">
      otro                  → <chapter role="otro"> (FALLBACK)
    LOS ÍNDICES (indice_onomastico, indice_concepto, indice_autores) NO
    PASAN POR ESTA HOJA: SON PIEZAS SIN CUERPO (m_PiezasLibro.TieneCuerpo)
    Y LOS COMPONE LaTeX (SC-77). LAS MARCAS SÍ: indexterm EN EL CUERPO DE
    CADA PIEZA, CON SU startref PREFIJADO COMO LOS DEMÁS id.

  TRANSFORMACIONES APLICADAS:
    1. SLUGIFY xml:id CON CARACTERES NO-ASCII (TÍPICAMENTE LOS
       AUTOGENERADOS POR PANDOC DESDE TÍTULOS CON TILDES).
       SE ACTUALIZAN TAMBIÉN LOS xlink:href INTERNOS QUE LOS
       REFERENCIAN.
    2. ELIMINAR <textobject><phrase> DENTRO DE <figure> CUANDO
       SU CONTENIDO DUPLICA EL <title> DE LA FIGURA. EN UN LIBRO EL
       TEXTO ALTERNATIVO ES OBLIGATORIO Y NO SE REEMPLAZA CON EL PIE
       (SC-76): UNO QUE LO REPITE CUENTA COMO AUSENTE, Y gbp-alt LO
       SEÑALA.
    3. DESCARTAR EL <title> DEL <section> RAÍZ DEL BODY PANDOC
       (ES EL PRIMER HEADING DEL MARKDOWN, REDUNDANTE CON EL
       <title> QUE VIENE EN <info>).

  NOTAS:
    - SIN DOCTYPE: DOCBOOK 5.2 USA RELAX NG, NO DTD. EL DOCUMENTO
      SE VALIDA CONTRA docbook.rng-5.2 INSTALADO LOCALMENTE.
    - NAMESPACES DECLARADOS UNA SOLA VEZ EN EL ELEMENTO RAÍZ.
    - VERSIÓN XSLT: 2.0 (REQUIERE SAXON-HE 12.x).
  =====================================================
-->
<xsl:stylesheet
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns="http://docbook.org/ns/docbook"
  xmlns:db="http://docbook.org/ns/docbook"
  xmlns:xlink="http://www.w3.org/1999/xlink"
  xmlns:mml="http://www.w3.org/1998/Math/MathML"
  xmlns:xs="http://www.w3.org/2001/XMLSchema"
  exclude-result-prefixes="db xs xlink mml"
  version="2.0">

  <!-- ================================================
       PARÁMETROS DE ENTRADA
       ================================================ -->
  <xsl:param name="body" as="xs:string"/>
  <xsl:param name="biblio" as="xs:string" select="''"/>
  <xsl:param name="tipo_capitulo" as="xs:string" select="'capitulo'"/>
  <xsl:param name="xml_id_capitulo" as="xs:string" select="''"/>
  <xsl:param name="idioma" as="xs:string" select="'es'"/>

  <!-- RUTA DEL XML DE HUELLAS QUE ESCRIBE generar_canonicos_capitulos.sh
       (SC-75): UNA <fuente archivo="…" sha256="…"/> POR CADA ARCHIVO QUE SE
       COPIA DENTRO DEL CANÓNICO, EL .md Y SUS CUADROS. required: UN
       CANÓNICO SIN SUS HUELLAS ES JUSTO LO QUE ESTA REGLA EVITA. CON UNA
       HOJA ANTERIOR, QUE NO DECLARA EL PARÁMETRO, SAXON LO IGNORA Y EL
       CANÓNICO SALE «SIN HUELLA»: EL VALIDADOR LO DICE (SC-11) -->
  <xsl:param name="huellas" as="xs:string" required="yes"/>

  <!-- ================================================
       SALIDA: DOCBOOK 5.2 SIN DOCTYPE
       VALIDACIÓN POSTERIOR CON RELAX NG (jing / Saxon NG).
       ================================================ -->
  <!-- indent="no" (SC-30): CON indent="yes" SAXON METE UN SALTO DE
       LÍNEA CON SANGRÍA DONDE UN ELEMENTO QUEDA PEGADO A OTRO SIN TEXTO
       EN MEDIO —</quote></quote>, «<emphasis>, </emphasis><footnote>—, Y
       ESE SALTO SE VE COMO UN ESPACIO EN LA SALIDA (VERIFICADO, GV-71).
       LA SANGRÍA QUE TRAEN LAS FUENTES SE CONSERVA: LA COPIA LLEVA SUS
       NODOS DE ESPACIO. -->
  <xsl:output
    method="xml"
    encoding="UTF-8"
    indent="no"
    omit-xml-declaration="no"/>

  <!-- ================================================
       FUNCIÓN UTILITARIA: SLUGIFY
       CONVIERTE UN STRING CON CARACTERES NO-ASCII A SU
       EQUIVALENTE ASCII APROXIMADO. ETAPA 1: TRADUCE
       VOCALES CON TILDES, DIÉRESIS, ETC. ETAPA 2:
       REEMPLAZA CUALQUIER CARÁCTER NO-ASCII RESTANTE
       POR GUIÓN PARA EVITAR IDs INVÁLIDOS.
       ================================================ -->
  <xsl:function name="db:slugify" as="xs:string">
    <xsl:param name="s" as="xs:string"/>
    <!-- ETAPA 1: ROMANCE COMMON (ESPAÑOL, PORTUGUÉS, FRANCÉS, CATALÁN) -->
    <xsl:variable name="t1" select="translate($s,
      'áàäâãéèëêíìïîóòöôõúùüûñçÁÀÄÂÃÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÑÇ',
      'aaaaaeeeeiiiiooooouuuuncAAAAAEEEEIIIIOOOOOUUUUNC')"/>
    <!-- ETAPA 2: CUALQUIER OTRO NO-ASCII → '-' (GUARDIA PARA
         CARACTERES DE OTROS ALFABETOS QUE EVENTUALMENTE APAREZCAN).
         USA \p{IsBasicLatin} EN VEZ DE \x00-\x7F PORQUE XPATH 2.0
         SIGUE XSD REGEX, QUE NO ACEPTA ESCAPES HEX LITERALES. EL
         BLOQUE UNICODE IsBasicLatin EQUIVALE EXACTAMENTE A U+0000
         HASTA U+007F (RANGO ASCII COMPLETO). -->
    <xsl:sequence select="replace($t1, '[^\p{IsBasicLatin}]', '-')"/>
  </xsl:function>

  <!-- ================================================
       FUNCIÓN: db:es-id-global
       LOS IDs QUE NO SE PREFIJAN CON EL DEL CAPÍTULO:
         bib-*  ÚNICOS POR EL id DE LA BASE (biblioentry).
         fig-*  LOS ESCRIBE EL EDITOR EN EL .md (::: {.fig #fig-mapa})
                Y LOS REFIERE CON @fig-mapa DESDE CUALQUIER CAPÍTULO.
                CON EL PREFIJO, UNA REFERENCIA A UNA FIGURA DE OTRO
                CAPÍTULO QUEDABA APUNTANDO AL PROPIO: cap-3.fig-mapa
                CONTRA cap-5.fig-mapa. SON ÚNICOS EN EL LIBRO POR
                CONVENCIÓN; UN REPETIDO LO INFORMA LA COMPILACIÓN DEL
                PDF Y LO AVISAN LAS SALIDAS DIGITALES.
         tbl-*  LOS CUADROS (SC-66): EL id ES EL NOMBRE DE SU ARCHIVO EN
                cuadros/, ASÍ QUE ES ÚNICO EN EL PROYECTO. SE REFIEREN CON
                @tbl-nombre DESDE CUALQUIER CAPÍTULO, COMO LAS FIGURAS.
       LOS PREFIJOS DE REFERENCIA SON LOS MISMOS QUE LOS DE
       cite-to-biblioref-db.lua: AGREGAR eq- EN LOS DOS.
       ================================================ -->
  <xsl:function name="db:es-id-global" as="xs:boolean">
    <xsl:param name="id" as="xs:string"/>
    <xsl:sequence select="starts-with($id, 'bib-') or starts-with($id, 'fig-')
                          or starts-with($id, 'tbl-')"/>
  </xsl:function>

  <!-- ================================================
       TEMPLATE RAÍZ
       PUNTO DE ENTRADA: PROCESA info-cap-NN.xml
       ================================================ -->
  <xsl:template match="/">

    <!-- DERIVAR elementoRaiz Y roleAtributo SEGÚN tipo_capitulo -->
    <xsl:variable name="elementoRaiz">
      <xsl:choose>
        <xsl:when test="$tipo_capitulo = 'capitulo'">chapter</xsl:when>
        <xsl:when test="$tipo_capitulo = 'introduccion'">chapter</xsl:when>
        <xsl:when test="$tipo_capitulo = 'conclusiones'">chapter</xsl:when>
        <xsl:when test="$tipo_capitulo = 'epilogo'">chapter</xsl:when>
        <xsl:when test="$tipo_capitulo = 'prologo'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'prefacio'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'presentacion'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'palabras_preliminares'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'nota_traductor'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'nota_editor'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'posfacio'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'post_scriptum'">preface</xsl:when>
        <xsl:when test="$tipo_capitulo = 'dedicatoria'">dedication</xsl:when>
        <xsl:when test="$tipo_capitulo = 'agradecimientos'">acknowledgements</xsl:when>
        <xsl:when test="$tipo_capitulo = 'apendice'">appendix</xsl:when>
        <xsl:when test="$tipo_capitulo = 'sobre_autores'">appendix</xsl:when>
        <xsl:when test="$tipo_capitulo = 'cronologia'">appendix</xsl:when>
        <xsl:when test="$tipo_capitulo = 'glosario'">glossary</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_abreviaturas'">glossary</xsl:when>
        <xsl:when test="$tipo_capitulo = 'bibliografia'">bibliography</xsl:when>
        <xsl:when test="$tipo_capitulo = 'colofon'">colophon</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_figuras'">toc</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_tablas'">toc</xsl:when>
        <xsl:otherwise>chapter</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- DERIVAR roleAtributo: VACÍO PARA CAPÍTULOS NEUTROS,
         NOMBRE DEL tipo PARA TIPOS QUE COMPARTEN ELEMENTO -->
    <xsl:variable name="roleAtributo">
      <xsl:choose>
        <xsl:when test="$tipo_capitulo = 'introduccion'">introduccion</xsl:when>
        <xsl:when test="$tipo_capitulo = 'conclusiones'">conclusiones</xsl:when>
        <xsl:when test="$tipo_capitulo = 'epilogo'">epilogo</xsl:when>
        <xsl:when test="$tipo_capitulo = 'prologo'">prologo</xsl:when>
        <xsl:when test="$tipo_capitulo = 'prefacio'">prefacio</xsl:when>
        <xsl:when test="$tipo_capitulo = 'presentacion'">presentacion</xsl:when>
        <xsl:when test="$tipo_capitulo = 'palabras_preliminares'">palabras-preliminares</xsl:when>
        <xsl:when test="$tipo_capitulo = 'nota_traductor'">nota-traductor</xsl:when>
        <xsl:when test="$tipo_capitulo = 'nota_editor'">nota-editor</xsl:when>
        <xsl:when test="$tipo_capitulo = 'posfacio'">posfacio</xsl:when>
        <xsl:when test="$tipo_capitulo = 'post_scriptum'">post-scriptum</xsl:when>
        <xsl:when test="$tipo_capitulo = 'sobre_autores'">sobre-autores</xsl:when>
        <xsl:when test="$tipo_capitulo = 'cronologia'">cronologia</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_abreviaturas'">abreviaturas</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_figuras'">lof</xsl:when>
        <xsl:when test="$tipo_capitulo = 'lista_tablas'">lot</xsl:when>
        <xsl:when test="$tipo_capitulo = 'otro'">otro</xsl:when>
        <xsl:otherwise></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>


    <!-- CARGAR FRAGMENTO body (OBLIGATORIO) -->
    <xsl:variable name="bodyDoc" select="document($body)"/>

    <!-- LAS HUELLAS DE LAS FUENTES, ANTES DE LA RAÍZ (SC-75). EN EL PRÓLOGO
         NO LAS VE jing NI LAS TOMAN LAS HOJAS DE SALIDA (GV-XML-02), Y LAS
         LEE vigencia_canonico DE engine/comun.sh. LA FORMA —archivo PRIMERO,
         sha256 DESPUÉS, COMILLAS DOBLES— ES LA QUE ESA FUNCIÓN ESPERA: SI
         CAMBIA ACÁ, CAMBIA ALLÁ. EL CONTENIDO DE UNA PI NO SE ESCAPA: LA
         RUTA LLEGA SIN COMILLAS PORQUE EL SCRIPT LAS RECHAZA -->
    <xsl:for-each select="doc($huellas)/huellas/fuente">
      <xsl:processing-instruction name="gb-fuente"
        select="concat('archivo=&quot;', @archivo, '&quot; sha256=&quot;', @sha256, '&quot;')"/>
    </xsl:for-each>

    <!-- ELEMENTO RAÍZ DINÁMICO -->
    <xsl:element name="{$elementoRaiz}">
      <!-- DECLARAR EXPLÍCITAMENTE LOS NAMESPACES QUE USARÁN LOS
           DESCENDIENTES, PARA QUE SAXON NO LOS RE-EMITA EN CADA
           NODO HIJO COPIADO DESDE EL document() DEL BODY. -->
      <xsl:namespace name="xlink" select="'http://www.w3.org/1999/xlink'"/>
      <xsl:namespace name="mml" select="'http://www.w3.org/1998/Math/MathML'"/>
      <xsl:attribute name="version" select="'5.2'"/>
      <xsl:attribute name="xml:lang" select="$idioma"/>
      <xsl:if test="$xml_id_capitulo != ''">
        <xsl:attribute name="xml:id" select="$xml_id_capitulo"/>
      </xsl:if>
      <xsl:if test="$roleAtributo != ''">
        <xsl:attribute name="role" select="$roleAtributo"/>
      </xsl:if>

      <!-- PASO 1: INSERTAR <info> DESDE EL ARCHIVO PRINCIPAL -->
      <xsl:apply-templates select="//db:info | //info"/>

      <!-- PASO 2: INSERTAR CONTENIDO DEL BODY
           DESCARTANDO EL <title> DEL section RAÍZ (REDUNDANTE
           CON EL <title> DE <info>). TOMA TODOS LOS HIJOS DEL
           ROOT EXCEPTO TITLE. -->
      <xsl:apply-templates
        select="$bodyDoc/*/node()[not(self::db:title) and not(self::title)]"/>

      <!-- PASO 3: INSERTAR <bibliography> SI EL FRAGMENTO EXISTE.
           NO APLICA SI tipo_capitulo='bibliografia' (EL CAPÍTULO
           ENTERO ES LA BIBLIOGRAFÍA, EL CONTENIDO YA VINO EN body). -->
      <xsl:if test="$biblio != '' and $tipo_capitulo != 'bibliografia'">
        <xsl:variable name="biblioDoc" select="document($biblio)"/>
        <xsl:if test="$biblioDoc/db:bibliography/db:biblioentry
                      or $biblioDoc/bibliography/biblioentry">
          <xsl:apply-templates
            select="$biblioDoc/db:bibliography | $biblioDoc/bibliography"/>
        </xsl:if>
      </xsl:if>

    </xsl:element>
  </xsl:template>

  <!-- ================================================
       TEMPLATE DE IDENTIDAD
       COPIA TODOS LOS NODOS TAL CUAL, EXCEPTO LOS
       QUE TIENEN TEMPLATES ESPECÍFICOS MÁS ABAJO.
       USA copy-namespaces="no" PARA EVITAR QUE LOS
       ELEMENTOS DESCENDIENTES RE-DECLAREN xmlns:mml Y
       xmlns:xlink QUE YA ESTÁN EN EL ELEMENTO RAÍZ.
       ================================================ -->
  <xsl:template match="@*|node()">
    <xsl:copy copy-namespaces="no">
      <xsl:apply-templates select="@*|node()"/>
    </xsl:copy>
  </xsl:template>

  <!-- ================================================
       SLUGIFY xml:id CON CARACTERES NO-ASCII
       LOS xml:id AUTOGENERADOS POR PANDOC DESDE TÍTULOS
       (TÍPICAMENTE CON TILDES Y ñ) SE NORMALIZAN A ASCII
       PARA COMPATIBILIDAD CON HERRAMIENTAS EXTERNAS
       (CROSSREF, EPUB VALIDATORS, ETC.).
       LOS xml:id YA ASCII (TÍPICAMENTE LOS EXPLÍCITOS DEL
       AUTOR: fig-N, tbl-N, eq-N, cap-N) SE PRESERVAN.
       ================================================ -->
  <xsl:template match="@xml:id">
    <!-- PASO 1: NORMALIZAR A ASCII SI TIENE CARACTERES NO-LATINOS -->
    <xsl:variable name="idNormalizado" as="xs:string">
      <xsl:choose>
        <xsl:when test="matches(., '[^\p{IsBasicLatin}]')">
          <xsl:value-of select="db:slugify(.)"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="."/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- PASO 2: PREFIJAR CON $xml_id_capitulo PARA EVITAR COLISIONES
         AL ENSAMBLAR EL LIBRO COMPLETO.
         EXCEPCIONES: LOS IDs GLOBALES (db:es-id-global), bib-* Y fig-*,
         NO SE PREFIJAN. -->
    <xsl:choose>
      <xsl:when test="db:es-id-global($idNormalizado)">
        <xsl:attribute name="xml:id" select="$idNormalizado"/>
      </xsl:when>
      <xsl:when test="$xml_id_capitulo != ''">
        <xsl:attribute name="xml:id"
                       select="concat($xml_id_capitulo, '.', $idNormalizado)"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:attribute name="xml:id" select="$idNormalizado"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ================================================
       SLUGIFY xlink:href INTERNO (FRAGMENTOS #X)
       SE APLICA SOLO A xlink:href QUE EMPIEZAN CON '#'
       (REFERENCIAS INTERNAS); LAS URLs EXTERNAS SE
       PRESERVAN INTACTAS.
       MANTIENE LA CONSISTENCIA ENTRE EL xml:id NORMALIZADO
       Y LAS REFERENCIAS QUE LO USAN.
       ================================================ -->
  <xsl:template match="@xlink:href[starts-with(., '#')]">
    <xsl:variable name="targetId" select="substring-after(., '#')"/>

    <!-- PASO 1: NORMALIZAR A ASCII -->
    <xsl:variable name="targetIdNormalizado" as="xs:string">
      <xsl:choose>
        <xsl:when test="matches($targetId, '[^\p{IsBasicLatin}]')">
          <xsl:value-of select="db:slugify($targetId)"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="$targetId"/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- PASO 2: PREFIJAR CONSISTENTE CON EL TEMPLATE @xml:id -->
    <xsl:choose>
      <xsl:when test="db:es-id-global($targetIdNormalizado)">
        <xsl:attribute name="xlink:href"
                       select="concat('#', $targetIdNormalizado)"/>
      </xsl:when>
      <xsl:when test="$xml_id_capitulo != ''">
        <xsl:attribute name="xlink:href"
                       select="concat('#', $xml_id_capitulo, '.', $targetIdNormalizado)"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:attribute name="xlink:href"
                       select="concat('#', $targetIdNormalizado)"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <!-- ================================================
       PREFIJAR @startref (CIERRE DE UN RANGO DE ÍNDICE, SC-77)
       EL xml:id DEL COMIENZO (idx-N, DE indice.lua) SE PREFIJA CON
       EL DEL CAPÍTULO EN EL TEMPLATE @xml:id; SIN ESTO, EL CIERRE
       APUNTARÍA A UN id QUE YA NO EXISTE Y EL CANÓNICO NO VALIDARÍA
       (startref ES IDREF EN EL RNG). idx-N NO ES GLOBAL Y ES ASCII,
       PERO SE APLICA EL MISMO CRITERIO QUE A @linkend.
       ================================================ -->
  <xsl:template match="@startref">
    <xsl:variable name="targetNormalizado" as="xs:string">
      <xsl:choose>
        <xsl:when test="matches(., '[^\p{IsBasicLatin}]')">
          <xsl:value-of select="db:slugify(.)"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="."/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:choose>
      <xsl:when test="db:es-id-global($targetNormalizado)">
        <xsl:attribute name="startref" select="$targetNormalizado"/>
      </xsl:when>
      <xsl:when test="$xml_id_capitulo != ''">
        <xsl:attribute name="startref"
                       select="concat($xml_id_capitulo, '.', $targetNormalizado)"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:attribute name="startref" select="$targetNormalizado"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ================================================
       PREFIJAR @linkend INTERNO (biblioref, xref) Y @otherterm
       APLICA EL MISMO CRITERIO QUE @xml:id Y @xlink:href
       PARA MANTENER CONSISTENCIA CON LOS IDs PREFIJADOS.
       LOS linkend A bib-* SE PRESERVAN INTACTOS.
       @otherterm ES LA REMISIÓN DEL GLOSARIO (<glosssee>, glosario.lua,
       1.18.0): ES IDREF COMO linkend, Y SIN PREFIJO APUNTARÍA A UN id
       QUE YA NO EXISTE. EL NOMBRE DEL ATRIBUTO SE CONSERVA (name()).
       ================================================ -->
  <xsl:template match="@linkend | @otherterm">
    <!-- PASO 1: NORMALIZAR A ASCII -->
    <xsl:variable name="targetNormalizado" as="xs:string">
      <xsl:choose>
        <xsl:when test="matches(., '[^\p{IsBasicLatin}]')">
          <xsl:value-of select="db:slugify(.)"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="."/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- PASO 2: PREFIJAR CONSISTENTE -->
    <xsl:choose>
      <xsl:when test="db:es-id-global($targetNormalizado)">
        <xsl:attribute name="{name()}" select="$targetNormalizado"/>
      </xsl:when>
      <xsl:when test="$xml_id_capitulo != ''">
        <xsl:attribute name="{name()}"
                       select="concat($xml_id_capitulo, '.', $targetNormalizado)"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:attribute name="{name()}" select="$targetNormalizado"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- ================================================
       ELIMINAR <textobject><phrase> REDUNDANTE EN FIGURAS
       NACIÓ CONTRA EL RUIDO DE PANDOC, QUE PONÍA EL alt
       IGUAL AL <title>. HOY LA FIGURA LA ARMA EL FILTRO
       (fenced-divs-to-elements-db.lua) Y SE QUEDA A
       PROPÓSITO (DECISIÓN DE ALBERTO, 29/10/2026): EL TEXTO
       ALTERNATIVO ES OBLIGATORIO Y NO SE REEMPLAZA CON EL
       PIE. SI EL alt FALTA, EL FILTRO PONE EL PIE COMO RED
       DE SEGURIDAD; ACÁ SE DESCARTA, Y LA REGLA gbp-alt
       DEL VALIDADOR SEÑALA LA FIGURA SIN TEXTO ALTERNATIVO
       (SC-76). NO SACAR ESTA PLANTILLA SIN AFLOJAR ANTES
       ESA REGLA.
       ================================================ -->
  <xsl:template match="db:figure/db:mediaobject/db:textobject[
      normalize-space(db:phrase) = normalize-space(ancestor::db:figure[1]/db:title)
   or normalize-space(db:phrase) = normalize-space(ancestor::db:figure[1]/db:info/db:title)]"/>

  <!-- ================================================
       PRESERVAR ELEMENTOS MathML SIN PERDER NAMESPACE
       LA IDENTIDAD POR DEFAULT YA LOS COPIA CORRECTAMENTE
       PORQUE EL NAMESPACE mml: ESTÁ DECLARADO EN EL
       STYLESHEET. NO HACE FALTA TEMPLATE ESPECÍFICO.
       (DOCUMENTADO POR CLARIDAD.)
       ================================================ -->

</xsl:stylesheet>
