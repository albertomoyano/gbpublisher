# Entrega 3 — el glosario del libro

## Qué hay en el zip

Archivos completos, en sus carpetas, para reemplazar:

- `.hidden/filters/glosario.lua` — **nuevo**. La lista de definiciones de la pieza glosario pasa a `<glossdiv>`/`<glossentry>`, ordenada y por letra; resuelve los `[x]{.vease}`.
- `.hidden/filters/fenced-divs-to-elements-db.lua` — el viejo `::: {.glossary term=…}` (apartado 6.10c) ahora frena con un mensaje.
- `.hidden/engine/comun.sh` — `glosario.lua` entra al final de `FILTROS_LIBRO` (15°), con su razón.
- `.hidden/engine/generar_canonicos_capitulos.sh` — pasa `-M gb-tipo-pieza` a pandoc.
- `.hidden/xslt/ensamblar-capitulo-canonico.xsl` — prefija `@otherterm` como `@linkend` (sin esto, el «véase» apuntaba a un id inexistente).
- `.hidden/xslt/docbook-to-latex.xsl`, `docbook-to-html.xsl`, `docbook-to-epub.xsl` — plantillas del glosario.
- `.hidden/latex/preambulo-contrato.tex` — contrato 20: entorno `gbglosario` y sus macros.
- `.hidden/assets/css/gbpublisher.css`, `gbpublisher-epub-libro.css` — párrafo francés del glosario.

`CAMBIOS.diff` muestra qué cambió en cada uno respecto de lo que tenés hoy.

## Un parche de Gambas

### 1. m_GenerarPDFLibro.module

En el archivo m_GenerarPDFLibro.module, cabecera del módulo, en la constante CONTRATO_VERSION. El contrato sube a 20.

Reemplazar:

```gambas
Public Const CONTRATO_VERSION As Integer = 19
```

por:

```gambas
Public Const CONTRATO_VERSION As Integer = 20
```

## Pendiente de tu lado, en gbShortcodes

- Retirar el shortcode `glossary` (está en borrador; el bloque ya no existe).
- Si querés insertarla desde el panel, un shortcode en línea para la remisión: `vease`, modo `envolver`, apertura `[`, cierre `]{.vease}`; libro liberado, revista `no_aplica`.

## Cómo probar

1. Declarar una pieza de tipo `glosario` (por ejemplo `bm-20-glosario`) con un `.md` así:

```
Una introducción opcional.

*Travelling*
:   Desplazamiento de la cámara. Véase también [plano secuencia]{.vease}.

Plano secuencia
:   Toma sin cortes.

Traveling
:   [Travelling]{.vease}
```

2. Generar todos los canónicos y las tres salidas.
